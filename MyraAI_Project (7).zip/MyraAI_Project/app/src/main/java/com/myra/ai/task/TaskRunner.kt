package com.myra.ai.task

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import com.myra.ai.overlay.OverlayManager
import com.myra.ai.service.MyraAccessibilityService
import kotlinx.coroutines.delay

data class Parsed(val kind: String, val pkg: String?, val name: String?, val video: Boolean)

/** Understands phone commands, runs them step by step with the overlay task card. */
object TaskRunner {
    private val alias = mapOf("व्हाट्सएप" to "whatsapp", "वॉट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "व्हाट्सअप" to "whatsapp", "यूट्यूब" to "youtube", "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook",
        "क्रोम" to "chrome", "कैमरा" to "camera", "टिकटॉक" to "tiktok")
    private val stop = setOf("video", "वीडियो", "call", "कॉल", "कर", "करो", "दो", "पर", "से", "को", "on", "to",
        "whatsapp", "फोन", "please", "प्लीज", "मायरा", "myra")
    private val songStop = setOf("youtube", "पर", "चलाओ", "चला", "play", "गाना", "गाने", "सुनाओ", "सुना", "करो", "दो", "को", "का", "की")

    class Step(val name: String, val action: suspend () -> Boolean)

    fun question(kind: String): String? =
        mapOf("call" to "किसको कॉल करूँ?", "alarm" to "कितने बजे का अलार्म?", "yt_play" to "कौन सा गाना चलाऊँ?")[kind]

    private fun apps(ctx: Context): Map<String, String> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).associate { it.loadLabel(pm).toString().lowercase() to it.activityInfo.packageName }
    }

    private fun nameOf(s: String): String? {
        val raw = Regex("(.+?)\\s+को(?=\\s|$)").find(s)?.groupValues?.get(1)
            ?: Regex("(?:call|कॉल)\\s+(?:to\\s+)?(.+)").find(s)?.groupValues?.get(1) ?: return null
        val n = raw.split(" ").filter { it.isNotBlank() && it !in stop }.joinToString(" ")
        return n.ifBlank { null }
    }

    /** "6:30", "6 30", "शाम 6 बजे" -> "18:30" */
    fun timeOf(s: String): String? {
        val m = Regex("(\\d{1,2})(?:[:.\\s]+(\\d{2}))?").find(s) ?: return null
        var h = m.groupValues[1].toInt(); val min = m.groupValues[2].ifBlank { "0" }.toInt()
        val pm = s.contains("शाम") || s.contains("रात") || s.contains("pm") || s.contains("दोपहर")
        if (pm && h < 12) h += 12
        return if (h < 24 && min < 60) "$h:$min" else null
    }

    private fun songOf(ctx: Context, s: String): String? {
        if (s.contains("मेरा गाना") || s.contains("my song"))
            return ctx.getSharedPreferences("myra", Context.MODE_PRIVATE).getString("p_song", "")?.ifBlank { null }
        return s.split(" ").filter { it.isNotBlank() && it !in songStop }.joinToString(" ").ifBlank { null }
    }

    /** null = not a phone task (send it to Gemini). */
    fun parse(ctx: Context, said: String): Parsed? {
        var s = said.lowercase().trim()
        alias.forEach { (k, v) -> s = s.replace(k, v) }
        val tk = s.split(Regex("\\s+")).toSet()
        fun has(vararg w: String) = w.any { it in tk }
        if (s.contains("battery") || s.contains("बैटरी")) return Parsed("battery", null, null, false)
        if (has("unlock", "अनलॉक")) return Parsed("unlock", null, null, false)
        if (has("lock", "लॉक")) return Parsed("lock", null, null, false)
        if (s.contains("alarm") || s.contains("अलार्म")) return Parsed("alarm", null, timeOf(s), false)
        if (has("copy", "कॉपी")) return Parsed("copy", null, null, false)
        if (has("paste", "पेस्ट")) return Parsed("paste", null, null, false)
        if (has("skip", "स्किप")) return Parsed("yt_skip", null, null, false)
        if (s.contains("youtube")) {
            if (has("like", "लाइक")) return Parsed("yt_like", null, null, false)
            if (s.contains("चला") || s.contains("play") || s.contains("गाना") || s.contains("सुना"))
                return Parsed("yt_play", null, songOf(ctx, s), false)
        }
        if (s.contains("instagram")) {
            if (has("like", "लाइक")) return Parsed("insta_like", null, null, false)
            if (listOf("post", "पोस्ट", "reel", "रील", "story", "स्टोरी", "upload", "अपलोड").any { s.contains(it) })
                return Parsed("insta_post", "com.instagram.android", null, false)
        }
        val isCall = s.contains("call") || s.contains("कॉल")
        val video = s.contains("video") || s.contains("वीडियो")
        val installed = apps(ctx)
        val app = installed.entries.firstOrNull { it.key.length > 2 && s.contains(it.key) }
        val open = s.contains("open") || s.contains("खोल") || s.contains("चलाओ")
        if (isCall) return Parsed("call", app?.value ?: "com.whatsapp", nameOf(s), video)
        if (open && app != null) return Parsed("open", app.value, null, false)
        return null
    }

    private suspend fun retry(f: suspend () -> Boolean): Boolean {
        repeat(3) { if (f()) return true; delay(700) }
        return false
    }

    private fun setAlarm(ctx: Context, t: String): Boolean = runCatching {
        val (h, m) = t.split(":").map { it.toInt() }
        ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, "MYRA")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    }.getOrDefault(false)

    fun steps(ctx: Context, p: Parsed): List<Step> {
        val svc = { MyraAccessibilityService.instance }
        val open = Step("Open App") {
            val s = svc() ?: return@Step false
            s.openApp(ctx, p.pkg ?: return@Step false); delay(2200); true
        }
        when (p.kind) {
            "lock" -> return listOf(Step("Lock Phone") { svc()?.lock() ?: false })
            "alarm" -> return listOf(Step("Set Alarm") { setAlarm(ctx, p.name ?: return@Step false) })
            "copy" -> return listOf(Step("Copy") { svc()?.copy() ?: false })
            "paste" -> return listOf(Step("Paste") { svc()?.paste() ?: false })
            "yt_skip" -> return listOf(Step("Skip Ad") {
                val s = svc() ?: return@Step false; retry { s.clickText("Skip") } })
            "yt_like" -> return listOf(Step("Like Video") {
                val s = svc() ?: return@Step false; retry { s.clickText("like this video") || s.clickText("Like") } })
            "insta_like" -> return listOf(Step("Like Post") {
                val s = svc() ?: return@Step false; retry { s.clickText("Like") } })
            "insta_post" -> return listOf(open, Step("Tap Create") {
                val s = svc() ?: return@Step false; retry { s.clickText("Create") || s.clickText("New post") } })
            "yt_play" -> {
                val q = p.name ?: return emptyList()
                return listOf(
                    Step("Open YouTube") {
                        runCatching {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
                                .setPackage("com.google.android.youtube").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            delay(3500)
                        }.isSuccess
                    },
                    Step("Play Video") {
                        val s = svc() ?: return@Step false; val w = q.split(" ").first(); retry { s.clickText(w) }
                    })
            }
        }
        if (p.kind == "open") return listOf(open)
        val name = p.name ?: ""
        val tap = Step("Tap Element") {
            val s = svc() ?: return@Step false
            retry { s.clickText(name) } || retry {
                s.clickText("Search") && run { delay(600); s.typeInto(name) } && run { delay(900); s.clickText(name) }
            }
        }
        val call = Step(if (p.video) "Video Call" else "Call Contact") {
            val s = svc() ?: return@Step false
            val labels = if (p.video) listOf("Video call", "वीडियो कॉल") else listOf("Voice call", "वॉइस कॉल")
            retry { labels.any { s.clickText(it) } }
        }
        return listOf(open, tap, call)
    }

    suspend fun execute(ctx: Context, steps: List<Step>): Boolean {
        if (steps.isEmpty()) return false
        val st = IntArray(steps.size)
        fun show(state: Int) = OverlayManager.task(ctx, steps.mapIndexed { i, s -> s.name to st[i] }, state)
        show(0)
        for ((i, s) in steps.withIndex()) {
            val ok = runCatching { s.action() }.getOrDefault(false)
            st[i] = if (ok) 1 else 2
            if (!ok) { show(2); return false }
            show(if (i == steps.lastIndex) 1 else 0)
        }
        return true
    }
}
