package com.myra.ai.service

import android.app.*
import android.content.*
import android.os.*
import android.speech.*
import androidx.core.app.NotificationCompat
import com.myra.ai.ai.GeminiClient
import com.myra.ai.overlay.OverlayManager
import com.myra.ai.task.Parsed
import com.myra.ai.task.TaskRunner
import com.myra.ai.voice.Speaker
import kotlinx.coroutines.*

/** Always listening: "Hello Myra" -> "जी बॉस" -> runs phone tasks (with overlay card) or asks Gemini. */
class WakeWordService : Service() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var rec: SpeechRecognizer? = null
    private var awake = false
    private var pending: Parsed? = null
    private lateinit var speaker: Speaker

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "myra"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "MYRA", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, NotificationCompat.Builder(this, ch).setContentTitle("MYRA सुन रही है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        speaker = Speaker(this)
        com.myra.ai.battery.BatteryMonitor.start(this, speaker, scope)
        OverlayManager.showOrb(this)
        listen()
    }

    private fun listen() {
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle) {
                    handle(b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase())
                }
                override fun onError(e: Int) { restart() }
                override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(r: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            })
        }
    }

    private fun restart() = scope.launch { delay(400); listen() }

    private fun handle(said: String) {
        val wake = listOf("hello myra", "हेलो मायरा", "हैलो मायरा", "हेलो मीरा", "hello mira")
        if (!awake) {
            if (wake.any { said.contains(it) }) {
                awake = true; OverlayManager.awake(true)
                scope.launch { speaker.say("जी बॉस") { listen() } }
            } else restart()
            return
        }
        awake = false; OverlayManager.awake(false)
        scope.launch { command(said) }
    }

    private suspend fun command(said: String) {
        val p0 = pending
        pending = null
        val p = if (p0 != null) p0.copy(name = if (p0.kind == "alarm") TaskRunner.timeOf(said) else said.trim()) else TaskRunner.parse(this, said)
        when {
            p == null -> {
                val key = getSharedPreferences("myra", MODE_PRIVATE).getString("gemini_key", "") ?: ""
                speaker.say(GeminiClient.ask(key, said)) { listen() }
            }
            p.kind == "battery" -> speaker.say(com.myra.ai.battery.BatteryMonitor.statusText(this)) { listen() }
            p.kind == "unlock" -> speaker.say("बॉस, PIN या पैटर्न वाला फ़ोन ऐप से अनलॉक नहीं हो सकता, यह Android की सुरक्षा है। फिंगरप्रिंट या फेस अनलॉक इस्तेमाल करो।") { listen() }
            p.name == null && TaskRunner.question(p.kind) != null -> {
                pending = p   // MYRA asks first, then uses your answer
                speaker.say(TaskRunner.question(p.kind)!!) { awake = true; OverlayManager.awake(true); listen() }
            }
            else -> {
                val ok = TaskRunner.execute(this, TaskRunner.steps(this, p))
                speaker.say(if (ok) "हो गया बॉस" else "काम नहीं हो पाया बॉस। Accessibility चालू है?") { listen() }
            }
        }
    }

    override fun onDestroy() {
        rec?.destroy(); com.myra.ai.battery.BatteryMonitor.stop(this); speaker.shutdown(); OverlayManager.hideOrb(); scope.cancel(); super.onDestroy()
    }
}
