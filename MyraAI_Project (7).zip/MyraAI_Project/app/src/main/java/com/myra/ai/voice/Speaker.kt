package com.myra.ai.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speaks with ElevenLabs if keys are saved; otherwise (or on failure) uses the phone's Hindi voice. */
class Speaker(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) tts?.language = Locale("hi", "IN")
        }
    }

    suspend fun say(text: String, done: () -> Unit = {}) {
        val p = ctx.getSharedPreferences("myra", Context.MODE_PRIVATE)
        val ek = p.getString("eleven_key", "").orEmpty().trim()
        val vid = p.getString("voice_id", "").orEmpty().trim()
        if (ek.isNotBlank() && vid.isNotBlank() && ElevenLabsTts(ctx, ek, vid).speak(text, done)) return
        val t = tts
        if (t == null) { main.post { done() }; return }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { done() } }
            @Deprecated("deprecated in Java")
            override fun onError(id: String?) { main.post { done() } }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myra")
    }

    fun shutdown() { tts?.stop(); tts?.shutdown() }
}
