package com.myra.ai.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/** Green particle sphere (floats above all apps). Brighter and faster when MYRA is awake. */
class ParticleView(ctx: Context) : View(ctx) {
    private val n = 420
    private val th = FloatArray(n) { acos(1f - 2f * Random.nextFloat()) }
    private val ph = FloatArray(n) { (2.0 * PI).toFloat() * Random.nextFloat() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    var awake = false

    override fun onDraw(c: Canvas) {
        t += if (awake) 0.035f else 0.012f
        val cx = width / 2f; val cy = height / 2f
        val r = min(width, height) / 2f * (0.86f + 0.07f * sin(t * 2f))
        for (i in 0 until n) {
            val a = ph[i] + t
            val x = sin(th[i]) * cos(a); val z = sin(th[i]) * sin(a); val y = cos(th[i])
            val d = (z + 1f) / 2f
            paint.color = Color.argb((70 + 185 * d).toInt(), if (awake) 120 else 60, 255, if (awake) 230 else 130)
            c.drawCircle(cx + x * r, cy + y * r, 1.6f + 1.8f * d, paint)
        }
        postInvalidateOnAnimation()
    }
}
