package com.myra.ai

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import com.myra.ai.data.Store
import com.myra.ai.overlay.OverlayManager
import com.myra.ai.service.WakeWordService
import com.myra.ai.ui.MyraRoot

class MainActivity : ComponentActivity() {
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.RECORD_AUDIO] == true && Store(this).get("wake") != "off")
            startForegroundService(Intent(this, WakeWordService::class.java))
        if (!Settings.canDrawOverlays(this))   // needed for the floating animation + task card
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.POST_NOTIFICATIONS))
        setContent { MyraRoot() }
    }

    override fun onResume() {
        super.onResume()
        if (Store(this).get("wake") != "off") OverlayManager.showOrb(applicationContext)
    }
}
