package com.myra.ai.ui

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.content.Intent
import android.speech.RecognizerIntent
import com.myra.ai.voice.Speaker
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.myra.ai.service.WakeWordService
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.myra.ai.ai.GeminiClient
import com.myra.ai.ai.GeminiTools
import com.myra.ai.data.Store
import kotlinx.coroutines.launch

/** Use in MainActivity:  setContent { MyraRoot() } */
@Composable
fun MyraRoot() = MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Bg)) { MyraContent() }

@Composable
fun MyraContent() {
    val ctx = LocalContext.current; val store = remember { Store(ctx) }
    var screen by remember { mutableStateOf("Home") }
    if (screen == "Home") AnimatedHome(onTile = { screen = it }, onMic = { screen = "Voice Assistant" }) else
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            TextButton({ screen = "Home" }) { Text("← Home", color = Purple) }
            when (screen) {
                "AI Chat", "Voice Assistant" -> Ask(store, "Gemini से पूछो") { k, q -> GeminiClient.ask(k, q) }
                "Web Search" -> Ask(store, "Internet पर खोजो") { k, q -> GeminiTools.webSearch(k, q) }
                "Live Vision" -> Vision(store)
                "Memory" -> MemoryPanel(store)
                "Automation" -> HistoryPanel(store)
                else -> SettingsPanel(store)   // Phone Control / More Tools -> settings & permissions
            }
        }
}

@Composable
fun Ask(store: Store, hint: String, call: suspend (String, String) -> String) {
    val ctx = LocalContext.current
    val speaker = remember { Speaker(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    var q by remember { mutableStateOf("") }; var a by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    fun run(text: String) = scope.launch {
        a = "सोच रही हूँ..."; a = call(store.get("gemini_key"), text); store.addHistory(text)
        if (!a.startsWith("Error") && !a.startsWith("Network")) speaker.say(a)
    }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { q = it; run(it) }
    }
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text(hint) })
    Row {
        Button({ run(q) }) { Text("भेजो") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton({
            mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
        }) { Text("🎤 बोलो") }
    }
    Text(a, color = Color.White, modifier = Modifier.padding(top = 12.dp))
}

@Composable
fun Vision(store: Store) {
    var q by remember { mutableStateOf("यह क्या है?") }; var a by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val speaker = remember { Speaker(LocalContext.current) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp: Bitmap? ->
        if (bmp != null) scope.launch { a = "देख रही हूँ..."; a = GeminiTools.vision(store.get("gemini_key"), bmp, q)
            if (!a.startsWith("Error") && !a.startsWith("Network")) speaker.say(a) }
    }
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("सवाल") })
    Button({ cam.launch(null) }) { Text("📷 फोटो लो और पूछो") }
    Text(a, color = Color.White, modifier = Modifier.padding(top = 12.dp))
}

@Composable
fun MemoryPanel(store: Store) {
    val speaker = remember { Speaker(LocalContext.current) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(store.memories()) }; var t by remember { mutableStateOf("") }
    OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth(), label = { Text("कुछ याद रखवाओ") })
    Row { Button({ if (t.isNotBlank()) { store.addMemory(t); items = store.memories(); t = ""; scope.launch { speaker.say("ठीक है बॉस, याद कर लिया।") } } }) { Text("Save") }
        Spacer(Modifier.width(8.dp)); OutlinedButton({ store.clearMemories(); items = emptyList() }) { Text("Clear") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton({ scope.launch { speaker.say(if (items.isEmpty()) "अभी कुछ याद नहीं है बॉस।" else items.joinToString(". ")) } }) { Text("🔊 सुनाओ") } }
    LazyColumn { items(items) { Text("• $it", color = Color.White, modifier = Modifier.padding(vertical = 4.dp)) } }
}

@Composable
fun HistoryPanel(store: Store) =
    LazyColumn { items(store.history().reversed()) { Text("• $it", color = Color.White, modifier = Modifier.padding(vertical = 4.dp)) } }

@Composable
fun SettingsPanel(store: Store) {
    val ctx = LocalContext.current
    var wake by remember { mutableStateOf(store.get("wake") != "off") }
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Background Wake Word (Hello Myra)", color = Color.White, modifier = Modifier.weight(1f))
        Switch(wake, { on ->
            wake = on; store.set("wake", if (on) "on" else "off")
            val i = Intent(ctx, WakeWordService::class.java)
            if (on) ctx.startForegroundService(i) else ctx.stopService(i)
        })
    }
    val keys = listOf("gemini_key" to "Gemini API Key", "eleven_key" to "ElevenLabs API Key", "voice_id" to "ElevenLabs Voice ID")
    keys.forEach { (k, label) ->
        var v by remember { mutableStateOf(store.get(k)) }
        OutlinedTextField(v, { v = it; store.set(k, it) }, Modifier.fillMaxWidth().padding(bottom = 8.dp), label = { Text(label) }, singleLine = true)
    }
    Text("Phone Control के लिए: Settings → Accessibility → MYRA ON करो।", color = Color.White)
}
