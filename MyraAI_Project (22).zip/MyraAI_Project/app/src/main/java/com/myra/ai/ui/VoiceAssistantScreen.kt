package com.myra.ai.ui

import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.ai.data.Store
import com.myra.ai.service.VoiceState
import com.myra.ai.service.WakeWordService
import kotlin.math.*
import kotlin.random.Random

private fun toggleVoice(ctx: Context) {
    ctx.startForegroundService(Intent(ctx, WakeWordService::class.java)
        .setAction(if (VoiceState.on) "conv_stop" else "conv_start"))
}

/**
 * ONE option: tap the orb -> MYRA talks continuously (no wake word), even when you switch to any other app,
 * until you tap again (or say "बंद करो"). The orb reacts to your voice and to MYRA's voice.
 */
@Composable
fun VoiceAssistantScreen(store: Store, onSettings: () -> Unit = {}) {
    val ctx = LocalContext.current
    val on = VoiceState.on
    val t = rememberInfiniteTransition(label = "va")
    val orbit by t.animateFloat(0f, 6.2832f, infiniteRepeatable(tween(if (on) 3500 else 12000, easing = LinearEasing)), label = "o")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (on) 4000 else 16000, easing = LinearEasing)), label = "s")
    val pulse by t.animateFloat(0.92f, 1.06f, infiniteRepeatable(tween(if (on) 650 else 2000), RepeatMode.Reverse), label = "p")
    val dots = remember { List(900) { Triple((2.0 * PI).toFloat() * Random.nextFloat(), acos(1f - 2f * Random.nextFloat()), Random.nextFloat()) } }
    val teal = Color(0xFF3FE0B0); val red = Color(0xFFFF2D3D)
    val name = store.get("p_name").ifBlank { "बॉस" }

    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Hello, $name", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.Start))
        Text(if (on) "मैं सुन रही हूँ..." else "How can I assist you today?", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.align(Alignment.Start))
        if (store.get("gemini_key").isBlank()) {
            Text("⚠ Gemini API Key खाली है: इसके बिना MYRA सुनेगी नहीं / जवाब और खोज नहीं करेगी", color = Color(0xFFFF6B6B), fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 6.dp))
            OutlinedButton(onSettings) { Text("Settings खोलो और Key डालो") }
        }
        Box(Modifier.weight(1f).fillMaxWidth()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { toggleVoice(ctx) },
            contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val c = center; val R = min(size.width, size.height) * 0.30f
                val lvl = max(VoiceState.level, if (VoiceState.speaking) 0.55f + 0.35f * sin(orbit * 9f) else 0f)
                val k = pulse * (if (on) 1f + lvl * 0.28f else 0.85f)
                drawCircle(Brush.radialGradient(listOf(red.copy(.45f), Color.Transparent), c, R * 1.9f), R * 1.9f, c)
                dots.forEach { (a0, th, s) ->                                   // teal particle sphere
                    val a = a0 + orbit * (0.4f + s * 0.8f)
                    val x = sin(th) * cos(a); val z = sin(th) * sin(a); val y = cos(th)
                    val d = (z + 1f) / 2f
                    drawCircle(teal.copy(alpha = 0.25f + 0.65f * d), 1.4f + 1.8f * d, Offset(c.x + x * R * k, c.y + y * R * k))
                }
                if (on) for (b in 0 until 5) {                                  // crackling energy
                    val ang = b * 1.2566f + spin * 0.03f
                    var p0 = Offset(c.x + cos(ang) * R * k, c.y + sin(ang) * R * k)
                    for (j in 1..4) {
                        val r = R * k + j * R * .12f; val off = sin(orbit * 11f + b * 3f + j * 2f) * R * .09f
                        val p1 = Offset(c.x + cos(ang) * r - sin(ang) * off, c.y + sin(ang) * r + cos(ang) * off)
                        drawLine(Color.White.copy(alpha = .3f + .5f * lvl), p0, p1, 2f); p0 = p1
                    }
                }
                for (i in 0..3) rotate(spin * (if (i % 2 == 0) 1f else -1.3f) + i * 45f, c) {   // red orbital rings
                    drawOval(red.copy(alpha = if (on) .9f else .5f), Offset(c.x - R * .55f, c.y - R * (0.35f + i * .12f)),
                        Size(R * 1.1f, R * (0.7f + i * .24f)), style = Stroke(2.5f))
                }
                val cr = R * .5f * pulse * (1f + lvl * .5f)                     // glowing core
                drawCircle(Brush.radialGradient(listOf(Color.White, red, Color.Transparent), c, cr), cr, c)
                val baseY = c.y + R * 1.75f; val n = 41                          // voice waveform
                for (i in 0 until n) {
                    val env = 1f - abs(i - n / 2f) / (n / 2f)
                    val h = 4f + R * 0.55f * env * (if (on) (0.15f + lvl) * (0.6f + 0.4f * sin(orbit * 6f + i * .7f)).absoluteValue else 0.05f)
                    val x = c.x - R * 1.1f + i * (R * 2.2f / n)
                    drawLine(red, Offset(x, baseY - h), Offset(x, baseY + h), 5f)
                }
            }
            if (!on) Text("▶ TAP TO START", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        }
        Text(VoiceState.line.ifBlank { if (on) "" else "एक टैप: MYRA लगातार बात करेगी, किसी भी ऐप में। बंद करने के लिए फिर टैप।" },
            color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(8.dp))
    }
}
