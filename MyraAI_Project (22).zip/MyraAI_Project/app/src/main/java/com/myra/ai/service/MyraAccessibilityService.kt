package com.myra.ai.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.myra.ai.overlay.OverlayManager

/** Phone Control: tap by text, type, swipe, back/home/recents/lock, copy/paste, open apps. */
class MyraAccessibilityService : AccessibilityService() {
    companion object { var instance: MyraAccessibilityService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun global(a: String): Boolean {
        val id = when (a) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
            else -> return false
        }
        return performGlobalAction(id)
    }

    fun lock() = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    fun copy(): Boolean = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.performAction(AccessibilityNodeInfo.ACTION_COPY) ?: false
    fun paste(): Boolean = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.performAction(AccessibilityNodeInfo.ACTION_PASTE) ?: false

    /** Taps the first clickable element whose text / description contains [text]. */
    fun clickText(text: String): Boolean {
        val nodes = rootInActiveWindow?.findAccessibilityNodeInfosByText(text) ?: return false
        for (node in nodes) {
            var n: AccessibilityNodeInfo? = node
            while (n != null && !n.isClickable) n = n.parent
            if (n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
        }
        return false
    }

    private fun editable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) editable(n.getChild(i))?.let { return it }
        return null
    }

    /** Types into the focused input (or the first input on screen), adding to what is already written. */
    fun typeInto(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: editable(root) ?: return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val old = if (n.isShowingHintText) "" else n.text?.toString().orEmpty()
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    /** Finger swipe in the given direction (up / down / left / right). Touch Guard lets it through. */
    fun swipe(dir: String): Boolean {
        val w = resources.displayMetrics.widthPixels.toFloat(); val h = resources.displayMetrics.heightPixels.toFloat()
        val (x0, y0, x1, y1) = when (dir) {
            "up" -> listOf(w / 2, h * 0.72f, w / 2, h * 0.28f)
            "down" -> listOf(w / 2, h * 0.28f, w / 2, h * 0.72f)
            "left" -> listOf(w * 0.8f, h / 2, w * 0.2f, h / 2)
            "right" -> listOf(w * 0.2f, h / 2, w * 0.8f, h / 2)
            else -> return false
        }
        val path = Path().apply { moveTo(x0, y0); lineTo(x1, y1) }
        OverlayManager.guardTouchable(false)
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { OverlayManager.guardTouchable(true) }
                override fun onCancelled(g: GestureDescription?) { OverlayManager.guardTouchable(true) }
            }, null)
        if (!ok) OverlayManager.guardTouchable(true)
        return ok
    }

    private var nodes: List<AccessibilityNodeInfo> = emptyList()

    fun currentPkg(): String = rootInActiveWindow?.packageName?.toString().orEmpty()

    /** Numbered list of what is on screen (for the AI agent). */
    fun dumpScreen(): String {
        val out = ArrayList<AccessibilityNodeInfo>(); val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || out.size >= 70 || d > 25) return
            val label = (n.text ?: n.contentDescription ?: n.hintText)?.toString()?.take(40).orEmpty()
            val kind = if (n.isEditable) "edit" else if (n.isClickable) "btn" else ""
            if (n.isVisibleToUser && (label.isNotBlank() || kind == "edit")) { out.add(n); sb.append("${out.size - 1}: \"$label\" $kind\n") }
            for (i in 0 until n.childCount) walk(n.getChild(i), d + 1)
        }
        walk(rootInActiveWindow, 0); nodes = out
        return sb.toString().ifBlank { "(स्क्रीन खाली / पढ़ी नहीं जा सकी)" }
    }

    fun tapNode(i: Int): Boolean {
        var n: AccessibilityNodeInfo? = nodes.getOrNull(i)
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    fun typeNode(i: Int, text: String): Boolean {
        val n = nodes.getOrNull(i) ?: return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS); n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        val b = Bundle(); b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    /** Presses Enter / Search on the keyboard of the focused field (Android 11+). */
    fun enter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun openApp(ctx: Context, pkg: String) {
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
