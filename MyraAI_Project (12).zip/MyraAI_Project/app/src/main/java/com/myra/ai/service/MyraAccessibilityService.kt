package com.myra.ai.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Phone Control / Automation base: back, home, recents, open app, tap by text. */
class MyraAccessibilityService : AccessibilityService() {
    companion object { var instance: MyraAccessibilityService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)

    fun clickText(text: String): Boolean =
        rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.firstOrNull()
            ?.let { var n: android.view.accessibility.AccessibilityNodeInfo? = it
                while (n != null && !n.isClickable) n = n.parent
                n?.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK) } ?: false

    /** Types text into the currently focused input (e.g. a search box). */
    fun typeInto(text: String): Boolean {
        val n = rootInActiveWindow?.findFocus(android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = android.os.Bundle()
        b.putCharSequence(android.view.accessibility.AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun lock() = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    fun copy(): Boolean = rootInActiveWindow?.findFocus(android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT)
        ?.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_COPY) ?: false
    fun paste(): Boolean = rootInActiveWindow?.findFocus(android.view.accessibility.AccessibilityNodeInfo.FOCUS_INPUT)
        ?.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_PASTE) ?: false

    fun openApp(ctx: Context, pkg: String) {
        ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }
}
