package com.myra.ai.ai

import android.content.Context
import com.myra.ai.data.Store
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * MYRA's brain with memory: remembers the recent conversation + saved facts (Memory panel, Profile),
 * and can think with Gemini or ChatGPT (OpenAI). Live-web questions always go through Gemini search.
 */
object Brain {
    private val client = OkHttpClient()
    private val bg = CoroutineScope(Dispatchers.IO + SupervisorJob())
    @Volatile private var busy = false
    private const val BASE = "तुम MYRA हो, यूज़र की स्मार्ट हिंदी वॉइस असिस्टेंट। यूज़र को 'बॉस' बोलो। " +
        "जवाब सिर्फ़ 1-2 छोटे वाक्यों में दो (कोड या लिस्ट माँगने पर ज़्यादा)। पिछली बातचीत और नीचे याद की हुई बातें हमेशा ध्यान में रखो।"

    private fun system(s: Store): String {
        val mem = s.memories()
        return BASE +
            (if (s.get("p_name").isNotBlank()) "\nयूज़र का नाम: ${s.get("p_name")}" else "") +
            (if (mem.isNotEmpty()) "\nयाद की हुई बातें:\n" + mem.takeLast(60).joinToString("\n") { "- $it" } else "")
    }

    suspend fun answer(ctx: Context, q: String): String {
        val s = Store(ctx)
        // "याद रखो कि ..." saves a fact, no AI call needed
        Regex("(?:याद रखो|याद रखना|याद रख|remember that|remember)\\s*(?:कि|that)?\\s*(.+)", RegexOption.IGNORE_CASE)
            .find(q)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }
            ?.let { s.addMemory(it); return "ठीक है बॉस, याद रखूँगी।" }
        val low = q.lowercase()
        if (listOf("सब भूल जाओ", "सब कुछ भूल जाओ", "forget everything").any { low.contains(it) }) {
            s.clearMemories(); s.clearChat(); return "ठीक है बॉस, सब भूल गई।"
        }
        val key = s.get("gemini_key"); val hist = s.chat()
        val ans = when {
            GeminiTools.needsSearch(q) -> GeminiTools.webSearch(key, system(s) + "\n\n" + q)
            s.get("brain") == "openai" -> openai(s, system(s), hist, q)
            else -> gemini(key, system(s), hist, q)
        }
        if (!(ans.startsWith("Error") || ans.startsWith("Network") || ans.startsWith("पहले Settings"))) {
            s.addChat(q, ans)
            if (q.length >= 12 && !GeminiTools.needsSearch(q)) bg.launch { learn(s, q, ans) }   // auto-remember in background
        }
        return ans
    }

    private suspend fun gemini(key: String, sys: String, hist: List<Pair<String, String>>, q: String): String {
        val contents = JSONArray()
        (hist + ("user" to q)).forEach { (r, t) ->
            contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        return GeminiClient.generate(key, JSONObject().put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))))
    }

    private suspend fun openai(s: Store, sys: String, hist: List<Pair<String, String>>, q: String): String = withContext(Dispatchers.IO) {
        val key = s.get("openai_key").trim()
        if (key.isBlank()) return@withContext "पहले Settings में OpenAI (ChatGPT) API Key डालो बॉस।"
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
        hist.forEach { (r, t) -> msgs.put(JSONObject().put("role", if (r == "model") "assistant" else "user").put("content", t)) }
        msgs.put(JSONObject().put("role", "user").put("content", q))
        val body = JSONObject().put("model", s.get("openai_model").trim().ifBlank { "gpt-5.4-mini" }).put("messages", msgs)
        val req = Request.Builder().url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        runCatching {
            client.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                if (!r.isSuccessful) return@runCatching "Error ${r.code}: " +
                    runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault("")
                JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
        }.getOrElse { "Network error: ${it.message}" }
    }

    /** Asks the brain what is worth remembering long-term and saves new facts (no passwords / OTP / card numbers). */
    private suspend fun think(s: Store, prompt: String): String =
        if (s.get("brain") == "openai" && s.get("openai_key").isNotBlank()) openai(s, "तुम सिर्फ़ JSON array देते हो।", emptyList(), prompt)
        else GeminiClient.raw(s.get("gemini_key"), prompt)

    private fun jsonList(raw: String): JSONArray? =
        runCatching { JSONArray(raw.substring(raw.indexOf('['), raw.lastIndexOf(']') + 1)) }.getOrNull()

    private suspend fun learn(s: Store, q: String, ans: String) {
        val prompt = "नीचे यूज़र और असिस्टेंट की बातचीत है। यूज़र के बारे में सिर्फ़ वो पक्की बातें निकालो जो लंबे समय तक काम आएँ " +
            "(नाम, रिश्ते, पसंद-नापसंद, आदतें, काम/पढ़ाई, शहर, योजनाएँ, ज़रूरी तारीख़ें)। पासवर्ड, OTP, बैंक/कार्ड/आधार नंबर कभी मत निकालो। " +
            "हर बात एक छोटे हिंदी वाक्य में। सिर्फ़ JSON array दो, जैसे [\"यूज़र का नाम नितिन है\"]। कुछ न मिले तो []।\n\nयूज़र: $q\nअसिस्टेंट: $ans"
        val a = jsonList(think(s, prompt)) ?: return
        val have = s.memories().map { it.lowercase() }
        for (i in 0 until a.length()) {
            val f = a.optString(i).trim()
            if (f.length in 4..160 && have.none { it == f.lowercase() }) s.addMemory(f)
        }
        if (s.memories().size > 100) consolidate(s)
    }

    /** Too many facts? Merge duplicates / outdated ones into a short list. */
    private suspend fun consolidate(s: Store) {
        if (busy) return
        busy = true
        try {
            val prompt = "नीचे यूज़र के बारे में याद की हुई बातें हैं। दोहराव हटाओ, पुरानी और नई बात में टकराव हो तो नई रखो, " +
                "और ज़्यादा से ज़्यादा 60 छोटे वाक्यों में समेटो। सिर्फ़ JSON array दो।\n" + s.memories().joinToString("\n") { "- $it" }
            val a = jsonList(think(s, prompt)) ?: return
            if (a.length() in 5..120) { s.clearMemories(); for (i in 0 until a.length()) s.addMemory(a.optString(i)) }
        } finally { busy = false }
    }
}
