MYRA - Part 1 (drop-in files). Package: com.myra.ai  (अगर आपका package अलग है तो हर file की पहली line "package ..." बदल दो)

1) इन files को app/src/main/java/com/myra/ai/ में copy करो (ui, ai, voice, service folders)
   और res/xml/accessibility_config.xml को app/src/main/res/xml/ में।

2) AndroidManifest.xml में <manifest> के अंदर permissions:
   <uses-permission android:name="android.permission.INTERNET"/>
   <uses-permission android:name="android.permission.RECORD_AUDIO"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE"/>
   <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
   <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>

3) <application> के अंदर:
   <service android:name=".service.WakeWordService" android:foregroundServiceType="microphone" android:exported="false"/>
   <service android:name=".service.MyraAccessibilityService" android:exported="true"
       android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">
     <intent-filter><action android:name="android.accessibilityservice.AccessibilityService"/></intent-filter>
     <meta-data android:name="android.accessibilityservice" android:resource="@xml/accessibility_config"/>
   </service>

4) MainActivity में setContent { HomeScreen(onTile = { ... }) } लगाओ, और RECORD_AUDIO permission लेने के बाद
   startForegroundService(Intent(this, WakeWordService::class.java)) चलाओ।

5) Keys: SharedPreferences "myra" में gemini_key, eleven_key, voice_id save करो (Settings screen बाद में)।
