package com.myra.ai.ai

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.io.ByteArrayOutputStream

object GeminiTools {
    private val client = OkHttpClient()
    private fun url(k: String) = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$k"

    private suspend fun post(key: String, body: JSONObject): String = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder().url(url(key)).post(body.toString().toRequestBody("application/json".toMediaType())).build()
            client.newCall(req).execute().use { r ->
                val s = r.body?.string().orEmpty()
                if (!r.isSuccessful) return@runCatching "Error ${r.code}"
                JSONObject(s).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                    .getJSONArray("parts").getJSONObject(0).getString("text")
            }
        }.getOrElse { "Network error" }
    }

    private fun parts(vararg p: JSONObject) = JSONArray().put(JSONObject().put("parts", JSONArray(p.toList())))
    private fun text(t: String) = JSONObject().put("text", t)

    /** Live internet research via Gemini Google Search grounding. */
    suspend fun webSearch(key: String, q: String) = post(key, JSONObject()
        .put("contents", parts(text("हिंदी में छोटा जवाब दो: $q")))
        .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject()))))

    /** Live Vision / image understanding. */
    suspend fun vision(key: String, bmp: Bitmap, q: String): String {
        val out = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        val img = JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg")
            .put("data", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)))
        return post(key, JSONObject().put("contents", parts(img, text("हिंदी में बताओ: $q"))))
    }
}
