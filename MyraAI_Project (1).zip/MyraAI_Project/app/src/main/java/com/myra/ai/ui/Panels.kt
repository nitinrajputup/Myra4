package com.myra.ai.ui

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.content.Intent
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.myra.ai.service.WakeWordService
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.myra.ai.ai.GeminiClient
import com.myra.ai.ai.GeminiTools
import com.myra.ai.data.Store
import kotlinx.coroutines.launch

/** Use in MainActivity:  setContent { MyraRoot() } */
@Composable
fun MyraRoot() {
    val ctx = LocalContext.current; val store = remember { Store(ctx) }
    var screen by remember { mutableStateOf("Home") }
    if (screen == "Home") AnimatedHome(onTile = { screen = it }) else
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            TextButton({ screen = "Home" }) { Text("← Home", color = Purple) }
            when (screen) {
                "AI Chat", "Voice Assistant" -> Ask(store, "Gemini से पूछो") { k, q -> GeminiClient.ask(k, q) }
                "Web Search" -> Ask(store, "Internet पर खोजो") { k, q -> GeminiTools.webSearch(k, q) }
                "Live Vision" -> Vision(store)
                "Memory" -> MemoryPanel(store)
                "Automation" -> HistoryPanel(store)
                else -> SettingsPanel(store)   // Phone Control / More Tools -> settings & permissions
            }
        }
}

@Composable
fun Ask(store: Store, hint: String, call: suspend (String, String) -> String) {
    var q by remember { mutableStateOf("") }; var a by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text(hint) })
    Button({ scope.launch { a = "सोच रही हूँ..."; a = call(store.get("gemini_key"), q); store.addHistory(q) } }) { Text("भेजो") }
    Text(a, color = Color.White, modifier = Modifier.padding(top = 12.dp))
}

@Composable
fun Vision(store: Store) {
    var q by remember { mutableStateOf("यह क्या है?") }; var a by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp: Bitmap? ->
        if (bmp != null) scope.launch { a = "देख रही हूँ..."; a = GeminiTools.vision(store.get("gemini_key"), bmp, q) }
    }
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("सवाल") })
    Button({ cam.launch(null) }) { Text("📷 फोटो लो और पूछो") }
    Text(a, color = Color.White, modifier = Modifier.padding(top = 12.dp))
}

@Composable
fun MemoryPanel(store: Store) {
    var items by remember { mutableStateOf(store.memories()) }; var t by remember { mutableStateOf("") }
    OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth(), label = { Text("कुछ याद रखवाओ") })
    Row { Button({ if (t.isNotBlank()) { store.addMemory(t); items = store.memories(); t = "" } }) { Text("Save") }
        Spacer(Modifier.width(8.dp)); OutlinedButton({ store.clearMemories(); items = emptyList() }) { Text("Clear") } }
    LazyColumn { items(items) { Text("• $it", color = Color.White, modifier = Modifier.padding(vertical = 4.dp)) } }
}

@Composable
fun HistoryPanel(store: Store) =
    LazyColumn { items(store.history().reversed()) { Text("• $it", color = Color.White, modifier = Modifier.padding(vertical = 4.dp)) } }

@Composable
fun SettingsPanel(store: Store) {
    val ctx = LocalContext.current
    var wake by remember { mutableStateOf(store.get("wake") != "off") }
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Background Wake Word (Hello Myra)", color = Color.White, modifier = Modifier.weight(1f))
        Switch(wake, { on ->
            wake = on; store.set("wake", if (on) "on" else "off")
            val i = Intent(ctx, WakeWordService::class.java)
            if (on) ctx.startForegroundService(i) else ctx.stopService(i)
        })
    }
    val keys = listOf("gemini_key" to "Gemini API Key", "eleven_key" to "ElevenLabs API Key", "voice_id" to "ElevenLabs Voice ID")
    keys.forEach { (k, label) ->
        var v by remember { mutableStateOf(store.get(k)) }
        OutlinedTextField(v, { v = it; store.set(k, it) }, Modifier.fillMaxWidth().padding(bottom = 8.dp), label = { Text(label) }, singleLine = true)
    }
    Text("Phone Control के लिए: Settings → Accessibility → MYRA ON करो।", color = Color.White)
}
