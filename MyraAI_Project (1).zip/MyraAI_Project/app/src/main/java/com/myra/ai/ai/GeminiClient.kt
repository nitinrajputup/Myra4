package com.myra.ai.ai

import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*

object GeminiClient {
    private val client = OkHttpClient()
    private const val SYSTEM = "तुम MYRA हो, एक स्मार्ट हिंदी वॉइस असिस्टेंट। यूज़र को 'बॉस' बोलो। जवाब छोटा रखो।\n"

    /** Retries on 503 (high demand). */
    suspend fun ask(apiKey: String, prompt: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts",
            JSONArray().put(JSONObject().put("text", SYSTEM + prompt)))))
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        for (attempt in 1..3) {
            try {
                client.newCall(req).execute().use { r ->
                    val s = r.body?.string().orEmpty()
                    if (r.isSuccessful) return@withContext JSONObject(s).getJSONArray("candidates")
                        .getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                        .getJSONObject(0).getString("text")
                    if (r.code != 503) return@withContext "Error ${r.code}"
                }
            } catch (e: Exception) { if (attempt == 3) return@withContext "Network error" }
            delay(1000L * attempt)
        }
        "Gemini अभी busy है बॉस, थोड़ी देर में try करो।"
    }
}
