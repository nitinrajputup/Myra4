package com.myra.ai.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.sin

/** Charging animation: pulsing rings, battery filling up to the current %, lightning bolt. */
class ChargingView(ctx: Context, private val pct: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f

    override fun onDraw(c: Canvas) {
        t += 0.05f
        val w = width.toFloat(); val h = height.toFloat(); val cx = w / 2f; val cy = h * 0.42f
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f
        for (i in 0..2) {                                   // expanding rings
            val ph = (t * 0.5f + i / 3f) % 1f
            p.color = Color.argb(((1f - ph) * 170).toInt(), 60, 255, 130)
            c.drawCircle(cx, cy, w * 0.20f + ph * w * 0.28f, p)
        }
        val bw = w * 0.34f; val bh = h * 0.34f; val left = cx - bw / 2f; val top = cy - bh / 2f
        p.strokeWidth = 6f; p.color = Color.rgb(60, 255, 130)
        c.drawRoundRect(left, top, left + bw, top + bh, 24f, 24f, p)
        p.style = Paint.Style.FILL
        c.drawRect(cx - bw * 0.2f, top - 14f, cx + bw * 0.2f, top, p)   // battery cap
        val fillTop = top + 10f + (bh - 20f) * (1f - pct / 100f)
        p.color = Color.argb((150 + 70 * sin(t * 2f)).toInt(), 40, 230, 110)
        c.drawRoundRect(left + 10f, fillTop, left + bw - 10f, top + bh - 10f, 14f, 14f, p)
        val bolt = Path().apply {                           // lightning bolt
            moveTo(cx + bw * 0.06f, top + bh * 0.16f); lineTo(cx - bw * 0.16f, top + bh * 0.56f)
            lineTo(cx, top + bh * 0.56f); lineTo(cx - bw * 0.06f, top + bh * 0.86f)
            lineTo(cx + bw * 0.18f, top + bh * 0.44f); lineTo(cx, top + bh * 0.44f); close()
        }
        p.color = Color.WHITE; c.drawPath(bolt, p)
        p.textSize = w * 0.13f; p.textAlign = Paint.Align.CENTER
        c.drawText("$pct%", cx, top + bh + w * 0.17f, p)
        postInvalidateOnAnimation()
    }
}
