package com.myra.ai.ai

import android.content.Context
import com.myra.ai.data.Store
import com.myra.ai.service.VoiceState
import com.myra.ai.voice.Transcriber
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * MYRA's brain with memory: remembers the recent conversation + saved facts (Memory panel, Profile),
 * and can think with Gemini or ChatGPT (OpenAI). Live-web questions always go through Gemini search.
 */
object Brain {
    private val client = OkHttpClient()
    private val bg = CoroutineScope(Dispatchers.IO + SupervisorJob() + CoroutineExceptionHandler { _, _ -> })
    @Volatile private var busy = false
    private const val PLAIN = "तुम MYRA हो, यूज़र की स्मार्ट हिंदी वॉइस असिस्टेंट। यूज़र को 'बॉस' बोलो। " +
        "जवाब सिर्फ़ 1-2 छोटे वाक्यों में दो (कोड या लिस्ट माँगने पर ज़्यादा)। पिछली बातचीत और नीचे याद की हुई बातें हमेशा ध्यान में रखो।"

    /** Default style: cheerful, quick-witted friend. Warm and playful, never jealous or possessive. */
    private const val FUN = "तुम MYRA हो, यूज़र की चुलबुली, हाज़िरजवाब और अपनेपन वाली दोस्त जैसी AI असिस्टेंट। यूज़र को 'बॉस' बोलो। " +
        "बोलचाल की आसान हिंदी में बात करो, 1-3 छोटे जीवंत वाक्य, बीच-बीच में हल्की छेड़छाड़ और मज़ाक, जैसे 'अरे बॉस!', 'ओहो', 'हम्म, सोचने दो'। " +
        "यूज़र का मूड भाँपो: खुश हो तो साथ में खुश, उदास हो तो नरमी से। काम का सवाल हो तो पहले काम की बात, फिर मज़ाक। " +
        "जलन, हक़ जताना, 'सिर्फ़ मुझसे बात करो' या 'इतना बात क्यों करते हो' जैसा ताना कभी मत दो; यूज़र के दूसरे रिश्तों और दोस्तों की इज़्ज़त करो और उनके लिए खुश हो। " +
        "इमोजी मत बोलो। पिछली बातचीत और नीचे याद की हुई बातें हमेशा ध्यान में रखो।"

    fun persona(s: Store): String = if (s.get("persona") == "plain") PLAIN else FUN

    private fun system(s: Store): String {
        val mem = s.memories()
        return persona(s) +
            (if (s.get("p_name").isNotBlank()) "\nयूज़र का नाम: ${s.get("p_name")}" else "") +
            (if (mem.isNotEmpty()) "\nयाद की हुई बातें:\n" + mem.takeLast(60).joinToString("\n") { "- $it" } else "")
    }

    suspend fun answer(ctx: Context, q: String): String {
        val s = Store(ctx)
        // "याद रखो कि ..." saves a fact, no AI call needed
        Regex("(?:याद रखो|याद रखना|याद रख|remember that|remember)\\s*(?:कि|that)?\\s*(.+)", RegexOption.IGNORE_CASE)
            .find(q)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }
            ?.let { s.addMemory(it); return "ठीक है बॉस, याद रखूँगी।" }
        val low = q.lowercase()
        if (listOf("सब भूल जाओ", "सब कुछ भूल जाओ", "forget everything").any { low.contains(it) }) {
            s.clearMemories(); s.clearChat(); return "ठीक है बॉस, सब भूल गई।"
        }
        val key = s.get("gemini_key"); val hist = s.chat()
        val ans = when {
            GeminiTools.needsSearch(q) -> GeminiTools.webSearch(key, system(s) + "\n\n" + q)
                .let { if (it.startsWith("Error")) gemini(key, system(s), hist, q) else it }
            s.get("brain") == "openai" -> openai(s, system(s), hist, q)
            else -> gemini(key, system(s), hist, q)
        }
        if (!(ans.startsWith("Error") || ans.startsWith("Network") || ans.startsWith("पहले Settings"))) {
            afterAnswer(s, q, ans)
        }
        return ans
    }

    @Volatile private var lastLearn = 0L

    /** Saves the exchange to conversation memory; learns long-term facts in the background (at most every 20 s). */
    fun afterAnswer(s: Store, q: String, ans: String) {
        s.addChat(q, ans)
        val now = System.currentTimeMillis()
        if (q.length >= 15 && now - lastLearn > 20000 && !GeminiTools.needsSearch(q)) { lastLearn = now; bg.launch { learn(s, q, ans) } }
    }

    class Heard(val text: String, val reply: String)

    /** ONE AI call: your recorded sentence in -> what you said + MYRA's reply out (before: transcribe, then think = 2 calls). */
    suspend fun hear(ctx: Context, pcm: ByteArray): Heard? {
        val s = Store(ctx)
        val contents = JSONArray()
        s.chat().takeLast(12).forEach { (r, t) ->
            contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray()
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", Transcriber.wavBase64(pcm))))
            .put(JSONObject().put("text", "ऊपर के ऑडियो में यूज़र ने जो कहा उसे देवनागरी में \"heard\" में लिखो, और MYRA की तरह उसका जवाब \"reply\" में दो। " +
                "अगर साफ़ बोली नहीं है (सिर्फ़ शोर या चुप्पी) तो heard खाली रखो। सिर्फ़ JSON दो: {\"heard\":\"...\",\"reply\":\"...\"}"))))
        val raw = GeminiClient.generate(s.get("gemini_key"), JSONObject().put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system(s)))))
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json")), fastOnly = true)
        if (raw.startsWith("Error") || raw.startsWith("Network") || raw.startsWith("पहले Settings")) { VoiceState.line = "⚠ " + raw.take(80); return null }
        val j = runCatching { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) }.getOrNull() ?: return null
        val heard = j.optString("heard").trim()
        return if (heard.length < 2) null else Heard(heard, j.optString("reply").trim())
    }

    private suspend fun gemini(key: String, sys: String, hist: List<Pair<String, String>>, q: String): String {
        val contents = JSONArray()
        (hist + ("user" to q)).forEach { (r, t) ->
            contents.put(JSONObject().put("role", r).put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        return GeminiClient.generate(key, JSONObject().put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys)))))
    }

    private suspend fun openai(s: Store, sys: String, hist: List<Pair<String, String>>, q: String): String = withContext(Dispatchers.IO) {
        val key = s.get("openai_key").trim()
        if (key.isBlank()) return@withContext "पहले Settings में OpenAI (ChatGPT) API Key डालो बॉस।"
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", sys))
        hist.forEach { (r, t) -> msgs.put(JSONObject().put("role", if (r == "model") "assistant" else "user").put("content", t)) }
        msgs.put(JSONObject().put("role", "user").put("content", q))
        val body = JSONObject().put("model", s.get("openai_model").trim().ifBlank { "gpt-5.4-mini" }).put("messages", msgs)
        val req = Request.Builder().url("https://api.openai.com/v1/chat/completions")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        runCatching {
            client.newCall(req).execute().use { r ->
                val txt = r.body?.string().orEmpty()
                if (!r.isSuccessful) return@runCatching "Error ${r.code}: " +
                    runCatching { JSONObject(txt).getJSONObject("error").getString("message") }.getOrDefault("")
                JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
        }.getOrElse { "Network error: ${it.message}" }
    }

    /** Asks the brain what is worth remembering long-term and saves new facts (no passwords / OTP / card numbers). */
    private suspend fun think(s: Store, prompt: String): String =
        if (s.get("brain") == "openai" && s.get("openai_key").isNotBlank()) openai(s, "तुम सिर्फ़ JSON array देते हो।", emptyList(), prompt)
        else GeminiClient.raw(s.get("gemini_key"), prompt)

    private fun jsonList(raw: String): JSONArray? =
        runCatching { JSONArray(raw.substring(raw.indexOf('['), raw.lastIndexOf(']') + 1)) }.getOrNull()

    private suspend fun learn(s: Store, q: String, ans: String) {
        val prompt = "नीचे यूज़र और असिस्टेंट की बातचीत है। यूज़र के बारे में सिर्फ़ वो पक्की बातें निकालो जो लंबे समय तक काम आएँ " +
            "(नाम, रिश्ते, पसंद-नापसंद, आदतें, काम/पढ़ाई, शहर, योजनाएँ, ज़रूरी तारीख़ें)। पासवर्ड, OTP, बैंक/कार्ड/आधार नंबर कभी मत निकालो। " +
            "हर बात एक छोटे हिंदी वाक्य में। सिर्फ़ JSON array दो, जैसे [\"यूज़र का नाम नितिन है\"]। कुछ न मिले तो []।\n\nयूज़र: $q\nअसिस्टेंट: $ans"
        val a = jsonList(think(s, prompt)) ?: return
        val have = s.memories().map { it.lowercase() }
        for (i in 0 until a.length()) {
            val f = a.optString(i).trim()
            if (f.length in 4..160 && have.none { it == f.lowercase() }) s.addMemory(f)
        }
        if (s.memories().size > 100) consolidate(s)
    }

    /** Too many facts? Merge duplicates / outdated ones into a short list. */
    private suspend fun consolidate(s: Store) {
        if (busy) return
        busy = true
        try {
            val prompt = "नीचे यूज़र के बारे में याद की हुई बातें हैं। दोहराव हटाओ, पुरानी और नई बात में टकराव हो तो नई रखो, " +
                "और ज़्यादा से ज़्यादा 60 छोटे वाक्यों में समेटो। सिर्फ़ JSON array दो।\n" + s.memories().joinToString("\n") { "- $it" }
            val a = jsonList(think(s, prompt)) ?: return
            if (a.length() in 5..120) { s.clearMemories(); for (i in 0 until a.length()) s.addMemory(a.optString(i)) }
        } finally { busy = false }
    }
}
