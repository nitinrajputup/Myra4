package com.myra.ai.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

object ThemeState {
    var primary by mutableStateOf(Color(0xFFB04CFF))
    var secondary by mutableStateOf(Color(0xFF3D8BFF))
    var bg by mutableStateOf(Color(0xFF05030F))
}

class MyraThemeDef(val name: String, val p: Long, val s: Long, val bg: Long)

val themeList = listOf(
    MyraThemeDef("Neon Purple", 0xFFB04CFF, 0xFF3D8BFF, 0xFF05030F),
    MyraThemeDef("Ocean Blue", 0xFF2D9CFF, 0xFF00E5FF, 0xFF020A18),
    MyraThemeDef("Cyber Green", 0xFF2BD96B, 0xFF00E5B0, 0xFF021208),
    MyraThemeDef("Sunset Orange", 0xFFFF7A18, 0xFFFFB347, 0xFF120803),
    MyraThemeDef("Rose Pink", 0xFFFF4D9D, 0xFFFF8FC7, 0xFF14030C),
    MyraThemeDef("Gold Luxury", 0xFFFFC83D, 0xFFFF9F1C, 0xFF0E0A02),
    MyraThemeDef("Crimson Red", 0xFFFF3D5A, 0xFFFF7A7A, 0xFF140306),
    MyraThemeDef("Aqua Mint", 0xFF00E5C3, 0xFF6BFFE0, 0xFF011311),
    MyraThemeDef("Violet Night", 0xFF8A5CFF, 0xFFD36BFF, 0xFF08041A),
    MyraThemeDef("Lava", 0xFFFF5A1F, 0xFFFF2D55, 0xFF100401),
    MyraThemeDef("Ice White", 0xFF9AD8FF, 0xFFE0F4FF, 0xFF07101A),
    MyraThemeDef("Matrix", 0xFF00FF41, 0xFF00B82E, 0xFF000A02),
    MyraThemeDef("Royal Blue", 0xFF4D6BFF, 0xFF8AA0FF, 0xFF030618),
    MyraThemeDef("Candy", 0xFFFF7AD9, 0xFF7AE0FF, 0xFF0F0412),
    MyraThemeDef("Midnight Teal", 0xFF19C2C2, 0xFF3D8BFF, 0xFF030D12)
)

fun applyTheme(p: Long, s: Long, bg: Long) {
    ThemeState.primary = Color(p); ThemeState.secondary = Color(s); ThemeState.bg = Color(bg)
}

fun hex(h: String): Long = 0xFF000000L or h.trim().removePrefix("#").toLong(16)

fun loadTheme(saved: String) {
    if (saved.startsWith("custom:")) {
        val x = saved.removePrefix("custom:").split(":")
        runCatching { applyTheme(hex(x[0]), hex(x[1]), hex(x[2])) }
    } else themeList.firstOrNull { it.name == saved }?.let { applyTheme(it.p, it.s, it.bg) }
}
