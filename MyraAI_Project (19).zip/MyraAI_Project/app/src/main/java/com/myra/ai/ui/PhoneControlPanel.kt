package com.myra.ai.ui

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.myra.ai.data.Store
import com.myra.ai.service.MyraAccessibilityService
import com.myra.ai.task.TaskRunner
import com.myra.ai.voice.Speaker
import kotlinx.coroutines.launch

/** Phone Control: type a command, or pick any installed app from the list and open it. */
@Composable
fun PhoneControlPanel(store: Store) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val speaker = remember { Speaker(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    var cmd by remember { mutableStateOf("") }; var out by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("") }
    val apps = remember {
        val pm = ctx.packageManager
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }.sortedBy { it.first.lowercase() }
    }
    Column {
        Text(if (MyraAccessibilityService.instance != null) "✅ Accessibility चालू" else "❌ Accessibility बंद (tap / call के लिए चालू करो)", color = Color.White)
        OutlinedButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }) { Text("Accessibility खोलो") }
        F("कमांड लिखो (जैसे: WhatsApp खोलो)", cmd) { cmd = it }
        Button({
            scope.launch {
                val p = TaskRunner.parseSmart(ctx, cmd)
                if (p == null) out = "यह फ़ोन कमांड समझ नहीं आई"
                else { out = "चल रहा है..."; out = TaskRunner.runText(ctx, p) { speaker.sayWait(it) } }
                speaker.say(out)
            }
        }) { Text("चलाओ") }
        Text(out, color = Color.White)
        F("ऐप खोजो", filter) { filter = it }
        LazyColumn(Modifier.height(320.dp)) {
            items(apps.filter { it.first.contains(filter, true) }) { (label, pkg) ->
                Text(label, color = Color.White, modifier = Modifier.fillMaxWidth()
                    .clickable { ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) } }
                    .padding(vertical = 10.dp))
            }
        }
    }
}
