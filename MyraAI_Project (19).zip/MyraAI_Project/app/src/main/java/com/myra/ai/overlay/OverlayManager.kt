package com.myra.ai.overlay

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.myra.ai.data.Store
import android.widget.ProgressBar
import android.widget.TextView

/** Floating particle orb + task card drawn over every app (needs "Display over other apps"). */
object OverlayManager {
    private var wm: WindowManager? = null
    private var orb: ParticleView? = null
    private var card: View? = null
    private var chg: View? = null
    private val h = Handler(Looper.getMainLooper())
    private val hideCard = Runnable { removeCard() }

    private fun params(w: Int, hgt: Int, g: Int) = WindowManager.LayoutParams(w, hgt,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
        PixelFormat.TRANSLUCENT).apply { gravity = g }

    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun showOrb(ctx: Context) {
        val c = ctx.applicationContext
        if (orb != null || !Settings.canDrawOverlays(c)) return
        val w = c.getSystemService(WindowManager::class.java); wm = w
        val s = dp(c, 210)
        orb = runCatching { ParticleView(c).also { w.addView(it, params(s, s, Gravity.CENTER)) } }.getOrNull()
    }

    fun awake(on: Boolean) { orb?.awake = on }

    fun hideOrb() { orb?.let { runCatching { wm?.removeView(it) } }; orb = null; removeCard(); hideCharging(); guardOff() }

    /** steps = name + status (0 waiting, 1 done, 2 failed); state = 0 running, 1 completed, 2 failed. */
    fun task(ctx: Context, steps: List<Pair<String, Int>>, state: Int) {
        val c = ctx.applicationContext
        if (!Settings.canDrawOverlays(c)) return
        val w = wm ?: c.getSystemService(WindowManager::class.java).also { wm = it }
        removeCard()
        val done = steps.count { it.second == 1 }
        val box = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
            background = GradientDrawable().apply { cornerRadius = dp(c, 14).toFloat(); setColor(Color.argb(225, 20, 24, 40)) }
        }
        fun tv(t: String, sz: Float, col: Int, bold: Boolean = false) = TextView(c).apply {
            text = t; textSize = sz; setTextColor(col); if (bold) setTypeface(typeface, Typeface.BOLD)
        }
        box.addView(tv("✨ MYRA", 11f, Color.rgb(170, 130, 255), true))
        val head = when (state) {
            1 -> "✅ Task completed"
            2 -> "❌ Task failed"
            else -> "⏳ " + (steps.firstOrNull { it.second == 0 }?.first ?: "Working")
        }
        box.addView(tv(head, 15f, Color.WHITE, true))
        box.addView(tv("$done / ${steps.size} steps", 10f, Color.LTGRAY))
        box.addView(ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = steps.size; progress = done
            progressTintList = ColorStateList.valueOf(Color.rgb(140, 90, 255))
        })
        steps.forEach { (n, s) -> box.addView(tv((if (s == 1) "✅ " else if (s == 2) "❌ " else "⏳ ") + n, 12f, Color.WHITE)) }
        val lp = params(dp(c, 230), WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
            .apply { x = dp(c, 12); y = dp(c, 90) }
        runCatching { w.addView(box, lp); card = box }
        h.removeCallbacks(hideCard)
        if (state != 0) h.postDelayed(hideCard, 4000)
    }

    /** Charging animation in the centre of the screen for a few seconds. */
    fun charging(ctx: Context, pct: Int, ms: Long = 6000) {
        val c = ctx.applicationContext
        if (!Settings.canDrawOverlays(c)) return
        val w = wm ?: c.getSystemService(WindowManager::class.java).also { wm = it }
        hideCharging()
        runCatching { val v = ChargingView(c, pct); w.addView(v, params(dp(c, 260), dp(c, 320), Gravity.CENTER)); chg = v }
        h.postDelayed({ hideCharging() }, ms)
    }

    fun hideCharging() { chg?.let { runCatching { wm?.removeView(it) } }; chg = null }

    // ---- Touch Guard: while MYRA controls the phone, your accidental touches are blocked ----
    private var guard: FrameLayout? = null
    private var guardLp: WindowManager.LayoutParams? = null
    private val guardTimeout = Runnable { guardOff() }

    fun guardOn(ctx: Context) {
        val c = ctx.applicationContext
        if (guard != null || !Settings.canDrawOverlays(c) || Store(c).get("touchguard") == "off") return
        val w = wm ?: c.getSystemService(WindowManager::class.java).also { wm = it }
        val f = FrameLayout(c); f.setOnTouchListener { _, _ -> true }
        val banner = TextView(c).apply {
            text = "🛡 MYRA काम कर रही है — रोकने के लिए यहाँ 3 बार टैप करो"
            setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(210, 140, 0, 0)); setPadding(dp(c, 10), dp(c, 8), dp(c, 10), dp(c, 8))
        }
        var taps = 0; var last = 0L
        banner.setOnClickListener {
            val n = System.currentTimeMillis(); taps = if (n - last < 800) taps + 1 else 1; last = n
            if (taps >= 3) guardOff()
        }
        f.addView(banner, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT)
        if (runCatching { w.addView(f, lp) }.isFailure) return
        guard = f; guardLp = lp
        h.removeCallbacks(guardTimeout); h.postDelayed(guardTimeout, 60000)   // safety: never block touches for more than a minute
    }

    fun guardOff() { guard?.let { runCatching { wm?.removeView(it) } }; guard = null; guardLp = null; h.removeCallbacks(guardTimeout) }

    /** Lets MYRA's own swipe/tap gestures pass through the guard. */
    fun guardTouchable(on: Boolean) {
        val f = guard ?: return; val lp = guardLp ?: return
        lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv() else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        runCatching { wm?.updateViewLayout(f, lp) }
    }

    private fun removeCard() { card?.let { runCatching { wm?.removeView(it) } }; card = null }
}
