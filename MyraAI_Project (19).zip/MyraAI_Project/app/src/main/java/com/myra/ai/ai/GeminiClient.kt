package com.myra.ai.ai

import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*

object GeminiClient {
    private val client = OkHttpClient()
    // Auto order: fast first. 404/503/429 -> next model. The working one is remembered.
    private val models = listOf("gemini-3.5-flash-lite", "gemini-3.5-flash", "gemini-3.8-flash",
        "gemini-3-flash-preview", "gemini-2.5-flash-lite", "gemini-2.5-flash")
    private val plainOnly = mutableSetOf<String>()      // models that rejected the "thinking off" setting
    @Volatile private var good: String? = null
    /** Model chosen in Settings (Auto = blank). Tried first. */
    @Volatile var preferred: String = ""
        set(v) { field = v.trim(); good = null }
    private const val SYSTEM = "तुम MYRA हो, एक स्मार्ट हिंदी वॉइस असिस्टेंट। यूज़र को 'बॉस' बोलो। जवाब सिर्फ़ 1-2 छोटे वाक्यों में दो।\n"

    suspend fun ask(key: String, prompt: String): String = raw(key, SYSTEM + prompt)

    /** Plain prompt, no short-answer rule (resume, coding). */
    suspend fun raw(key: String, prompt: String): String = generate(key, JSONObject().put("contents",
        JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt))))))

    suspend fun generate(key: String, body: JSONObject, fastOnly: Boolean = false): String = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext "पहले Settings में Gemini API Key डालो बॉस।"
        var last = "Gemini error"
        val order = (listOf(if (fastOnly) "" else preferred).filter { it.isNotBlank() } +
            listOfNotNull(good).filter { !fastOnly || !it.contains("pro") } + models).distinct()
        for (m in order) {
            for (fast in listOf(true, false)) {
                if (fast && m in plainOnly) continue
                val b = if (fast) JSONObject(body.toString()).also { j ->
                    val gc = j.optJSONObject("generationConfig") ?: JSONObject()
                    j.put("generationConfig", gc.put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
                } else body
                val req = Request.Builder()
                    .url("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=${key.trim()}")
                    .post(b.toString().toRequestBody("application/json".toMediaType())).build()
                var retryPlain = false
                try {
                    client.newCall(req).execute().use { r ->
                        val s = r.body?.string().orEmpty()
                        if (r.isSuccessful) {
                            good = m
                            val parts = JSONObject(s).getJSONArray("candidates").getJSONObject(0)
                                .getJSONObject("content").getJSONArray("parts")
                            return@withContext (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
                                .ifBlank { "(खाली जवाब)" }
                        }
                        val msg = runCatching { JSONObject(s).getJSONObject("error").getString("message") }.getOrDefault("")
                        last = "Error ${r.code}: $msg"
                        if (r.code == 400 && fast) { plainOnly.add(m); retryPlain = true; return@use }
                        if (msg.contains("API key", true) || r.code !in listOf(400, 404, 503, 429)) return@withContext last
                    }
                } catch (e: Exception) { return@withContext "Network error: ${e.message}" }
                if (!retryPlain) break
            }
        }
        last
    }
}
