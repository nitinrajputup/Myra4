package com.myra.ai.service

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Shared between the background service and the Voice Assistant screen. */
object VoiceState {
    var on by mutableStateOf(false)          // continuous conversation running
    var speaking by mutableStateOf(false)    // MYRA is talking / thinking
    var line by mutableStateOf("")           // last thing heard / said
    var level by mutableFloatStateOf(0f)     // live mic loudness 0..1 (drives the animation)
}
