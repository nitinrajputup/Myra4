package com.myra.ai.voice

import android.content.Context
import android.media.MediaPlayer
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File

private val sharedClient = OkHttpClient()   // reused connection = faster

class ElevenLabsTts(private val ctx: Context, private val apiKey: String, private val voiceId: String) {
    private val client = sharedClient
    private var player: MediaPlayer? = null

    /** Returns false if ElevenLabs failed (bad key/voice/network) so the caller can fall back. */
    suspend fun speak(text: String, onDone: () -> Unit = {}): Boolean {
        val f = withContext(Dispatchers.IO) {
            val body = JSONObject().put("text", text).put("model_id", "eleven_flash_v2_5")
                .put("voice_settings", JSONObject().put("stability", 0.35).put("similarity_boost", 0.8))   // livelier, more expressive
            val req = Request.Builder().url("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_22050_32")
                .header("xi-api-key", apiKey)
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            runCatching {
                client.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return@runCatching null
                    File(ctx.cacheDir, "tts.mp3").also { it.writeBytes(r.body!!.bytes()) }
                }
            }.getOrNull()
        } ?: return false
        return runCatching {
            withContext(Dispatchers.Main) {
                player?.release()
                player = MediaPlayer().apply {
                    setDataSource(f.absolutePath); prepare()
                    setOnCompletionListener { onDone() }; setOnErrorListener { _, _, _ -> onDone(); true }; start()
                }
            }
        }.isSuccess
    }
}
