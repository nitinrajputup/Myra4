package com.myra.ai.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.*
import kotlin.random.Random

/** Green particle sphere. Small and calm while listening for the wake word; grows with ripples when MYRA wakes up. */
class ParticleView(ctx: Context) : View(ctx) {
    private val n = 420
    private val th = FloatArray(n) { acos(1f - 2f * Random.nextFloat()) }
    private val ph = FloatArray(n) { (2.0 * PI).toFloat() * Random.nextFloat() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t = 0f
    private var scale = 0.62f
    var awake = false

    override fun onDraw(c: Canvas) {
        t += if (awake) 0.035f else 0.012f
        scale += ((if (awake) 1f else 0.62f) - scale) * 0.08f
        val cx = width / 2f; val cy = height / 2f; val half = min(width, height) / 2f
        if (awake) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f
            for (i in 0..2) {
                val p = (t * 0.6f + i / 3f) % 1f
                paint.color = Color.argb(((1f - p) * 170).toInt(), 120, 255, 230)
                c.drawCircle(cx, cy, half * (0.7f + p * 0.3f), paint)
            }
        }
        paint.style = Paint.Style.FILL
        val r = half * scale * (0.86f + 0.07f * sin(t * 2f))
        for (i in 0 until n) {
            val a = ph[i] + t
            val x = sin(th[i]) * cos(a); val z = sin(th[i]) * sin(a); val y = cos(th[i])
            val d = (z + 1f) / 2f
            paint.color = Color.argb((70 + 185 * d).toInt(), if (awake) 120 else 60, 255, if (awake) 230 else 130)
            c.drawCircle(cx + x * r, cy + y * r, 1.6f + 1.8f * d, paint)
        }
        postInvalidateOnAnimation()
    }
}
