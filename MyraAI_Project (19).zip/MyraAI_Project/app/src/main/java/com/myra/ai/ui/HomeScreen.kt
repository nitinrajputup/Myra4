package com.myra.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Purple: Color get() = ThemeState.primary
val Blue: Color get() = ThemeState.secondary
val Bg: Color get() = ThemeState.bg
val Neon: Brush get() = Brush.horizontalGradient(listOf(Blue, Purple))

@Composable
fun HomeScreen(
    status: String = "I am listening...",
    battery: Int = 92,
    charging: Boolean = true,
    onTile: (String) -> Unit = {},
    onMic: () -> Unit = {}
) {
    Column(
        Modifier.fillMaxSize().background(Bg).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Pill("☰"); Spacer(Modifier.weight(1f))
            Pill("👑 Premium", Color(0xFFFFC83D)); Spacer(Modifier.weight(1f))
            Pill("⚙") { onTile("Settings") }; Spacer(Modifier.width(8.dp)); Pill("🔔")
        }
        Spacer(Modifier.height(12.dp))
        Text("MYRA AI", fontSize = 44.sp, fontWeight = FontWeight.Black,
            fontStyle = FontStyle.Italic, color = Color.White)
        Text("Your Smart AI Assistant", color = Color.White, fontSize = 15.sp)
        NeonOrb(Modifier.weight(1f).fillMaxWidth())
        VoiceBar(status, onMic)
        Spacer(Modifier.height(12.dp))
        val tiles = listOf("💬" to "AI Chat", "🎙" to "Voice Assistant", "📷" to "Live Vision",
            "📱" to "Phone Control", "🧠" to "Memory", "🌐" to "Web Search",
            "⚡" to "Automation", "▦" to "More Tools")
        tiles.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (i, t) -> Tile(i, t, Modifier.weight(1f)) { onTile(t) } }
            }
            Spacer(Modifier.height(8.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatusCard("🔋", "Battery", "$battery%", if (charging) "Charging OK" else "On battery", Modifier.weight(1f))
            StatusCard("🛡", "Security", "Active", "All Safe", Modifier.weight(1f))
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("🏠 Home", "📊 Tasks", "🗓 History", "👑 Pro").forEachIndexed { i, s ->
                Text(s, color = if (i == 0) Purple else Color.Gray, fontSize = 13.sp)
            }
        }
    }
}

@Composable fun Pill(t: String, c: Color = Color.White, onClick: () -> Unit = {}) =
    Box(Modifier.border(1.dp, Neon, RoundedCornerShape(20.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(t, color = c, fontSize = 14.sp)
    }

@Composable
fun NeonOrb(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "s")
    val pulse by t.animateFloat(0.92f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "p")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height / 2)
            val r = minOf(size.width, size.height) * 0.36f * pulse
            drawCircle(Brush.radialGradient(listOf(Purple.copy(.45f), Color.Transparent), c, r * 1.6f), r * 1.6f, c)
            drawCircle(Neon, r, c, style = Stroke(5f))
            for (i in 0..2) {
                val w = r * (2.2f + i * .35f); val h = w * .28f
                drawOval(if (i % 2 == 0) Purple else Blue,
                    Offset(c.x - w / 2, c.y - h / 2), Size(w, h), style = Stroke(3f), alpha = .8f)
            }
        }
        Box(Modifier.size(110.dp).rotate(0f).background(Brush.radialGradient(listOf(Purple, Bg)), CircleShape),
            contentAlignment = Alignment.Center) {
            // TODO: replace with Image(painterResource(R.drawable.myra_avatar), ...)
            Text("MYRA", color = Color.White, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
        }
    }
}

@Composable
fun VoiceBar(status: String, onMic: () -> Unit) {
    val t = rememberInfiniteTransition(label = "w")
    val ph by t.animateFloat(0f, 6.28f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "ph")
    Row(Modifier.fillMaxWidth().height(80.dp).border(2.dp, Neon, RoundedCornerShape(40.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp).border(1.dp, Purple, CircleShape).clickable { onMic() }, Alignment.Center) { Text("🎤", fontSize = 22.sp) }
        Spacer(Modifier.width(12.dp))
        Column {
            Canvas(Modifier.fillMaxWidth().height(34.dp)) {
                for (i in 0 until 40) {
                    val h = (kotlin.math.sin(ph + i * .5f).toFloat() * .5f + .5f) * size.height
                    drawLine(Blue, Offset(i * size.width / 40, (size.height - h) / 2),
                        Offset(i * size.width / 40, (size.height + h) / 2), 4f)
                }
            }
            Text("Hello Boss...", color = Color.White, fontWeight = FontWeight.Bold)
            Text(status, color = Purple, fontSize = 12.sp)
        }
    }
}

@Composable
fun Tile(icon: String, title: String, m: Modifier, onClick: () -> Unit) =
    Column(m.height(84.dp).border(1.dp, Neon, RoundedCornerShape(16.dp)).clickable { onClick() }.padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, fontSize = 26.sp)
        Text(title, color = Color.White, fontSize = 11.sp, maxLines = 2, lineHeight = 13.sp)
    }

@Composable
fun StatusCard(icon: String, title: String, big: String, small: String, m: Modifier) =
    Row(m.border(1.dp, Color(0xFF2BD96B), RoundedCornerShape(18.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 30.sp); Spacer(Modifier.width(8.dp))
        Column {
            Text(title, color = Color.White, fontSize = 12.sp)
            Text(big, color = Color(0xFF2BD96B), fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("✔ $small", color = Color(0xFF2BD96B), fontSize = 11.sp)
        }
    }
