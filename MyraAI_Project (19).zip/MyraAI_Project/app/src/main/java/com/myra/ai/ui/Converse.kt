package com.myra.ai.ui

import android.content.Context
import com.myra.ai.ai.Brain
import com.myra.ai.ai.GeminiTools
import com.myra.ai.task.Parsed
import com.myra.ai.task.TaskRunner
import com.myra.ai.voice.Speaker

/** Remembers a half-finished command ("किसको कॉल करूँ?") until the next thing you say. */
object ConvState { var pending: Parsed? = null }

/**
 * One brain for Home mic, Voice Assistant and AI Chat: phone task first (speaks every step),
 * otherwise web search / memory brain. Returns the sentence to show and say.
 */
suspend fun converse(ctx: Context, speaker: Speaker, text: String): String {
    val p0 = ConvState.pending; ConvState.pending = null
    val p = if (p0 != null) p0.copy(name = if (p0.kind == "alarm") TaskRunner.timeOf(text) else text.trim())
            else TaskRunner.parseSmart(ctx, text)
    if (p != null) {
        val q = TaskRunner.question(p.kind)
        if (p.name == null && q != null) { ConvState.pending = p; return q }
        return TaskRunner.runText(ctx, p) { speaker.sayWait(it) }
    }
    if (GeminiTools.needsSearch(text)) speaker.sayWait("ठीक है बॉस, इंटरनेट पर खोज रही हूँ।")
    return Brain.answer(ctx, text)
}
