package com.myra.ai.ai

import android.graphics.Bitmap
import android.util.Base64
import org.json.*
import java.io.ByteArrayOutputStream

object GeminiTools {
    private fun parts(vararg p: JSONObject) = JSONArray().put(JSONObject().put("parts", JSONArray(p.toList())))
    private fun text(t: String) = JSONObject().put("text", t)

    private val searchWords = listOf("search", "सर्च", "खोज", "ढूंढ", "ढूँढ", "news", "न्यूज़", "समाचार", "खबर", "मौसम",
        "weather", "आज", "latest", "कीमत", "price", "रेट", "स्कोर", "score", "कौन है", "who is")
    fun needsSearch(q: String) = q.lowercase().let { s -> searchWords.any { s.contains(it) } }

    /** Normal answer, or live web search when the question needs fresh info. */
    suspend fun answer(key: String, q: String) = if (needsSearch(q)) webSearch(key, q) else GeminiClient.ask(key, q)

    /** Live internet research via Gemini Google Search grounding. */
    suspend fun webSearch(key: String, q: String) = GeminiClient.generate(key, JSONObject()
        .put("contents", parts(text("हिंदी में छोटा जवाब दो: $q")))
        .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject()))))

    /** Live Vision / image understanding. */
    suspend fun vision(key: String, bmp: Bitmap, q: String): String {
        val out = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        val img = JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg")
            .put("data", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)))
        return GeminiClient.generate(key, JSONObject().put("contents", parts(img, text("हिंदी में बताओ: $q"))))
    }
}
