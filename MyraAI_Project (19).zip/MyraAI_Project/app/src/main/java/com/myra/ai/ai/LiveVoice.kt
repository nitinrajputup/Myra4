package com.myra.ai.ai

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini Live (e.g. gemini-3.8-live): streams your mic (16 kHz PCM) and plays the spoken answer (24 kHz PCM). */
class LiveVoice(private val key: String, private val model: String, private val sys: String, private val onState: (String) -> Unit) {
    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private val ui = Handler(Looper.getMainLooper())
    private var ws: WebSocket? = null
    private var mic: AudioRecord? = null
    private var track: AudioTrack? = null
    @Volatile private var running = false

    private fun state(s: String) { ui.post { onState(s) } }

    fun start() {
        if (running) return
        running = true; state("कनेक्ट हो रही है...")
        val ver = if (model.contains("thinking")) "v1alpha" else "v1beta"
        val req = Request.Builder()
            .url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.$ver.GenerativeService.BidiGenerateContent?key=${key.trim()}").build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                val setup = JSONObject().put("model", "models/$model")
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO")))
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                w.send(JSONObject().put("setup", setup).toString())
            }
            override fun onMessage(w: WebSocket, text: String) = onMsg(text)
            override fun onMessage(w: WebSocket, bytes: ByteString) = onMsg(bytes.utf8())
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) { state("Error: ${t.message}"); stop() }
            override fun onClosed(w: WebSocket, code: Int, reason: String) { state("बंद ($code) $reason"); stop() }
        })
    }

    private fun onMsg(s: String) {
        val j = runCatching { JSONObject(s) }.getOrNull() ?: return
        if (j.has("setupComplete")) { state("🎙 बोलिए, मैं सुन रही हूँ"); startMic(); return }
        val sc = j.optJSONObject("serverContent") ?: return
        if (sc.optBoolean("interrupted")) { track?.pause(); track?.flush(); track?.play() }
        val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts") ?: return
        for (i in 0 until parts.length()) {
            val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
            if (d.isNotEmpty()) { val b = Base64.decode(d, Base64.DEFAULT); track?.write(b, 0, b.size) }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        mic = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400))
        val tmin = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(tmin * 4, 48000)).setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
        mic?.startRecording()
        Thread {
            val buf = ByteArray(3200)
            while (running) {
                val n = mic?.read(buf, 0, buf.size) ?: break
                if (n > 0) ws?.send(JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
                    .put("data", Base64.encodeToString(buf, 0, n, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000"))).toString())
            }
        }.start()
    }

    fun stop() {
        if (!running) return
        running = false
        runCatching { ws?.close(1000, "bye") }; ws = null
        runCatching { mic?.stop(); mic?.release() }; mic = null
        runCatching { track?.stop(); track?.release() }; track = null
        state("बंद")
    }
}
