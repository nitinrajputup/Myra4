package com.myra.ai.voice

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import com.myra.ai.ai.GeminiClient
import com.myra.ai.service.VoiceState
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Always-on microphone (no Google recognizer = no "ting", no restarts). Cuts the audio into sentences by
 * silence and hands each sentence to [onSpeech]. Frames are ignored while [blocked] (MYRA talking / busy).
 */
class ContinuousMic(private val onSpeech: (ByteArray) -> Unit, private val blocked: () -> Boolean) {
    @Volatile var running = false
    private var gen = 0

    fun start() {
        if (running) return
        running = true; gen++; val g = gen
        Thread { loop(g) }.also { it.isDaemon = true }.start()
    }

    fun stop() { running = false; gen++ }

    @SuppressLint("MissingPermission")
    private fun loop(g: Int) {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val ar = runCatching { AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, max(min, rate)) }.getOrNull()
        if (ar == null || ar.state != AudioRecord.STATE_INITIALIZED) {
            VoiceState.line = "⚠ माइक शुरू नहीं हुआ: App info में Microphone ✅ करो और दूसरे ऐप का माइक बंद करो"; running = false; return
        }
        ar.startRecording()
        val buf = ShortArray(800)                       // 50 ms
        val pre = ArrayDeque<ByteArray>()               // a little audio before speech starts
        val speech = ByteArrayOutputStream()
        var inSpeech = false; var silent = 0; var loud = 0; var noise = 0.01
        while (running && g == gen) {
            val n = ar.read(buf, 0, buf.size)
            if (n <= 0) continue
            if (blocked()) { speech.reset(); inSpeech = false; silent = 0; loud = 0; pre.clear(); continue }
            var sum = 0.0
            for (i in 0 until n) sum += buf[i] * buf[i].toDouble()
            val rms = sqrt(sum / n) / 32768.0
            val bytes = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN).also { b -> for (i in 0 until n) b.putShort(buf[i]) }.array()
            val thr = max(0.008, noise * 3.0)
            if (rms > thr) { loud++; silent = 0; if (loud >= 3 && !inSpeech) { inSpeech = true; VoiceState.line = "🎙 सुन रही हूँ..."; pre.forEach { speech.write(it) }; pre.clear() } }
            else { silent++; loud = 0; if (!inSpeech) noise = noise * 0.98 + rms * 0.02 }
            if (inSpeech) {
                speech.write(bytes)
                VoiceState.level = (rms * 8).coerceIn(0.0, 1.0).toFloat()
                if (silent >= 12 || speech.size() > rate * 2 * 15) {        // 0.8 s of silence, or 15 s max
                    val data = speech.toByteArray(); speech.reset(); inSpeech = false; silent = 0; loud = 0
                    if (data.size > rate * 2 * 4 / 10) onSpeech(data)       // ignore clicks shorter than 0.4 s
                }
            } else { pre.addLast(bytes); if (pre.size > 4) pre.removeFirst(); VoiceState.level *= 0.8f }
        }
        runCatching { ar.stop(); ar.release() }
    }
}

/** Turns one recorded sentence into text with Gemini (Hindi in Devanagari). null = nothing clear was said. */
object Transcriber {
    private fun wav(pcm: ByteArray): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray()).put("fmt ".toByteArray())
            .putInt(16).putShort(1).putShort(1).putInt(16000).putInt(32000).putShort(2).putShort(16)
            .put("data".toByteArray()).putInt(pcm.size)
        return h.array() + pcm
    }

    /** Quiet speech is boosted (up to 8x) so Gemini hears it clearly. */
    private fun normalize(pcm: ByteArray): ByteArray {
        val bb = ByteBuffer.wrap(pcm).order(ByteOrder.LITTLE_ENDIAN); val n = pcm.size / 2
        var peak = 1
        for (i in 0 until n) peak = max(peak, abs(bb.getShort(i * 2).toInt()))
        if (peak > 20000 || peak < 150) return pcm
        val g = min(8f, 24000f / peak)
        val out = ByteBuffer.allocate(pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until n) out.putShort((bb.getShort(i * 2) * g).toInt().coerceIn(-32768, 32767).toShort())
        return out.array()
    }

    fun wavBase64(pcm: ByteArray): String = Base64.encodeToString(wav(normalize(pcm)), Base64.NO_WRAP)

    suspend fun text(key: String, pcm: ByteArray): String? {
        val parts = JSONArray()
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav")
                .put("data", Base64.encodeToString(wav(pcm), Base64.NO_WRAP))))
            .put(JSONObject().put("text", "इस ऑडियो में जो बोला गया है उसे ज्यों का त्यों लिखो (हिंदी देवनागरी में, अंग्रेज़ी शब्द जैसे बोले गए वैसे)। " +
                "अगर साफ़ बोली नहीं है, सिर्फ़ शोर या चुप्पी है, तो कुछ भी मत लिखो। सिर्फ़ बोला हुआ टेक्स्ट दो, कोई और शब्द नहीं।"))
        val r = GeminiClient.generate(key, JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))).trim()
        if (r.startsWith("Error") || r.startsWith("Network") || r.startsWith("पहले Settings")) { VoiceState.line = "⚠ " + r.take(70); return null }
        return r.takeIf { it.length >= 2 && it != "(खाली जवाब)" }
    }
}
