package com.myra.ai.battery

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.myra.ai.data.Store
import com.myra.ai.overlay.OverlayManager
import com.myra.ai.voice.Speaker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/** Speaks when: charger plugged in (+ charging animation), battery full, battery low. Runs inside WakeWordService. */
object BatteryMonitor {
    private var receiver: BroadcastReceiver? = null
    private var was: Boolean? = null
    private var fullSaid = false
    private var lowSaid = false

    private fun parse(i: Intent?): Pair<Int, Boolean> {
        val lvl = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val sc = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val st = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val pct = if (lvl >= 0 && sc > 0) lvl * 100 / sc else 0
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        return pct to (plugged || st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL)
    }

    /** Also shows a notification, so you see the alert even if the voice is silent. */
    private fun note(c: Context, t: String) = runCatching {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("myra_alert", "MYRA Alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(2, NotificationCompat.Builder(c, "myra_alert").setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("MYRA").setContentText(t).setAutoCancel(true).build())
    }

    fun read(ctx: Context): Pair<Int, Boolean> =
        parse(ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)))

    fun statusText(ctx: Context): String {
        val (p, c) = read(ctx)
        return if (c) "बॉस, बैटरी $p परसेंट है और चार्ज हो रही है।" else "बॉस, बैटरी $p परसेंट है।"
    }

    fun start(ctx: Context, speaker: Speaker, scope: CoroutineScope) {
        if (receiver != null) return
        val app = ctx.applicationContext
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val (pct, chg) = parse(i)
                val s = Store(c)
                fun on(k: String) = s.get(k) != "off"
                fun say(t: String) { note(c, t); scope.launch { speaker.say(t) } }
                val before = was; was = chg
                if (before != null && chg != before) {                       // plug / unplug
                    if (chg) { OverlayManager.charging(c, pct); if (on("bat_plug")) say("चार्जर लग गया बॉस, बैटरी $pct परसेंट है।") }
                    else { OverlayManager.hideCharging(); if (on("bat_unplug")) say("चार्जर निकाल दिया बॉस, बैटरी $pct परसेंट है।") }
                }
                if (chg && pct >= 100) {                                      // full
                    if (!fullSaid) { fullSaid = true; if (on("bat_full")) say("बैटरी फुल चार्ज हो गई बॉस, चार्जर निकाल दो।") }
                } else fullSaid = false
                val low = s.get("bat_low").toIntOrNull() ?: 20
                if (!chg && pct <= low) {                                     // low
                    if (!lowSaid) { lowSaid = true; if (on("bat_lowon")) say("बैटरी कम है बॉस, सिर्फ़ $pct परसेंट बची है। चार्जर लगाओ।") }
                } else if (chg || pct > low) lowSaid = false
            }
        }
        receiver = r
        ContextCompat.registerReceiver(app, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    fun stop(ctx: Context) {
        receiver?.let { runCatching { ctx.applicationContext.unregisterReceiver(it) } }
        receiver = null; was = null
    }
}
