package com.myra.ai.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.myra.ai.battery.BatteryMonitor
import com.myra.ai.data.Store
import com.myra.ai.overlay.OverlayManager
import com.myra.ai.voice.Speaker
import kotlinx.coroutines.launch

/** Live (percent, isCharging) that updates the Home battery card. */
@Composable
fun rememberBattery(): Pair<Int, Boolean> {
    val ctx = LocalContext.current
    var st by remember { mutableStateOf(BatteryMonitor.read(ctx)) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) { st = BatteryMonitor.read(c) } }
        ContextCompat.registerReceiver(ctx, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { runCatching { ctx.unregisterReceiver(r) } }
    }
    return st
}

@Composable
fun BatteryPanel(store: Store) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    val speaker = remember { Speaker(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    val (pct, chg) = rememberBattery()
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Text("🔋 $pct%  " + if (chg) "⚡ चार्ज हो रही है" else "बैटरी पर", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(10.dp))
        listOf("bat_plug" to "चार्जर लगाने पर बताओ", "bat_full" to "फुल चार्ज होने पर बताओ", "bat_unplug" to "चार्जर निकालने पर बताओ",
            "bat_lowon" to "बैटरी कम होने पर बताओ").forEach { (k, l) ->
            var on by remember { mutableStateOf(store.get(k) != "off") }
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(l, color = Color.White, modifier = Modifier.weight(1f))
                Switch(on, { on = it; store.set(k, if (it) "on" else "off") })
            }
        }
        var low by remember { mutableStateOf(store.get("bat_low").ifBlank { "20" }) }
        F("कम बैटरी कितने % पर बताऊँ", low) { low = it.filter(Char::isDigit).take(2); store.set("bat_low", low) }
        Button({ OverlayManager.charging(ctx, pct) }) { Text("⚡ Charging animation देखो") }
        OutlinedButton({ scope.launch { speaker.say(BatteryMonitor.statusText(ctx)) } }) { Text("🔊 आवाज़ टेस्ट") }
        Text("ध्यान: बताने के लिए MYRA का background (Wake Word) ON रहना चाहिए।", color = Color.Gray, fontSize = 12.sp)
    }
}
