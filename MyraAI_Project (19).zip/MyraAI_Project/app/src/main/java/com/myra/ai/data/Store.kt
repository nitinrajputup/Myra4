package com.myra.ai.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("myra", Context.MODE_PRIVATE)
    fun get(k: String) = p.getString(k, "") ?: ""
    fun set(k: String, v: String) = p.edit().putString(k, v).apply()
    // Memory: list of remembered notes/tasks
    fun memories(): List<String> = JSONArray(p.getString("memories", "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
    fun addMemory(t: String) = set("memories", JSONArray(memories() + t).toString())
    fun clearMemories() = set("memories", "[]")
    // Conversation memory (last 12 exchanges) so the brain remembers what was said
    fun chat(): List<Pair<String, String>> = JSONArray(p.getString("chat", "[]")).let { a ->
        (0 until a.length()).map { val o = a.getJSONObject(it); o.getString("r") to o.getString("t") } }
    fun addChat(user: String, bot: String) {
        val a = JSONArray()
        (chat() + listOf("user" to user, "model" to bot)).takeLast(40).forEach { a.put(JSONObject().put("r", it.first).put("t", it.second)) }
        p.edit().putString("chat", a.toString()).apply()
    }
    fun removeMemory(t: String) = set("memories", JSONArray(memories().filter { it != t }).toString())
    fun clearChat() = set("chat", "[]")
    // Task history
    fun history(): List<String> = JSONArray(p.getString("history", "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
    fun addHistory(t: String) = p.edit().putString("history", JSONArray((history() + t).takeLast(100)).toString()).apply()
}
