package com.myra.ai.voice

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import com.myra.ai.data.Store

/** Silences the "ting" that Google's speech recognizer plays every time it starts / stops listening. */
object Beep {
    private val h = Handler(Looper.getMainLooper())
    private val mine = mutableSetOf<Int>()      // only streams WE muted are un-muted again
    private var am: AudioManager? = null
    private val undo = Runnable { restore() }

    fun hush(ctx: Context, ms: Long = 900) {
        val a = ctx.getSystemService(AudioManager::class.java); am = a
        val streams = mutableListOf(AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION)
        if (Store(ctx).get("beepmusic") == "on") streams.add(AudioManager.STREAM_MUSIC)
        for (s in streams) if (s !in mine && !a.isStreamMute(s)) {
            if (runCatching { a.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0) }.isSuccess) mine.add(s)
        }
        h.removeCallbacks(undo); h.postDelayed(undo, ms)
    }

    fun restore() {
        val a = am ?: return
        mine.forEach { runCatching { a.adjustStreamVolume(it, AudioManager.ADJUST_UNMUTE, 0) } }
        mine.clear()
    }
}
