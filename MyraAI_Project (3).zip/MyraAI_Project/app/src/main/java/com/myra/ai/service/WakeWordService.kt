package com.myra.ai.service

import android.app.*
import android.content.*
import android.os.*
import android.speech.*
import androidx.core.app.NotificationCompat
import com.myra.ai.ai.GeminiClient
import com.myra.ai.voice.ElevenLabsTts
import kotlinx.coroutines.*

/** Foreground service: always listens for "Hello Myra", answers "जी बॉस", then takes the command. */
class WakeWordService : Service() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var rec: SpeechRecognizer? = null
    private var awake = false
    private lateinit var speaker: com.myra.ai.voice.Speaker

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "myra"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "MYRA", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, NotificationCompat.Builder(this, ch).setContentTitle("MYRA सुन रही है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build())
        speaker = com.myra.ai.voice.Speaker(this)
        listen()
    }

    private fun listen() {
        rec?.destroy()
        rec = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle) {
                    val said = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase()
                    handle(said)
                }
                override fun onError(e: Int) { restart() }
                override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(r: Float) {}; override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            })
        }
    }

    private fun restart() = scope.launch { delay(400); listen() }

    private fun handle(said: String) {
        val wake = listOf("hello myra", "हेलो मायरा", "हैलो मायरा", "हेलो मीरा", "hello mira")
        if (!awake) {
            if (wake.any { said.contains(it) }) {
                awake = true
                scope.launch { speaker.say("जी बॉस") { listen() } }   // listens for command after reply
            } else restart()
            return
        }
        awake = false
        scope.launch {
            val key = getSharedPreferences("myra", MODE_PRIVATE).getString("gemini_key", "") ?: ""
            speaker.say(GeminiClient.ask(key, said)) { listen() }
        }
    }

    override fun onDestroy() { rec?.destroy(); speaker.shutdown(); scope.cancel(); super.onDestroy() }
}
