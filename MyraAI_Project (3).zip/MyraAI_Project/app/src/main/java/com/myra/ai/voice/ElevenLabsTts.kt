package com.myra.ai.voice

import android.content.Context
import android.media.MediaPlayer
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File

class ElevenLabsTts(private val ctx: Context, private val apiKey: String, private val voiceId: String) {
    private val client = OkHttpClient()
    private var player: MediaPlayer? = null

    /** Returns false if ElevenLabs failed (bad key/voice/network) so the caller can fall back. */
    suspend fun speak(text: String, onDone: () -> Unit = {}): Boolean {
        val f = withContext(Dispatchers.IO) {
            val body = JSONObject().put("text", text).put("model_id", "eleven_multilingual_v2")
            val req = Request.Builder().url("https://api.elevenlabs.io/v1/text-to-speech/$voiceId")
                .header("xi-api-key", apiKey)
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            runCatching {
                client.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) return@runCatching null
                    File(ctx.cacheDir, "tts.mp3").also { it.writeBytes(r.body!!.bytes()) }
                }
            }.getOrNull()
        } ?: return false
        withContext(Dispatchers.Main) {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(f.absolutePath); prepare()
                setOnCompletionListener { onDone() }; start()
            }
        }
        return true
    }
}
