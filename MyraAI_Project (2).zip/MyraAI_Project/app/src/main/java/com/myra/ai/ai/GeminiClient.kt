package com.myra.ai.ai

import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*

object GeminiClient {
    private val client = OkHttpClient()
    // Tries these in order; remembers the one that works. 404/503/429 -> next model.
    private val models = listOf("gemini-3.5-flash", "gemini-3.8-flash", "gemini-3.5-flash-lite",
        "gemini-3-flash-preview", "gemini-2.5-flash-lite", "gemini-2.5-flash")
    @Volatile private var good: String? = null
    private const val SYSTEM = "तुम MYRA हो, एक स्मार्ट हिंदी वॉइस असिस्टेंट। यूज़र को 'बॉस' बोलो। जवाब छोटा रखो।\n"

    suspend fun ask(key: String, prompt: String): String = generate(key, JSONObject().put("contents",
        JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM + prompt))))))

    suspend fun generate(key: String, body: JSONObject): String = withContext(Dispatchers.IO) {
        if (key.isBlank()) return@withContext "पहले Settings में Gemini API Key डालो बॉस।"
        var last = "Gemini error"
        for (m in listOfNotNull(good) + models.filter { it != good }) {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent?key=${key.trim()}")
                .post(body.toString().toRequestBody("application/json".toMediaType())).build()
            try {
                client.newCall(req).execute().use { r ->
                    val s = r.body?.string().orEmpty()
                    if (r.isSuccessful) {
                        good = m
                        val parts = JSONObject(s).getJSONArray("candidates").getJSONObject(0)
                            .getJSONObject("content").getJSONArray("parts")
                        return@withContext (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
                            .ifBlank { "(खाली जवाब)" }
                    }
                    val msg = runCatching { JSONObject(s).getJSONObject("error").getString("message") }.getOrDefault("")
                    last = "Error ${r.code}: $msg"
                    if (r.code != 404 && r.code != 503 && r.code != 429) return@withContext last
                }
            } catch (e: Exception) { return@withContext "Network error: ${e.message}" }
        }
        last
    }
}
