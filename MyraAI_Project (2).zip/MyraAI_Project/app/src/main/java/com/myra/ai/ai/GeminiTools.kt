package com.myra.ai.ai

import android.graphics.Bitmap
import android.util.Base64
import org.json.*
import java.io.ByteArrayOutputStream

object GeminiTools {
    private fun parts(vararg p: JSONObject) = JSONArray().put(JSONObject().put("parts", JSONArray(p.toList())))
    private fun text(t: String) = JSONObject().put("text", t)

    /** Live internet research via Gemini Google Search grounding. */
    suspend fun webSearch(key: String, q: String) = GeminiClient.generate(key, JSONObject()
        .put("contents", parts(text("हिंदी में छोटा जवाब दो: $q")))
        .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject()))))

    /** Live Vision / image understanding. */
    suspend fun vision(key: String, bmp: Bitmap, q: String): String {
        val out = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        val img = JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg")
            .put("data", Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)))
        return GeminiClient.generate(key, JSONObject().put("contents", parts(img, text("हिंदी में बताओ: $q"))))
    }
}
