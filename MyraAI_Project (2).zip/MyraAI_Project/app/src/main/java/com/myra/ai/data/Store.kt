package com.myra.ai.data

import android.content.Context
import org.json.JSONArray

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("myra", Context.MODE_PRIVATE)
    fun get(k: String) = p.getString(k, "") ?: ""
    fun set(k: String, v: String) = p.edit().putString(k, v).apply()
    // Memory: list of remembered notes/tasks
    fun memories(): List<String> = JSONArray(p.getString("memories", "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
    fun addMemory(t: String) = set("memories", JSONArray(memories() + t).toString())
    fun clearMemories() = set("memories", "[]")
    // Task history
    fun history(): List<String> = JSONArray(p.getString("history", "[]")).let { a -> (0 until a.length()).map { a.getString(it) } }
    fun addHistory(t: String) = p.edit().putString("history", JSONArray((history() + t).takeLast(100)).toString()).apply()
}
