package com.myra.ai.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.random.Random

private val Red = Color(0xFFFF3D5A); private val Green = Color(0xFF2BD96B)

/**
 * Moving neon background: rising particles, flickering side lightning,
 * RGB sweeping border, and expanding "listening" ripples around the orb.
 * Draws on top of the UI at low alpha; touches pass through.
 */
@Composable
fun NeonBackdrop(modifier: Modifier = Modifier, listening: Boolean = true, orbY: Float = 0.34f) {
    val t = rememberInfiniteTransition(label = "bg")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(if (listening) 5000 else 10000, easing = LinearEasing)), label = "p")
    val sweep by t.animateFloat(0f, 1f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "sw")
    val flick by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "f")
    val ripple by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "r")
    val dots = remember { List(45) { Triple(Random.nextFloat(), Random.nextFloat(), Random.nextFloat()) } }
    val bolt = remember { List(9) { Random.nextFloat() } }

    Canvas(modifier) {
        val w = size.width; val h = size.height
        // 1) rising particles
        dots.forEach { (x, y, s) ->
            val yy = ((y - p * (0.4f + s)) % 1f + 1f) % 1f
            drawCircle(lerp(Blue, Purple, s).copy(alpha = 0.55f * s + 0.15f), 2f + s * 4f, Offset(x * w, yy * h))
        }
        // 2) side lightning, flickers
        listOf(0f, 1f).forEach { side ->
            val path = Path().apply {
                moveTo(w * side, 0f)
                bolt.forEachIndexed { i, r ->
                    val dx = (if (side == 0f) 1 else -1) * (10f + r * w * 0.10f)
                    lineTo(w * side + dx, h * (i + 1) / bolt.size * 0.45f)
                }
            }
            drawPath(path, Blue.copy(alpha = 0.15f + 0.45f * flick), style = Stroke(3f))
        }
        // 3) RGB border sweeping
        val off = (sweep * 2f - 1f) * w
        drawRoundRect(
            Brush.linearGradient(listOf(Red, Purple, Blue, Green, Red), Offset(off, 0f), Offset(off + w, h), TileMode.Mirror),
            cornerRadius = CornerRadius(40f), style = Stroke(5f), alpha = 0.9f
        )
        // 4) listening ripples
        if (listening) for (i in 0..2) {
            val ph = (ripple + i / 3f) % 1f
            drawCircle(Purple.copy(alpha = (1f - ph) * 0.6f), w * (0.2f + ph * 0.35f), Offset(w / 2, h * orbY), style = Stroke(3f))
        }
    }
}

/** Drop-in replacement for HomeScreen: same UI + animated layers on top. */
@Composable
fun AnimatedHome(listening: Boolean = true, onTile: (String) -> Unit = {}, onMic: () -> Unit = {}) {
    Box(Modifier.fillMaxSize()) {
        HomeScreen(status = if (listening) "I am listening..." else "Tap mic to speak", onTile = onTile, onMic = onMic)
        NeonBackdrop(Modifier.fillMaxSize(), listening)
    }
}
