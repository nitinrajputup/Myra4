MYRA - Part 3 (Animations). Part 1 और Part 2 के बाद जोड़ो. Package: com.myra.ai

File: ui/Animations.kt  ->  app/src/main/java/com/myra/ai/ui/

Features: moving neon background (rising particles), flickering side lightning,
RGB sweeping border, listening ripple rings around the orb.
(Orb pulse/rings और voice waveform Part 1 के HomeScreen.kt में पहले से हैं)

Use: Panels.kt में MyraRoot के अंदर
   HomeScreen(onTile = { screen = it })
इसे बदलो:
   AnimatedHome(onTile = { screen = it })

Ripples की position ठीक करनी हो तो NeonBackdrop का orbY (0.34f) बदलो।
