package com.myra.ai.service

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.myra.ai.ai.Brain
import com.myra.ai.ai.GeminiClient
import com.myra.ai.battery.BatteryMonitor
import com.myra.ai.overlay.OverlayManager
import com.myra.ai.task.Parsed
import com.myra.ai.task.TaskRunner
import com.myra.ai.voice.Speaker
import kotlinx.coroutines.*

/** Always listening: "Hello Myra" -> orb wakes up -> "जी बॉस" -> phone task / web search / answer. Keeps listening in every app. */
class WakeWordService : Service() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var job: Job? = null
    private var awake = false
    private var handled = false
    private var paused = false                 // Gemini Live panel is using the mic
    private var busy = false                   // answering / running a task
    @Volatile private var lastEvent = System.currentTimeMillis()
    private var pending: Parsed? = null
    private lateinit var speaker: Speaker

    private val wakeWords = listOf("myra", "मायरा", "maira", "मैरा", "mira", "मीरा", "मायरे")
    private val fillers = listOf("hello", "हेलो", "हैलो", "हलो", "हेल्लो", "helo", "hey")
    private fun isWake(t: String) = wakeWords.any { t.contains(it) }
    private fun stripWake(t: String): String { var x = t; (wakeWords + fillers).forEach { x = x.replace(it, " ") }; return x.trim() }

    private val intent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(b: Bundle?) {
            lastEvent = System.currentTimeMillis()
            if (handled) return
            handle(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase())
        }
        override fun onPartialResults(b: Bundle?) {
            lastEvent = System.currentTimeMillis()
            if (awake || handled) return
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase()
            if (isWake(t) && stripWake(t).length <= 3) { handled = true; rec?.cancel(); wakeUp() }
        }
        override fun onError(e: Int) {
            lastEvent = System.currentTimeMillis()
            if (handled) return
            when (e) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(60)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { rec?.cancel(); restart(800) }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> restart(3000)
                else -> restart(400)
            }
        }
        override fun onRmsChanged(r: Float) { lastEvent = System.currentTimeMillis() }
        override fun onReadyForSpeech(p: Bundle?) { lastEvent = System.currentTimeMillis() }
        override fun onBeginningOfSpeech() {}; override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}; override fun onEvent(t: Int, b: Bundle?) {}
    }

    /** If the recognizer goes silent for 30 s (killed mic, hung service) rebuild it. */
    private val watchdog = object : Runnable {
        override fun run() {
            if (!paused && !busy && System.currentTimeMillis() - lastEvent > 30000) { rec?.destroy(); rec = null; listen() }
            h.postDelayed(this, 10000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "myra"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "MYRA", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, ch).setContentTitle("MYRA सुन रही है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        val ok = runCatching {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        }.isSuccess
        if (!ok) { stopSelf(); return }   // Android refused the mic service from background: open the app once
        speaker = Speaker(this)
        BatteryMonitor.start(this, speaker, scope)
        OverlayManager.showOrb(this)
        listen()
        h.postDelayed(watchdog, 10000)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            "pause" -> { paused = true; rec?.cancel(); job?.cancel(); awake = false; OverlayManager.awake(false) }
            "revive" -> { paused = false; busy = false; awake = false; rec?.destroy(); rec = null; listen() }
        }
        return START_STICKY
    }

    /** One recognizer is reused (no create/destroy flicker). */
    private fun listen() {
        if (paused) return
        busy = false; handled = false; lastEvent = System.currentTimeMillis()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (rec == null) rec = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
        rec?.cancel(); rec?.startListening(intent)
    }

    private fun restart(ms: Long = 150) { job?.cancel(); job = scope.launch { delay(ms); listen() } }

    private fun wakeUp() {
        awake = true; busy = true; OverlayManager.awake(true)
        scope.launch { speaker.say("जी बॉस") { listen() } }
    }

    private fun handle(said: String) {
        if (!awake) {
            if (!isWake(said)) { restart(60); return }
            val rest = stripWake(said)
            if (rest.length <= 3) { wakeUp(); return }          // only "Hello Myra"
            busy = true; OverlayManager.awake(true)              // "Hello Myra <command>" in one go
            scope.launch { OverlayManager.awake(false); command(rest) }
            return
        }
        awake = false; busy = true; OverlayManager.awake(false)
        scope.launch { command(said) }
    }

    private suspend fun command(said: String) {
        val prefs = getSharedPreferences("myra", MODE_PRIVATE)
        val model = prefs.getString("model", "") ?: ""
        if (GeminiClient.preferred != model) GeminiClient.preferred = model
        val p0 = pending
        pending = null
        val p = if (p0 != null) p0.copy(name = if (p0.kind == "alarm") TaskRunner.timeOf(said) else said.trim())
                else TaskRunner.parse(this, said)
        when {
            p == null -> speaker.say(Brain.answer(this, said)) { listen() }
            p.kind == "battery" -> speaker.say(BatteryMonitor.statusText(this)) { listen() }
            p.kind == "unlock" -> speaker.say("बॉस, PIN या पैटर्न वाला फ़ोन ऐप से अनलॉक नहीं हो सकता, यह Android की सुरक्षा है। फिंगरप्रिंट या फेस अनलॉक इस्तेमाल करो।") { listen() }
            p.name == null && TaskRunner.question(p.kind) != null -> {
                pending = p
                speaker.say(TaskRunner.question(p.kind)!!) { awake = true; OverlayManager.awake(true); listen() }
            }
            else -> {
                val ok = TaskRunner.execute(this, TaskRunner.steps(this, p))
                speaker.say(if (ok) "हो गया बॉस" else "काम नहीं हो पाया बॉस। Accessibility चालू है?") { listen() }
            }
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(watchdog)
        rec?.destroy(); BatteryMonitor.stop(this); if (::speaker.isInitialized) speaker.shutdown()
        OverlayManager.hideOrb(); scope.cancel(); super.onDestroy()
    }
}
