package com.myra.ai.ui

import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.myra.ai.ai.GeminiClient
import com.myra.ai.data.Store
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun F(label: String, v: String, on: (String) -> Unit) =
    OutlinedTextField(v, on, Modifier.fillMaxWidth().padding(bottom = 6.dp), label = { Text(label) }, singleLine = true)

@Composable
fun MoreTools(go: (String) -> Unit) {
    Column(Modifier.verticalScroll(rememberScrollState())) { MoreToolsBody(go) }
}

@Composable
fun MoreToolsBody(go: (String) -> Unit) {
    listOf("🎨 Themes (15+ & Custom)" to "Themes", "👤 Profile & Links" to "Profile",
        "📄 Resume / Biodata" to "Resume", "💻 Coding Assistant" to "Coding",
        "🔋 Battery Alerts & Animation" to "Battery", "🎙 Gemini Live (3.8)" to "Live", "🩺 Setup Check (background fix)" to "Setup",
        "⚙ Settings & Permissions" to "Settings").forEach { (l, k) ->
        OutlinedButton({ go(k) }, Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text(l) }
    }
}

@Composable
fun ThemePanel(store: Store) {
    var p by remember { mutableStateOf("B04CFF") }; var s by remember { mutableStateOf("3D8BFF") }
    var b by remember { mutableStateOf("05030F") }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        themeList.forEach { t ->
            OutlinedButton({ applyTheme(t.p, t.s, t.bg); store.set("theme", t.name) }, Modifier.fillMaxWidth()) { Text(t.name) }
        }
        Text("Custom Theme (hex रंग)", color = Color.White, modifier = Modifier.padding(top = 12.dp))
        F("मुख्य रंग (RRGGBB)", p) { p = it }; F("दूसरा रंग", s) { s = it }; F("Background", b) { b = it }
        Button({ runCatching { applyTheme(hex(p), hex(s), hex(b)); store.set("theme", "custom:$p:$s:$b") } }) { Text("Custom लगाओ") }
    }
}

@Composable
fun ProfilePanel(store: Store) {
    val ctx = LocalContext.current
    var ver by remember { mutableStateOf(0) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            runCatching { ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, "profile.jpg").outputStream().use { o -> i.copyTo(o) } } }
            ver++
        }
    }
    val bmp = remember(ver) { BitmapFactory.decodeFile(File(ctx.filesDir, "profile.jpg").path)?.asImageBitmap() }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (bmp != null) Image(bmp, null, Modifier.size(80.dp).clip(CircleShape), contentScale = ContentScale.Crop)
            else Box(Modifier.size(80.dp).clip(CircleShape).background(Purple), Alignment.Center) { Text("👤", fontSize = 32.sp) }
            Spacer(Modifier.width(12.dp))
            OutlinedButton({ pick.launch("image/*") }) { Text("फोटो चुनो") }
        }
        Spacer(Modifier.height(8.dp))
        listOf("p_name" to "नाम", "p_song" to "पसंदीदा गाना (नाम/लिंक)", "p_yt" to "YouTube link",
            "p_ig" to "Instagram link", "p_fb" to "Facebook link", "p_tg" to "Telegram channel link").forEach { (k, l) ->
            var v by remember { mutableStateOf(store.get(k)) }
            F(l, v) { v = it; store.set(k, it) }
        }
    }
}

fun savePdf(ctx: Context, title: String, text: String): Boolean = runCatching {
    val doc = PdfDocument(); val paint = Paint().apply { textSize = 12f }
    var n = 1
    var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, n).create()); var y = 50f
    for (line in text.lines().flatMap { it.chunked(85) }) {
        if (y > 800f) { doc.finishPage(page); n++; page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, n).create()); y = 50f }
        page.canvas.drawText(line, 40f, y, paint); y += 18f
    }
    doc.finishPage(page)
    val v = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, "$title.pdf"); put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
    ctx.contentResolver.openOutputStream(uri)!!.use { doc.writeTo(it) }
    doc.close(); true
}.getOrDefault(false)

@Composable
fun ResumePanel(store: Store) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var kind by remember { mutableStateOf("Resume") }
    var edu by remember { mutableStateOf("") }; var skills by remember { mutableStateOf("") }
    var exp by remember { mutableStateOf("") }; var extra by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }; var msg by remember { mutableStateOf("") }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Row {
            listOf("Resume", "Biodata").forEach { k ->
                OutlinedButton({ kind = k }) { Text(if (kind == k) "✔ $k" else k) }; Spacer(Modifier.width(8.dp))
            }
        }
        F("पढ़ाई / Education", edu) { edu = it }; F("Skills", skills) { skills = it }
        F("Experience", exp) { exp = it }; F("अन्य (पिता का नाम, पता, जन्मतिथि...)", extra) { extra = it }
        Button({
            scope.launch {
                out = "बना रही हूँ..."
                out = GeminiClient.raw(store.get("gemini_key"),
                    "नीचे की जानकारी से एक साफ़, professional $kind बनाओ। सिर्फ़ plain text दो (कोई ** या # नहीं), headings CAPS में।\n" +
                    "नाम: ${store.get("p_name")}\nEducation: $edu\nSkills: $skills\nExperience: $exp\nअन्य: $extra\n" +
                    "Links: ${store.get("p_yt")} ${store.get("p_ig")} ${store.get("p_fb")} ${store.get("p_tg")}")
            }
        }) { Text("बनाओ") }
        if (out.isNotBlank()) {
            Button({ msg = if (savePdf(ctx, "$kind-" + System.currentTimeMillis(), out)) "Downloads में PDF सेव हो गई ✔" else "PDF सेव नहीं हुई" }) { Text("📄 PDF सेव करो") }
            Text(msg, color = Color.White); Text(out, color = Color.White)
        }
    }
}

@Composable
fun CodingPanel(store: Store) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }; var a by remember { mutableStateOf("") }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("कोडिंग सवाल / error paste करो") })
        Button({
            scope.launch {
                a = "सोच रही हूँ..."
                a = GeminiClient.raw(store.get("gemini_key"),
                    "तुम एक expert coding assistant हो। सही, चलने वाला कोड दो और कोड के बाद 2-3 लाइन हिंदी में समझाओ।\n$q")
            }
        }) { Text("भेजो") }
        Text(a, color = Color.White, modifier = Modifier.padding(top = 12.dp))
    }
}
