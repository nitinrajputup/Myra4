package com.myra.ai.service

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.myra.ai.ai.Brain
import com.myra.ai.ai.GeminiClient
import com.myra.ai.battery.BatteryMonitor
import com.myra.ai.overlay.OverlayManager
import com.myra.ai.task.Parsed
import com.myra.ai.task.TaskRunner
import com.myra.ai.voice.Beep
import com.myra.ai.voice.ContinuousMic
import com.myra.ai.voice.Speaker
import com.myra.ai.voice.Transcriber
import kotlinx.coroutines.*

/** Always listening: "Hello Myra" -> orb wakes up -> "जी बॉस" -> phone task / web search / answer. Keeps listening in every app. */
class WakeWordService : Service() {
    // An unexpected error must never kill MYRA: show it, then go back to listening.
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob() +
        CoroutineExceptionHandler { _, e -> VoiceState.line = ("⚠ " + e.message).take(80); VoiceState.speaking = false; restart(500) })
    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var job: Job? = null
    private var awake = false
    private var handled = false
    private var paused = false                 // Gemini Live panel is using the mic
    private var busySince = 0L
    @Volatile private var busy = false      // answering / running a task
        set(v) { field = v; if (v) busySince = System.currentTimeMillis() }
    @Volatile private var conv = false      // continuous conversation (own mic, no wake word) until you stop it
    @Volatile private var lastEvent = System.currentTimeMillis()
    private var pending: Parsed? = null
    private lateinit var speaker: Speaker

    private val wakeWords = listOf("myra", "मायरा", "maira", "मैरा", "mira", "मीरा", "मायरे")
    private val fillers = listOf("hello", "हेलो", "हैलो", "हलो", "हेल्लो", "helo", "hey")
    private fun isWake(t: String) = wakeWords.any { t.contains(it) }
    private fun stripWake(t: String): String { var x = t; (wakeWords + fillers).forEach { x = x.replace(it, " ") }; return x.trim() }

    @Volatile private var resumeAt = 0L
    /** Continuous mode: our own always-on mic. No Google recognizer, so no beeps and no restarts. */
    private val mic = ContinuousMic(
        onSpeech = { pcm -> busy = true; scope.launch { onUtterance(pcm) } },
        blocked = { busy || VoiceState.speaking || paused || System.currentTimeMillis() < resumeAt })

    private val intent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(b: Bundle?) {
            lastEvent = System.currentTimeMillis()
            if (handled) return
            handle(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase())
        }
        override fun onPartialResults(b: Bundle?) {
            lastEvent = System.currentTimeMillis()
            if (awake || handled) return
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase()
            if (isWake(t) && stripWake(t).length <= 3) { handled = true; rec?.cancel(); wakeUp() }
        }
        override fun onError(e: Int) {
            lastEvent = System.currentTimeMillis()
            if (handled) return
            when (e) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(60)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { rec?.cancel(); restart(800) }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> restart(3000)
                else -> restart(400)
            }
        }
        override fun onRmsChanged(r: Float) { lastEvent = System.currentTimeMillis(); VoiceState.level = VoiceState.level * 0.6f + (r.coerceIn(0f, 10f) / 10f) * 0.4f }
        override fun onReadyForSpeech(p: Bundle?) { lastEvent = System.currentTimeMillis() }
        override fun onBeginningOfSpeech() {}; override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() { Beep.hush(this@WakeWordService) }; override fun onEvent(t: Int, b: Bundle?) {}
    }

    /** If the recognizer goes silent for 30 s (killed mic, hung service) rebuild it. */
    private val watchdog = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (!paused) {
                if (busy && now - busySince > 60000) { busy = false; listen() }                                   // a task / answer hung
                else if (conv) { if (!mic.running) mic.start() }                                                   // keep the mic alive
                else if (!busy && now - lastEvent > 30000) { rec?.destroy(); rec = null; listen() }               // silent recognizer
            }
            h.postDelayed(this, if (conv) 4000 else 10000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "myra"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "MYRA", NotificationManager.IMPORTANCE_LOW))
        val n = buildNote(false)
        val ok = runCatching {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        }.isSuccess
        if (!ok) { alertRestart(); stopSelf(); return }   // Android refused the mic service from background: open the app once
        speaker = Speaker(this)
        BatteryMonitor.start(this, speaker, scope)
        OverlayManager.showOrb(this)
        listen()
        h.postDelayed(watchdog, 10000)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            "pause" -> { paused = true; mic.stop(); rec?.cancel(); job?.cancel(); awake = false; OverlayManager.awake(false) }
            "conv_start" -> startConv()
            "conv_stop" -> stopConv(true)
            "revive" -> { paused = false; busy = false; awake = false; rec?.destroy(); rec = null; listen() }
        }
        return START_STICKY
    }

    /** One recognizer is reused (no create/destroy flicker). */
    private fun listen() {
        if (paused) return
        if (conv) {
            busy = false; handled = false; VoiceState.speaking = false
            lastEvent = System.currentTimeMillis(); resumeAt = lastEvent + 600      // skip the tail of MYRA's own voice
            if (!mic.running) mic.start()
            return
        }
        busy = false; handled = false; VoiceState.speaking = false; lastEvent = System.currentTimeMillis()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (rec == null) rec = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
        Beep.hush(this); rec?.cancel(); rec?.startListening(intent)
    }

    private fun restart(ms: Long = 150) { job?.cancel(); job = scope.launch { delay(ms); listen() } }

    /** Android refused to restart the mic service in the background: tell the user how to bring MYRA back. */
    private fun alertRestart() = runCatching {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("myra_alert", "MYRA Alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(3, NotificationCompat.Builder(this, "myra_alert").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("MYRA रुक गई").setContentText("दोबारा शुरू करने के लिए यहाँ टैप करो").setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(this, 2, Intent(this, com.myra.ai.MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build())
    }

    private val stopWords = listOf("बंद करो", "बंद कर दो", "स्टॉप", "stop", "रुक जाओ", "बस करो", "exit", "अलविदा", "bye", "बात बंद")

    private fun buildNote(c: Boolean): Notification {
        val b = NotificationCompat.Builder(this, "myra")
            .setContentTitle(if (c) "MYRA बात कर रही है" else "MYRA सुन रही है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
        if (c) b.addAction(0, "बंद करो", PendingIntent.getService(this, 1,
            Intent(this, WakeWordService::class.java).setAction("conv_stop"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        return b.build()
    }

    private fun showNote(c: Boolean) = getSystemService(NotificationManager::class.java).notify(1, buildNote(c))

    /** Voice Assistant button: talk non-stop, no wake word, in any app, until stopped. */
    private fun startConv() {
        getSharedPreferences("myra", MODE_PRIVATE).edit().putString("conv_on", "1").apply()   // resume automatically if the app restarts
        if (conv) { paused = false; busy = false; listen(); return }
        conv = true; paused = false; busy = true; awake = true
        VoiceState.on = true; VoiceState.line = "सुन रही हूँ..."
        OverlayManager.showOrb(this); OverlayManager.awake(true); showNote(true)
        rec?.cancel(); job?.cancel()
        scope.launch { speaker.say("जी बॉस, मैं सुन रही हूँ। बोलिए।") { listen() } }
    }

    private fun stopConv(speak: Boolean) {
        getSharedPreferences("myra", MODE_PRIVATE).edit().putString("conv_on", "").apply()
        conv = false; awake = false; mic.stop()
        VoiceState.on = false; VoiceState.speaking = false; VoiceState.line = ""
        OverlayManager.awake(false); showNote(false)
        val keep = getSharedPreferences("myra", MODE_PRIVATE).getString("wake", "") != "off"
        scope.launch {
            if (speak) speaker.sayWait("ठीक है बॉस, बात बंद कर रही हूँ।")
            if (keep) listen() else stopSelf()
        }
    }

    private fun wakeUp() {
        awake = true; busy = true; OverlayManager.awake(true)
        scope.launch { speaker.say("जी बॉस") { listen() } }
    }

    private suspend fun onUtterance(pcm: ByteArray) {
        VoiceState.line = "✍ समझ रही हूँ..."
        val key = getSharedPreferences("myra", MODE_PRIVATE).getString("gemini_key", "") ?: ""
        val text = Transcriber.text(key, pcm)
        if (text == null) { listen(); return }          // noise / unclear: just keep listening
        handle(text.lowercase())
    }

    private fun handle(said: String) {
        if (conv) {
            if (said.isBlank()) { restart(60); return }
            if (stopWords.any { said.contains(it) }) { stopConv(true); return }
            busy = true; VoiceState.line = "🎤 $said"
            scope.launch { command(said) }
            return
        }
        if (!awake) {
            if (!isWake(said)) { restart(60); return }
            val rest = stripWake(said)
            if (rest.length <= 3) { wakeUp(); return }          // only "Hello Myra"
            busy = true; OverlayManager.awake(true)              // "Hello Myra <command>" in one go
            scope.launch { OverlayManager.awake(false); command(rest) }
            return
        }
        awake = false; busy = true; OverlayManager.awake(false)
        scope.launch { command(said) }
    }

    private suspend fun command(said: String) {
        try { commandInner(said) }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) {
            VoiceState.line = ("⚠ " + e.message).take(80)
            speaker.say("बॉस, कुछ गड़बड़ हो गई, फिर से बोलिए।") { listen() }
        }
    }

    private suspend fun commandInner(said: String) {
        VoiceState.speaking = true
        val prefs = getSharedPreferences("myra", MODE_PRIVATE)
        val model = prefs.getString("model", "") ?: ""
        if (GeminiClient.preferred != model) GeminiClient.preferred = model
        val p0 = pending
        pending = null
        val p = if (p0 != null) p0.copy(name = if (p0.kind == "alarm") TaskRunner.timeOf(said) else said.trim())
                else TaskRunner.parseSmart(this, said)
        when {
            p == null -> {
                if (com.myra.ai.ai.GeminiTools.needsSearch(said)) speaker.sayWait("ठीक है बॉस, इंटरनेट पर खोज रही हूँ।")
                val ans = Brain.answer(this, said); VoiceState.line = ans.take(140)
                speaker.say(ans) { listen() }
            }
            p.kind == "battery" -> speaker.say(BatteryMonitor.statusText(this)) { listen() }
            p.kind == "unlock" -> speaker.say("बॉस, PIN या पैटर्न वाला फ़ोन ऐप से अनलॉक नहीं हो सकता, यह Android की सुरक्षा है। फिंगरप्रिंट या फेस अनलॉक इस्तेमाल करो।") { listen() }
            p.name == null && TaskRunner.question(p.kind) != null -> {
                pending = p
                speaker.say(TaskRunner.question(p.kind)!!) { awake = true; OverlayManager.awake(true); listen() }
            }
            else -> {
                val msg = TaskRunner.execute(this, p, TaskRunner.steps(this, p)) { speaker.sayWait(it) }
                VoiceState.line = msg; speaker.say(msg) { listen() }
            }
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(watchdog); VoiceState.on = false
        rec?.destroy(); mic.stop(); Beep.restore(); BatteryMonitor.stop(this); if (::speaker.isInitialized) speaker.shutdown()
        OverlayManager.hideOrb(); scope.cancel(); super.onDestroy()
    }
}
