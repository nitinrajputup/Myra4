package com.myra.ai.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale

/**
 * Speaks with ElevenLabs if keys are saved; otherwise (or on failure) with the phone's Hindi voice.
 * `done` is ALWAYS called (even if the voice fails) so the caller never gets stuck waiting.
 */
class Speaker(private val ctx: Context) {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile var hindiOk = true
    private val main = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("hi", "IN"))
                hindiOk = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                ready = true
                if (!hindiOk) main.post {
                    Toast.makeText(ctx, "Hindi आवाज़ नहीं मिली: फ़ोन Settings → Text-to-speech में Hindi डाउनलोड करो", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    suspend fun say(text: String, done: () -> Unit = {}) {
        var fin = false
        val finish: () -> Unit = { if (!fin) { fin = true; main.post { done() } } }
        val p = ctx.getSharedPreferences("myra", Context.MODE_PRIVATE)
        val ek = p.getString("eleven_key", "").orEmpty().trim()
        val vid = p.getString("voice_id", "").orEmpty().trim()
        if (ek.isNotBlank() && vid.isNotBlank() && ElevenLabsTts(ctx, ek, vid).speak(text) { finish() }) {
            main.postDelayed({ finish() }, 60000); return
        }
        var w = 0
        while (!ready && w < 15) { delay(200); w++ }
        val t = tts
        if (t == null || !ready) { finish(); return }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { finish() }
            @Deprecated("deprecated in Java")
            override fun onError(id: String?) { finish() }
        })
        if (t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "myra") == TextToSpeech.ERROR) finish()
        else main.postDelayed({ finish() }, 25000)
    }

    /** Speaks and waits until finished (used to narrate each step before doing it). */
    suspend fun sayWait(text: String) {
        val d = CompletableDeferred<Unit>()
        say(text) { d.complete(Unit) }
        withTimeoutOrNull(15000) { d.await() }
    }

    fun shutdown() { tts?.stop(); tts?.shutdown() }
}
