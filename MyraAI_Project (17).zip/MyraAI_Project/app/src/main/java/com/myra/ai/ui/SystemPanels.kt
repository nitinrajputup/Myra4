package com.myra.ai.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.myra.ai.ai.LiveVoice
import com.myra.ai.data.Store
import com.myra.ai.service.MyraAccessibilityService
import com.myra.ai.service.WakeWordService
import com.myra.ai.voice.Speaker
import kotlinx.coroutines.launch

private fun svc(ctx: Context, action: String) {
    if (Store(ctx).get("wake") != "off")
        runCatching { ctx.startForegroundService(Intent(ctx, WakeWordService::class.java).setAction(action)) }
}

@Composable
private fun Check(ok: Boolean, label: String, btn: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text((if (ok) "✅ " else "❌ ") + label, color = Color.White, modifier = Modifier.weight(1f), fontSize = 14.sp)
        if (!ok) OutlinedButton(onClick) { Text(btn) }
    }
}

/** Everything MYRA needs to stay alive in the background, with one-tap fixes. */
@Composable
fun SetupPanel(store: Store) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tick by remember { mutableStateOf(0) }
    val speaker = remember { Speaker(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    val t = tick
    val pkgUri = Uri.parse("package:" + ctx.packageName)
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Check(ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
            "Microphone permission", "खोलो") { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri)) }
        Check(Settings.canDrawOverlays(ctx), "Overlay (ऊपर animation + background में माइक)", "ON करो") {
            ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri)) }
        Check(ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName),
            "Battery optimization बंद (ज़रूरी, वरना फ़ोन MYRA को मार देता है)", "बंद करो") {
            ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri)) }
        Check(NotificationManagerCompat.from(ctx).areNotificationsEnabled(), "Notifications", "ON करो") {
            ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)) }
        Check(MyraAccessibilityService.instance != null, "Accessibility (tap / call / lock)", "ON करो") {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        Spacer(Modifier.height(8.dp))
        Button({ svc(ctx, "revive"); tick++ }) { Text("▶ MYRA background दोबारा शुरू करो") }
        OutlinedButton({ scope.launch { speaker.say("नमस्ते बॉस, मैं मायरा बोल रही हूँ।") } }) { Text("🔊 आवाज़ टेस्ट") }
        OutlinedButton({ runCatching { ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS")) } }) { Text("Hindi आवाज़ डाउनलोड (Text-to-speech)") }
        OutlinedButton({ tick++ }) { Text("🔄 दोबारा जाँचो") }
        Text("Realme / Vivo / Oppo / Xiaomi: App info में Autostart ON और Battery 'No restrictions' करो। मीडिया volume भी चालू रखो.",
            color = Color.Gray, fontSize = 12.sp)
    }
}

/** Gemini Live (gemini-3.8-live): talk in real time. Pauses the wake-word listener while open. */
@Composable
fun LivePanel(store: Store) {
    val ctx = LocalContext.current
    var status by remember { mutableStateOf("बंद") }
    var model by remember { mutableStateOf(store.get("live_model").ifBlank { "gemini-3.8-live" }) }
    val holder = remember { arrayOfNulls<LiveVoice>(1) }
    DisposableEffect(Unit) { onDispose { if (holder[0] != null) { holder[0]?.stop(); holder[0] = null; svc(ctx, "revive") } } }
    Column(Modifier.verticalScroll(rememberScrollState())) {
        F("Live model ID", model) { model = it; store.set("live_model", it.trim()) }
        Row {
            Button({
                val key = store.get("gemini_key")
                if (key.isBlank()) { status = "पहले Settings में Gemini API Key डालो"; return@Button }
                holder[0]?.stop(); svc(ctx, "pause")
                val sys = "तुम MYRA हो, यूज़र की हिंदी वॉइस असिस्टेंट। यूज़र को बॉस बोलो, हिंदी में छोटे जवाब दो।" +
                    (if (store.get("p_name").isNotBlank()) " यूज़र का नाम ${store.get("p_name")} है।" else "") +
                    " याद की हुई बातें: " + store.memories().takeLast(40).joinToString("; ")
                val lv = LiveVoice(key, model.trim(), sys) { status = it }
                holder[0] = lv; lv.start()
            }) { Text("▶ Live शुरू") }
            Spacer(Modifier.width(8.dp))
            OutlinedButton({ holder[0]?.stop(); holder[0] = null; svc(ctx, "revive") }) { Text("■ बंद") }
        }
        Text(status, color = Color.White, modifier = Modifier.padding(top = 12.dp))
        Text("बेहतर होगा कि earphone लगाओ, वरना MYRA अपनी ही आवाज़ सुन सकती है।", color = Color.Gray, fontSize = 12.sp)
    }
}
