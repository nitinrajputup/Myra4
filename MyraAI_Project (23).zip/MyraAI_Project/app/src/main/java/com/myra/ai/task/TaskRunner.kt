package com.myra.ai.task

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import com.myra.ai.ai.GeminiClient
import com.myra.ai.overlay.OverlayManager
import org.json.JSONArray
import com.myra.ai.service.MyraAccessibilityService
import kotlinx.coroutines.delay

data class Parsed(val kind: String, val pkg: String?, val name: String?, val video: Boolean, val label: String? = null)

/** Understands phone commands and runs them step by step: MYRA SPEAKS before every step and after the result. */
object TaskRunner {
    private val alias = mapOf("व्हाट्सएप" to "whatsapp", "वॉट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp",
        "व्हाट्सअप" to "whatsapp", "यूट्यूब" to "youtube", "इंस्टाग्राम" to "instagram", "फेसबुक" to "facebook",
        "क्रोम" to "chrome", "गूगल" to "google", "कैमरा" to "camera", "टिकटॉक" to "tiktok")
    private val stop = setOf("video", "वीडियो", "call", "कॉल", "कर", "करो", "दो", "पर", "से", "को", "on", "to",
        "whatsapp", "फोन", "please", "प्लीज", "मायरा", "myra")
    private val songStop = setOf("youtube", "पर", "चलाओ", "चला", "play", "गाना", "गाने", "सुनाओ", "सुना", "करो", "दो", "को", "का", "की")

    /** name = card label, say = spoken before the step, fail = spoken if it fails. */
    class Step(val name: String, val say: String, val fail: String, val action: suspend () -> Boolean)

    fun question(kind: String): String? =
        mapOf("call" to "किसको कॉल करूँ?", "alarm" to "कितने बजे का अलार्म लगाऊँ?", "yt_play" to "कौन सा गाना चलाऊँ?")[kind]

    fun apps(ctx: Context): Map<String, String> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(i, 0).associate { it.loadLabel(pm).toString().lowercase() to it.activityInfo.packageName }
    }

    private fun nameOf(s: String): String? {
        val raw = Regex("(.+?)\\s+को(?=\\s|$)").find(s)?.groupValues?.get(1)
            ?: Regex("(?:call|कॉल)\\s+(?:to\\s+)?(.+)").find(s)?.groupValues?.get(1) ?: return null
        val n = raw.split(" ").filter { it.isNotBlank() && it !in stop }.joinToString(" ")
        return n.ifBlank { null }
    }

    /** "6:30", "6 30", "शाम 6 बजे" -> "18:30" */
    fun timeOf(s: String): String? {
        val m = Regex("(\\d{1,2})(?:[:.\\s]+(\\d{2}))?").find(s) ?: return null
        var h = m.groupValues[1].toInt(); val min = m.groupValues[2].ifBlank { "0" }.toInt()
        val pm = s.contains("शाम") || s.contains("रात") || s.contains("pm") || s.contains("दोपहर")
        if (pm && h < 12) h += 12
        return if (h < 24 && min < 60) "$h:$min" else null
    }

    private fun songOf(ctx: Context, s: String): String? {
        if (s.contains("मेरा गाना") || s.contains("my song"))
            return ctx.getSharedPreferences("myra", Context.MODE_PRIVATE).getString("p_song", "")?.ifBlank { null }
        return s.split(" ").filter { it.isNotBlank() && it !in songStop }.joinToString(" ").ifBlank { null }
    }

    private val openWords = listOf("open", "ओपन", "खोल", "चालू", "स्टार्ट", "start", "launch", "लॉन्च", "चला")

    /** Like [parse], but if the app name was said in Hindi letters ("टिकटॉक ओपन करो"), the brain matches it to an installed app. */
    private val uiVerbs = listOf("टैप", "क्लिक", "दबा", "स्वाइप", "स्क्रॉल", "स्क्रोल", "टाइप", "लिख", "भेज", "खोल", "ओपन",
        "tap", "click", "swipe", "scroll", "type", "open", "send")
    private val btnMap = mapOf("सेंड" to "Send", "भेजें" to "Send", "सर्च" to "Search", "ओके" to "OK", "लाइक" to "Like", "फॉलो" to "Follow",
        "शेयर" to "Share", "कमेंट" to "Comment", "प्ले" to "Play", "सब्सक्राइब" to "Subscribe", "मैसेज" to "Message")

    /** Several actions in one sentence ("WhatsApp खोलो और नाबिन को हाय भेजो"): the brain turns it into steps. */
    private suspend fun plan(ctx: Context, said: String): Parsed? {
        val key = ctx.getSharedPreferences("myra", Context.MODE_PRIVATE).getString("gemini_key", "") ?: ""
        if (key.isBlank()) return null
        val raw = GeminiClient.raw(key, "तुम एक Android फ़ोन ऑपरेटर हो। यूज़र का आदेश छोटे कदमों की JSON array में बदलो। हर कदम इनमें से एक: " +
            "{\"a\":\"open\",\"app\":\"<नीचे की सूची से हुबहू नाम>\"}, {\"a\":\"tap\",\"text\":\"<बटन/नाम का स्क्रीन पर दिखने वाला टेक्स्ट>\"}, " +
            "{\"a\":\"type\",\"text\":\"...\"}, {\"a\":\"swipe\",\"dir\":\"up|down|left|right\"}, {\"a\":\"back\"}, {\"a\":\"home\"}, " +
            "{\"a\":\"wait\",\"sec\":2}। सिर्फ़ JSON array दो, ज़्यादा से ज़्यादा 8 कदम।\nऐप: " + apps(ctx).keys.joinToString(", ") + "\nआदेश: $said")
        val arr = runCatching { JSONArray(raw.substring(raw.indexOf('['), raw.lastIndexOf(']') + 1)) }.getOrNull() ?: return null
        return if (arr.length() in 1..8) Parsed("plan", null, arr.toString(), false) else null
    }

    private suspend fun tapAny(s: MyraAccessibilityService, text: String): Boolean =
        retry { s.clickText(text) || (btnMap[text]?.let { s.clickText(it) } ?: false) }

    private suspend fun launch(ctx: Context, pkg: String?): Boolean {
        val i = pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) } ?: return false
        val ok = runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess
        delay(2200); return ok
    }

    private val ytMarkers = listOf("pause video", "minimize", "enter fullscreen", "rewind 10", "वीडियो रोकें", "छोटा करें", "फ़ुलस्क्रीन")

    private val moreVerbs = listOf("सर्च", "search", "खोज", "भेज", "send", "टाइप", "लिख", "लाइक", "like", "कॉल", "call", "मैसेज",
        "message", "फॉलो", "follow", "शेयर", "share", "स्क्रॉल", "scroll", "क्लिक", "टैप", "दबा", "फिर", "उसके बाद", " और ", " then ")
    private val hereVerbs = listOf("सर्च", "search", "खोज", "play", "प्ले", "चला", "बजा", "गाना", "सुना", "लाइक", "like", "सब्सक्राइब",
        "subscribe", "फॉलो", "follow", "भेज", "send", "कमेंट", "comment", "शेयर", "share", "सेव", "save", "डाउनलोड", "download")
    private val webHints = listOf("इंटरनेट", "internet", "गूगल", "google", "वेब", "web", "न्यूज़", "news", "मौसम", "weather")

    private fun isHome(ctx: Context, pkg: String) = pkg.contains("systemui") ||
        ctx.packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName == pkg
    private fun isBrowser(pkg: String) = listOf("chrome", "browser", "firefox", "opera", "brave", "edge").any { pkg.contains(it) }

    private val simple = setOf("type", "swipe", "global", "tap", "call", "alarm", "lock", "battery", "unlock", "copy", "paste",
        "yt_play", "yt_skip", "yt_like", "insta_like", "insta_post", "search")

    suspend fun parseSmart(ctx: Context, said: String): Parsed? {
        val s = said.lowercase()
        val p = parse(ctx, said)
        if (p != null && p.kind in simple) return p
        val compound = listOf(" और ", "फिर", "उसके बाद", " then ", " and ").any { s.contains(it) } && uiVerbs.any { s.contains(it) }
        // several actions, or "open X and ...": the agent reads the screen and continues step by step (never stops after opening)
        if (compound || (p != null && p.kind == "open" && moreVerbs.any { s.contains(it) })) return Parsed("agent", null, said, false)
        if (p != null) return p
        if (moreVerbs.any { s.contains(it) } && apps(ctx).keys.any { it.length > 2 && s.contains(it) }) return Parsed("agent", null, said, false)
        // No app named, but the phone is already INSIDE some app: "गाना सर्च करके प्ले करो" means that app.
        // (Before, this went to the chat brain, which only SAID it was done.)
        val a11y = MyraAccessibilityService.instance
        if (a11y != null && hereVerbs.any { s.contains(it) } && webHints.none { s.contains(it) }) {
            val fg = a11y.currentPkg()
            if (fg.isNotBlank() && fg != ctx.packageName && !isHome(ctx, fg) && !isBrowser(fg)) return Parsed("agent", null, said, false)
        }
        if (openWords.none { s.contains(it) }) return null
        val installed = apps(ctx)
        val key = ctx.getSharedPreferences("myra", Context.MODE_PRIVATE).getString("gemini_key", "") ?: ""
        if (key.isBlank() || installed.isEmpty()) return null
        val reply = GeminiClient.raw(key, "फ़ोन में ये ऐप हैं: " + installed.keys.joinToString(", ") +
            "\nयूज़र ने कहा: \"$said\"\nअगर यूज़र इनमें से कोई ऐप खोलना चाहता है तो सिर्फ़ उस ऐप का सूची वाला नाम हुबहू लिखो, वरना सिर्फ़ NONE लिखो।")
            .trim().trim('"', '.', '\'').lowercase()
        val hit = installed.entries.firstOrNull { it.key == reply } ?: return null
        return Parsed("open", hit.value, null, false, hit.key)
    }

    /** null = not a phone task (send it to the brain). */
    fun parse(ctx: Context, said: String): Parsed? {
        var s = said.lowercase().trim()
        alias.forEach { (k, v) -> s = s.replace(k, v) }
        val tk = s.split(Regex("\\s+")).toSet()
        fun has(vararg w: String) = w.any { it in tk }
        // "टाइप करो <text> (और भेज दो)"
        Regex("^(?:.*?\\s)?(?:टाइप करो|टाइप कर दो|टाइप|type|लिखो|लिख दो|लिखिए)\\s+(.+)$", RegexOption.IGNORE_CASE)
            .find(said.trim())?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }?.let { raw ->
                val send = Regex("\\s*(?:और\\s+)?(?:भेज दो|भेजो|भेज दे|send)$", RegexOption.IGNORE_CASE)
                return Parsed("type", null, raw.replace(send, "").trim(), false, if (send.containsMatchIn(raw)) "send" else null)
            }
        // swipe / scroll
        val scroll = has("scroll", "स्क्रॉल", "स्क्रोल")
        if (scroll || has("swipe", "स्वाइप", "स्वाइपे")) {
            var d = when {
                has("ऊपर", "up") -> "up"
                has("नीचे", "down") -> "down"
                has("बाएं", "बायें", "बाएँ", "left") -> "left"
                has("दाएं", "दायें", "दाएँ", "right") -> "right"
                else -> if (scroll) "down" else "up"
            }
            if (scroll) d = mapOf("up" to "down", "down" to "up", "left" to "right", "right" to "left")[d] ?: d
            return Parsed("swipe", null, d, false)
        }
        // back / home / recents / notifications / screenshot
        if (tk.size <= 5) {
            val g = when {
                has("back", "वापस", "पीछे") -> "back"
                has("home", "होम") -> "home"
                has("recents", "recent", "रीसेंट") -> "recents"
                has("notifications", "नोटिफिकेशन") -> "notifications"
                has("screenshot", "स्क्रीनशॉट") -> "screenshot"
                else -> null
            }
            if (g != null) return Parsed("global", null, g, false)
        }
        // "X पर टैप करो" / "tap X"
        (Regex("(?:tap|click|press)(?:\\s+on)?\\s+(.+)").find(s)?.groupValues?.get(1)
            ?: Regex("(.+?)\\s+(?:पर\\s+)?(?:टैप|क्लिक|दबाओ|दबा दो|प्रेस)").find(s)?.groupValues?.get(1))
            ?.trim()?.takeIf { it.isNotBlank() }?.let { return Parsed("tap", null, it, false) }
        if (s.contains("battery") || s.contains("बैटरी")) return Parsed("battery", null, null, false)
        if (has("unlock", "अनलॉक")) return Parsed("unlock", null, null, false)
        if (has("lock", "लॉक")) return Parsed("lock", null, null, false)
        if (s.contains("alarm") || s.contains("अलार्म")) return Parsed("alarm", null, timeOf(s), false)
        if (has("copy", "कॉपी")) return Parsed("copy", null, null, false)
        if (has("paste", "पेस्ट")) return Parsed("paste", null, null, false)
        if (has("skip", "स्किप")) return Parsed("yt_skip", null, null, false)
        if (s.contains("youtube")) {
            if (has("like", "लाइक")) return Parsed("yt_like", null, null, false)
            if (s.contains("चला") || s.contains("play") || s.contains("गाना") || s.contains("सुना"))
                return Parsed("yt_play", null, songOf(ctx, s), false, "YouTube")
        }
        if (s.contains("instagram")) {
            if (has("like", "लाइक")) return Parsed("insta_like", null, null, false)
            if (listOf("post", "पोस्ट", "reel", "रील", "story", "स्टोरी", "upload", "अपलोड").any { s.contains(it) })
                return Parsed("insta_post", "com.instagram.android", null, false, "Instagram")
        }
        val isCall = s.contains("call") || s.contains("कॉल")
        val video = s.contains("video") || s.contains("वीडियो")
        val installed = apps(ctx)
        val app = installed.entries.firstOrNull { it.key.length > 2 && s.contains(it.key) }
        val open = openWords.any { s.contains(it) }
        // "YouTube पर X सर्च करो", "गूगल पर X खोजो"
        val searchVerb = listOf("सर्च", "search", "खोजो", "खोज", "ढूंढ", "ढूँढ").any { s.contains(it) }
        val web = listOf("google", "chrome", "browser", "ब्राउज़र", "ब्राउजर").any { s.contains(it) }
        if (searchVerb && (app != null || web)) {
            val drop = songStop + stop + setOf("सर्च", "search", "खोजो", "खोज", "ढूंढो", "ढूँढो", "में", "for", "on", "करके",
                "google", "chrome", "browser", "ब्राउज़र", "ब्राउजर") + (app?.key?.split(" ") ?: emptyList())
            val q = s.split(" ").filter { it.isNotBlank() && it !in drop }.joinToString(" ")
            if (q.isNotBlank()) return Parsed("search", if (web && app == null) null else app?.value, q, false, if (app == null) "google" else app.key)
        }
        if (isCall) return Parsed("call", app?.value ?: "com.whatsapp", nameOf(s), video, app?.key ?: "WhatsApp")
        if (open && app != null) return Parsed("open", app.value, null, false, app.key)
        return null
    }

    private suspend fun retry(f: suspend () -> Boolean): Boolean {
        repeat(3) { if (f()) return true; delay(700) }
        return false
    }

    private fun setAlarm(ctx: Context, t: String): Boolean = runCatching {
        val (h, m) = t.split(":").map { it.toInt() }
        ctx.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_MESSAGE, "MYRA")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    }.getOrDefault(false)

    fun steps(ctx: Context, p: Parsed): List<Step> {
        val svc = { MyraAccessibilityService.instance }
        val app = p.label ?: "ऐप"
        val open = Step("Open App", "$app खोल रही हूँ", "$app नहीं खुल पाया") {   // plain launch: no Accessibility needed
            val pkg = p.pkg ?: return@Step false
            val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return@Step false
            runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess.also { delay(2200) }
        }
        when (p.kind) {
            "agent" -> return listOf(Step("AI Agent", "ठीक है बॉस, करती हूँ", "यह काम पूरा नहीं हो पाया") { PhoneAgent.run(ctx, p.name ?: "") })
            "search" -> {
                val q = p.name ?: return emptyList()
                val lab = (p.label ?: "").lowercase()
                val enc = Uri.encode(q)
                val i: Intent? = when {
                    lab == "youtube" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$enc")).setPackage("com.google.android.youtube")
                    lab == "google" || lab == "chrome" || p.pkg == null -> Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
                    lab.contains("maps") -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$enc"))
                    lab.contains("play store") -> Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=$enc"))
                    lab.contains("spotify") -> Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:$enc"))
                    else -> null
                }
                val where = if (lab.isBlank() || lab == "google") "गूगल" else lab
                if (i != null) return listOf(Step("Search", "$where पर $q खोज रही हूँ", "खोज स्क्रीन पर दिखी नहीं") {
                    if (!runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return@Step false
                    val verify = lab != "google" && lab != "chrome" && p.pkg != null      // check the screen (not for plain web search)
                    delay(3000)
                    val s = svc()
                    if (!verify || s == null) true else s.dumpScreen().contains(q.split(" ").first(), ignoreCase = true)
                })
                return listOf(Step("AI Agent", "ठीक है बॉस, $where में $q खोजती हूँ", "खोज नहीं हो पाई") {
                    PhoneAgent.run(ctx, "$where ऐप खोलो और उसमें '$q' सर्च करो") })
            }
            "type" -> return listOf(Step("Type Text", "टाइप कर रही हूँ", "टाइप नहीं हो पाया") {
                val s = svc() ?: return@Step false
                val ok = s.typeInto(p.name ?: "")
                if (ok && p.label == "send") { delay(500); retry { s.clickText("Send") || s.clickText("भेजें") } }
                ok
            })
            "swipe" -> return listOf(Step("Swipe", "स्वाइप कर रही हूँ", "स्वाइप नहीं हो पाया") { svc()?.swipe(p.name ?: "up") ?: false })
            "global" -> {
                val say = mapOf("back" to "पीछे जा रही हूँ", "home" to "होम स्क्रीन पर जा रही हूँ", "recents" to "रीसेंट ऐप्स खोल रही हूँ",
                    "notifications" to "नोटिफिकेशन खोल रही हूँ", "screenshot" to "स्क्रीनशॉट ले रही हूँ")[p.name] ?: "कर रही हूँ"
                return listOf(Step("Action", say, "यह नहीं हो पाया") { svc()?.global(p.name ?: "") ?: false })
            }
            "tap" -> return listOf(Step("Tap Element", "${p.name} दबा रही हूँ", "${p.name} नहीं मिला") {
                val s = svc() ?: return@Step false; tapAny(s, p.name ?: "") })
            "plan" -> {
                val arr = runCatching { JSONArray(p.name ?: "[]") }.getOrNull() ?: return emptyList()
                val installed = apps(ctx)
                return (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i); val txt = o.optString("text")
                    when (o.optString("a")) {
                        "open" -> { val ap = o.optString("app"); Step("Open App", "$ap खोल रही हूँ", "$ap नहीं खुल पाया") { launch(ctx, installed[ap.lowercase()]) } }
                        "tap" -> Step("Tap Element", "$txt दबा रही हूँ", "$txt नहीं मिला") { val s = svc() ?: return@Step false; tapAny(s, txt) }
                        "type" -> Step("Type Text", "टाइप कर रही हूँ", "टाइप नहीं हो पाया") { svc()?.typeInto(txt) ?: false }
                        "swipe" -> Step("Swipe", "स्वाइप कर रही हूँ", "स्वाइप नहीं हो पाया") { svc()?.swipe(o.optString("dir", "up")) ?: false }
                        "back" -> Step("Back", "पीछे जा रही हूँ", "नहीं हो पाया") { svc()?.global("back") ?: false }
                        "home" -> Step("Home", "होम स्क्रीन पर जा रही हूँ", "नहीं हो पाया") { svc()?.global("home") ?: false }
                        "wait" -> Step("Wait", "", "") { delay(o.optInt("sec", 2) * 1000L); true }
                        else -> Step("Skip", "", "") { true }
                    }
                }
            }
            "lock" -> return listOf(Step("Lock Phone", "फ़ोन लॉक कर रही हूँ", "फ़ोन लॉक नहीं हो पाया") { svc()?.lock() ?: false })
            "alarm" -> return listOf(Step("Set Alarm", "अलार्म सेट कर रही हूँ", "अलार्म नहीं लग पाया") { setAlarm(ctx, p.name ?: return@Step false) })
            "copy" -> return listOf(Step("Copy", "कॉपी कर रही हूँ", "कॉपी नहीं हो पाया") { svc()?.copy() ?: false })
            "paste" -> return listOf(Step("Paste", "पेस्ट कर रही हूँ", "पेस्ट नहीं हो पाया") { svc()?.paste() ?: false })
            "yt_skip" -> return listOf(Step("Skip Ad", "ऐड स्किप कर रही हूँ", "स्किप का बटन नहीं मिला") {
                val s = svc() ?: return@Step false; retry { s.clickText("Skip") } })
            "yt_like" -> return listOf(Step("Like Video", "वीडियो लाइक कर रही हूँ", "लाइक का बटन नहीं मिला") {
                val s = svc() ?: return@Step false; retry { s.clickText("like this video") || s.clickText("Like") } })
            "insta_like" -> return listOf(Step("Like Post", "पोस्ट लाइक कर रही हूँ", "लाइक का बटन नहीं मिला") {
                val s = svc() ?: return@Step false; retry { s.clickText("Like") } })
            "insta_post" -> return listOf(open, Step("Tap Create", "क्रिएट बटन दबा रही हूँ", "क्रिएट बटन नहीं मिला") {
                val s = svc() ?: return@Step false; retry { s.clickText("Create") || s.clickText("New post") } })
            "yt_play" -> {
                val q = p.name ?: return emptyList()
                return listOf(
                    Step("Open YouTube", "YouTube पर $q खोज रही हूँ", "YouTube पर खोज दिखी नहीं") {
                        val sent = runCatching {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
                                .setPackage("com.google.android.youtube").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }.isSuccess
                        delay(3500)
                        val s = svc()
                        // really check the screen: YouTube in front and the search words visible
                        sent && (s == null || (s.currentPkg().contains("youtube") && s.dumpScreen().contains(q.split(" ").first(), ignoreCase = true)))
                    },
                    Step("Play Video", "वीडियो चला रही हूँ", "वीडियो चल नहीं पाया") {
                        val s = svc() ?: return@Step false
                        PhoneAgent.run(ctx, "YouTube पर '$q' के सर्च रिज़ल्ट खुले हैं। मिलते-जुलते पहले वीडियो पर टैप करो ताकि वह चलने लगे। " +
                            "प्लेयर दिखे (Pause video / Minimize / Enter fullscreen जैसे बटन) तभी done कहो, उसी टेक्स्ट को proof में लिखकर।") &&
                            ytMarkers.any { s.dumpScreen().contains(it, ignoreCase = true) }      // the player controls must really be on screen
                    })
            }
        }
        if (p.kind == "open") return listOf(open)
        val name = p.name ?: ""
        val tap = Step("Tap Element", "$name को ढूँढ रही हूँ", "$name नहीं मिला") {
            val s = svc() ?: return@Step false
            retry { s.clickText(name) } || retry {
                s.clickText("Search") && run { delay(600); s.typeInto(name) } && run { delay(900); s.clickText(name) }
            }
        }
        val call = Step(if (p.video) "Video Call" else "Call Contact",
            if (p.video) "वीडियो कॉल लगा रही हूँ" else "कॉल लगा रही हूँ", "कॉल का बटन नहीं मिला") {
            val s = svc() ?: return@Step false
            val labels = if (p.video) listOf("Video call", "वीडियो कॉल") else listOf("Voice call", "वॉइस कॉल")
            retry { labels.any { s.clickText(it) } }
        }
        return listOf(open, tap, call)
    }

    private fun doneText(p: Parsed): String = when (p.kind) {
        "call" -> (if (p.video) "वीडियो कॉल" else "कॉल") + " लगा दी बॉस।"
        "open" -> "${p.label ?: "ऐप"} खुल गया बॉस।"
        "alarm" -> "बॉस, ${p.name} बजे का अलार्म लग गया।"
        "lock" -> "फ़ोन लॉक हो गया बॉस।"
        "type" -> "लिख दिया बॉस।"
        "search" -> "खोज दी बॉस, रिज़ल्ट खुल गए हैं।"
        "yt_play" -> "गाना चल रहा है बॉस।"
        else -> "हो गया बॉस।"
    }

    /** Runs the task, speaking each step through [narrate]. Returns the sentence to say at the end. */
    suspend fun execute(ctx: Context, p: Parsed, steps: List<Step>, narrate: (suspend (String) -> Unit)? = null): String {
        if (steps.isEmpty()) return "बॉस, यह काम मुझे समझ नहीं आया।"
        val st = IntArray(steps.size)
        fun show(state: Int) = OverlayManager.task(ctx, steps.mapIndexed { i, s -> s.name to st[i] }, state)
        show(0)
        PhoneAgent.narrate = narrate
        val guarded = p.kind !in setOf("open", "alarm", "lock", "copy", "paste", "search")
        if (guarded) OverlayManager.guardOn(ctx)       // Touch Guard: your touches are blocked while MYRA works
        try {
        for ((i, s) in steps.withIndex()) {
            if (s.say.isNotBlank()) narrate?.invoke(s.say)
            val ok = runCatching { s.action() }.getOrDefault(false)
            st[i] = if (ok) 1 else 2
            if (!ok) {
                show(2)
                val noA11y = MyraAccessibilityService.instance == null && p.kind !in setOf("open", "alarm")
                return if (noA11y) "बॉस, Accessibility चालू नहीं है, उसे ON करो।" else "बॉस, ${s.fail}।"
            }
            show(if (i == steps.lastIndex) 1 else 0)
        }
        return doneText(p)
        } finally { if (guarded) OverlayManager.guardOff() }
    }

    /** For the text panels: same as voice, returns the final sentence. */
    suspend fun runText(ctx: Context, p: Parsed, narrate: (suspend (String) -> Unit)? = null): String {
        if (p.kind == "unlock") return "बॉस, PIN वाला फ़ोन ऐप से अनलॉक नहीं हो सकता। फिंगरप्रिंट या फेस अनलॉक इस्तेमाल करो।"
        if (p.kind == "battery") return com.myra.ai.battery.BatteryMonitor.statusText(ctx)
        if (p.name == null) question(p.kind)?.let { return it }
        return execute(ctx, p, steps(ctx, p), narrate)
    }
}
