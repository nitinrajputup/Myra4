package com.myra.ai.service

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.myra.ai.ai.Brain
import com.myra.ai.ai.LiveVoice
import org.json.JSONArray
import org.json.JSONObject
import com.myra.ai.ai.GeminiClient
import com.myra.ai.battery.BatteryMonitor
import com.myra.ai.overlay.OverlayManager
import com.myra.ai.task.Parsed
import com.myra.ai.task.TaskRunner
import com.myra.ai.voice.Beep
import com.myra.ai.voice.ContinuousMic
import com.myra.ai.voice.Speaker
import com.myra.ai.voice.Transcriber
import kotlinx.coroutines.*

/** Always listening: "Hello Myra" -> orb wakes up -> "जी बॉस" -> phone task / web search / answer. Keeps listening in every app. */
class WakeWordService : Service() {
    // An unexpected error must never kill MYRA: show it, then go back to listening.
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob() +
        CoroutineExceptionHandler { _, e -> VoiceState.line = ("⚠ " + e.message).take(80); VoiceState.speaking = false; restart(500) })
    private val h = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var job: Job? = null
    private var awake = false
    private var handled = false
    @Volatile private var useLive = false       // Gemini Live is the conversation engine
    private var live: LiveVoice? = null
    private var liveFails = 0
    private var paused = false                 // Gemini Live panel is using the mic
    private var busySince = 0L
    @Volatile private var busy = false      // answering / running a task
        set(v) { field = v; if (v) busySince = System.currentTimeMillis() }
    @Volatile private var conv = false      // continuous conversation (own mic, no wake word) until you stop it
    @Volatile private var lastEvent = System.currentTimeMillis()
    private var pending: Parsed? = null
    private lateinit var speaker: Speaker
    companion object { @Volatile var shared: Speaker? = null }   // used by the notification reader

    private val wakeWords = listOf("myra", "मायरा", "maira", "मैरा", "mira", "मीरा", "मायरे")
    private val fillers = listOf("hello", "हेलो", "हैलो", "हलो", "हेल्लो", "helo", "hey")
    private fun isWake(t: String) = wakeWords.any { t.contains(it) }
    private fun stripWake(t: String): String { var x = t; (wakeWords + fillers).forEach { x = x.replace(it, " ") }; return x.trim() }

    @Volatile private var resumeAt = 0L
    private var lastCmd = ""
    private var lastCmdAt = 0L
    private var lastUnclear = 0L

    private fun buzz() { runCatching { getSystemService(Vibrator::class.java).vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE)) } }

    private fun sameAs(a: String, b: String): Boolean {
        val x = a.split(" ").filter { it.length >= 2 }.toSet(); val y = b.split(" ").filter { it.length >= 2 }.toSet()
        if (x.isEmpty() || y.isEmpty()) return false
        return x.intersect(y).size.toFloat() / x.union(y).size >= 0.7f
    }
    /** Continuous mode: our own always-on mic. No Google recognizer, so no beeps and no restarts. */
    private val mic = ContinuousMic(
        onSpeech = { pcm -> busy = true; scope.launch { onUtterance(pcm) } },
        blocked = { busy || VoiceState.speaking || paused },
        holdUntil = { resumeAt })

    private val intent by lazy {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onResults(b: Bundle?) {
            lastEvent = System.currentTimeMillis()
            if (handled) return
            handle(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase())
        }
        override fun onPartialResults(b: Bundle?) {
            lastEvent = System.currentTimeMillis()
            if (awake || handled) return
            val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().lowercase()
            if (isWake(t) && stripWake(t).length <= 3) { handled = true; rec?.cancel(); wakeUp() }
        }
        override fun onError(e: Int) {
            lastEvent = System.currentTimeMillis()
            if (handled) return
            when (e) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(60)
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> { rec?.cancel(); restart(800) }
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> restart(3000)
                else -> restart(400)
            }
        }
        override fun onRmsChanged(r: Float) { lastEvent = System.currentTimeMillis(); VoiceState.level = VoiceState.level * 0.6f + (r.coerceIn(0f, 10f) / 10f) * 0.4f }
        override fun onReadyForSpeech(p: Bundle?) { lastEvent = System.currentTimeMillis() }
        override fun onBeginningOfSpeech() {}; override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() { Beep.hush(this@WakeWordService) }; override fun onEvent(t: Int, b: Bundle?) {}
    }

    /** If the recognizer goes silent for 30 s (killed mic, hung service) rebuild it. */
    private val watchdog = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (!paused) {
                if (busy && now - busySince > 60000) { busy = false; listen() }                                   // a task / answer hung
                else if (conv) { if (useLive) { if (live == null) startLive() } else if (!mic.running) mic.start() }                                                   // keep the mic alive
                else if (!busy && now - lastEvent > 30000) { rec?.destroy(); rec = null; listen() }               // silent recognizer
            }
            h.postDelayed(this, if (conv) 4000 else 10000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "myra"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "MYRA", NotificationManager.IMPORTANCE_LOW))
        val n = buildNote(false)
        val ok = runCatching {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(1, n)
        }.isSuccess
        if (!ok) { alertRestart(); stopSelf(); return }   // Android refused the mic service from background: open the app once
        speaker = Speaker(this); shared = speaker
        BatteryMonitor.start(this, speaker, scope)
        OverlayManager.showOrb(this)
        listen()
        h.postDelayed(watchdog, 10000)
    }

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            "pause" -> { paused = true; mic.stop(); live?.stop(); live = null; rec?.cancel(); job?.cancel(); awake = false; OverlayManager.awake(false) }
            "conv_start" -> startConv()
            "conv_stop" -> stopConv(true)
            "revive" -> { paused = false; busy = false; awake = false; rec?.destroy(); rec = null; listen(); if (conv && useLive && live == null) startLive() }
        }
        return START_STICKY
    }

    /** One recognizer is reused (no create/destroy flicker). */
    private fun listen() {
        if (paused) return
        if (conv) {
            if (useLive) return                                   // Gemini Live handles the mic by itself
            busy = false; handled = false; VoiceState.speaking = false
            lastEvent = System.currentTimeMillis(); resumeAt = lastEvent + 400      // skip the tail of MYRA's own voice
            if (!VoiceState.line.startsWith("⚠")) VoiceState.line = "🎤 बोलिए, मैं सुन रही हूँ"
            if (!mic.running) mic.start()
            return
        }
        busy = false; handled = false; VoiceState.speaking = false; lastEvent = System.currentTimeMillis()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (rec == null) rec = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
        Beep.hush(this); rec?.cancel(); rec?.startListening(intent)
    }

    private fun restart(ms: Long = 150) { job?.cancel(); job = scope.launch { delay(ms); listen() } }

    /** Android refused to restart the mic service in the background: tell the user how to bring MYRA back. */
    private fun alertRestart() = runCatching {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("myra_alert", "MYRA Alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(3, NotificationCompat.Builder(this, "myra_alert").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("MYRA रुक गई").setContentText("दोबारा शुरू करने के लिए यहाँ टैप करो").setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(this, 2, Intent(this, com.myra.ai.MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)).build())
    }

    private val stopWords = listOf("बंद करो", "बंद कर दो", "स्टॉप", "stop", "रुक जाओ", "बस करो", "exit", "अलविदा", "bye", "बात बंद")

    private fun buildNote(c: Boolean): Notification {
        val b = NotificationCompat.Builder(this, "myra")
            .setContentTitle(if (c) "MYRA बात कर रही है" else "MYRA सुन रही है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true)
        if (c) b.addAction(0, "बंद करो", PendingIntent.getService(this, 1,
            Intent(this, WakeWordService::class.java).setAction("conv_stop"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        return b.build()
    }

    private fun showNote(c: Boolean) = getSystemService(NotificationManager::class.java).notify(1, buildNote(c))

    /** Voice Assistant button: talk non-stop, no wake word, in any app, until stopped. */
    private fun startConv() {
        if (conv) return                                   // already running: never disturb a command in progress
        if ((getSharedPreferences("myra", MODE_PRIVATE).getString("gemini_key", "") ?: "").isBlank()) {
            VoiceState.line = "⚠ Gemini API Key खाली है: Settings में डालो"
            scope.launch { speaker.sayWait("बॉस, पहले सेटिंग्स में Gemini की API key डालो। उसके बिना मैं जवाब और खोज नहीं कर पाऊँगी।") }
            return
        }
        getSharedPreferences("myra", MODE_PRIVATE).edit().putString("conv_on", "1").apply()   // resume automatically if the app restarts
        conv = true; paused = false; busy = true; awake = true
        VoiceState.on = true; VoiceState.line = "सुन रही हूँ..."
        OverlayManager.showOrb(this); OverlayManager.awake(true); showNote(true)
        rec?.cancel(); job?.cancel()
        liveFails = 0
        useLive = (getSharedPreferences("myra", MODE_PRIVATE).getString("live_engine", "") ?: "") != "off"
        scope.launch {
            if (MyraAccessibilityService.instance == null)
                speaker.sayWait("बॉस, Accessibility चालू नहीं है। उसके बिना मैं ऐप के अंदर सर्च, प्ले या मैसेज जैसा कुछ नहीं कर पाऊँगी।")
            if (useLive) startLive() else speaker.say("जी बॉस, बोलिए।") { listen() }
        }
    }

    private fun liveTools(withSearch: Boolean): JSONArray {
        fun fn(name: String, desc: String, prop: String, pd: String) = JSONObject().put("name", name).put("description", desc)
            .put("parameters", JSONObject().put("type", "OBJECT")
                .put("properties", JSONObject().put(prop, JSONObject().put("type", "STRING").put("description", pd)))
                .put("required", JSONArray().put(prop)))
        val decls = JSONArray()
            .put(fn("phone_command", "फ़ोन पर कोई भी काम करता है (ऐप खोलना, कॉल, मैसेज, सर्च, होम/पीछे, लॉक, अलार्म, गाना, टाइप, स्वाइप, नोटिफिकेशन, बैटरी) और बताता है कि हुआ या नहीं",
                "command", "यूज़र का हुक्म हिंदी में, जैसे 'व्हाट्सएप खोलो और नाबिन को हाय भेजो'"))
            .put(fn("remember", "यूज़र की कोई बात हमेशा के लिए याद रखता है", "fact", "याद रखने वाली बात, एक छोटा वाक्य"))
        val out = JSONArray().put(JSONObject().put("functionDeclarations", decls))
        if (withSearch) out.put(JSONObject().put("googleSearch", JSONObject()))
        return out
    }

    /** What Gemini Live can do on the phone: it calls these, we run them with the same engine as before. */
    private suspend fun runTool(name: String, args: JSONObject): String {
        val st = com.myra.ai.data.Store(this)
        if (name == "remember") { st.addMemory(args.optString("fact")); return "याद कर लिया" }
        if (name != "phone_command") return "अज्ञात टूल"
        val p = TaskRunner.parseSmart(this, args.optString("command").lowercase()) ?: return "यह फ़ोन का काम समझ नहीं आया"
        return when {
            p.kind == "battery" -> BatteryMonitor.statusText(this)
            p.kind == "readnotifs" -> NotifBus.summary()
            p.kind == "unlock" -> "PIN वाला फ़ोन ऐप से अनलॉक नहीं हो सकता"
            p.name == null && TaskRunner.question(p.kind) != null -> "जानकारी कम है: यूज़र से पूछो — " + TaskRunner.question(p.kind)
            else -> TaskRunner.execute(this, p, TaskRunner.steps(this, p), null)
        }
    }

    private fun startLive() {
        val prefs = getSharedPreferences("myra", MODE_PRIVATE)
        val key = prefs.getString("gemini_key", "") ?: ""
        val model = (prefs.getString("live_model", "") ?: "").ifBlank { "gemini-3.8-live" }
        val st = com.myra.ai.data.Store(this)
        val sys = Brain.persona(st) +
            (if (st.get("p_name").isNotBlank()) " यूज़र का नाम ${st.get("p_name")} है।" else "") +
            " फ़ोन पर कोई भी काम कहा जाए तो phone_command टूल चलाओ और उसका नतीजा देखकर ही बताओ कि हुआ या नहीं। " +
            "यूज़र अपनी कोई ज़रूरी बात बताए तो remember टूल से याद रखो। ताज़ा जानकारी चाहिए तो Google search इस्तेमाल करो। जवाब छोटे और तुरंत दो। " +
            "याद की हुई बातें: " + st.memories().takeLast(40).joinToString("; ")
        live = LiveVoice(key, model, sys, scope, liveTools(liveFails == 0),
            onTool = { n, a -> runTool(n, a) },
            onTurn = { u, a -> Brain.afterAnswer(st, u, a) },
            onEnd = { reason, was -> onLiveEnd(reason, was) }) { VoiceState.line = it }
        live?.start()
    }

    private fun onLiveEnd(reason: String, wasConnected: Boolean) {
        live = null
        if (!conv || !useLive) return
        if (wasConnected) { liveFails = 0; scope.launch { delay(400); if (conv && useLive && live == null) startLive() } }   // session time limit: reconnect
        else {
            liveFails++
            if (liveFails >= 3) {                                   // Live will not start on this key/model: use the normal engine
                useLive = false; busy = true
                scope.launch { speaker.say("बॉस, Live चल नहीं पाया, सामान्य मोड में बात करती हूँ।") { listen() } }
            } else scope.launch { delay(1200); if (conv && useLive && live == null) startLive() }
        }
    }

    private fun stopConv(speak: Boolean) {
        getSharedPreferences("myra", MODE_PRIVATE).edit().putString("conv_on", "").apply()
        conv = false; awake = false; mic.stop(); useLive = false; live?.stop(); live = null
        VoiceState.on = false; VoiceState.speaking = false; VoiceState.line = ""
        OverlayManager.awake(false); showNote(false)
        val keep = getSharedPreferences("myra", MODE_PRIVATE).getString("wake", "") != "off"
        scope.launch {
            if (speak) speaker.sayWait("ठीक है बॉस, बात बंद कर रही हूँ।")
            if (keep) listen() else stopSelf()
        }
    }

    private fun wakeUp() {
        awake = true; busy = true; OverlayManager.awake(true)
        scope.launch { speaker.say("जी बॉस") { listen() } }
    }

    private suspend fun onUtterance(pcm: ByteArray) {
        buzz()                                              // a tiny vibration = "heard you"
        VoiceState.line = "✍ समझ रही हूँ..."
        val t0 = System.currentTimeMillis()
        val hd = Brain.hear(this, pcm)
        if (hd == null) {                                 // noise / unclear
            val longEnough = pcm.size > 16000 * 2 * 12 / 10
            if (longEnough && !VoiceState.line.startsWith("⚠") && System.currentTimeMillis() - lastUnclear > 8000) {
                lastUnclear = System.currentTimeMillis(); VoiceState.speaking = true
                speaker.say("समझ नहीं पाई बॉस, एक बार और बोलिए।") { listen() }
            } else listen()
            return
        }
        val said = hd.text.lowercase()
        if (speaker.isEcho(said)) { listen(); return }                       // that was MYRA's own voice coming back
        val now = System.currentTimeMillis()
        if (sameAs(said, lastCmd) && now - lastCmdAt < 8000) { listen(); return }  // same sentence again: ignore (no double open)
        lastCmd = said; lastCmdAt = now
        // plain chat (no phone action / web search / memory command): answer straight away = 1 AI call in total
        val special = TaskRunner.parse(this, said) != null || com.myra.ai.ai.GeminiTools.needsSearch(said) ||
            listOf("याद र", "भूल", "remember", "forget", "खोल", "ओपन", "open", "बंद", "stop", "सर्च", "search", "खोज", "भेज", "send",
                "टाइप", "लिख", "कॉल", "call", "मैसेज", "message", "चला", "play", "लाइक", "शेयर", "फॉलो", "गाना", "सुना", "बजा", "प्ले", "सब्सक्राइब", "कमेंट", "डाउनलोड", "download").any { said.contains(it) }
        if (conv && !special && hd.reply.isNotBlank()) {
            val sec = (System.currentTimeMillis() - t0) / 100 / 10.0
            VoiceState.line = "⏱ ${sec}s · " + hd.reply.take(110); VoiceState.speaking = true
            Brain.afterAnswer(com.myra.ai.data.Store(this), hd.text, hd.reply)
            speaker.say(hd.reply) { listen() }
            return
        }
        handle(said)
    }

    private fun handle(said: String) {
        if (conv) {
            if (said.isBlank()) { restart(60); return }
            if (stopWords.any { said.contains(it) }) { stopConv(true); return }
            busy = true; VoiceState.line = "🎤 $said"
            scope.launch { command(said) }
            return
        }
        if (!awake) {
            if (!isWake(said)) { restart(60); return }
            val rest = stripWake(said)
            if (rest.length <= 3) { wakeUp(); return }          // only "Hello Myra"
            busy = true; OverlayManager.awake(true)              // "Hello Myra <command>" in one go
            scope.launch { OverlayManager.awake(false); command(rest) }
            return
        }
        awake = false; busy = true; OverlayManager.awake(false)
        scope.launch { command(said) }
    }

    private suspend fun command(said: String) {
        try { commandInner(said) }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) {
            VoiceState.line = ("⚠ " + e.message).take(80)
            speaker.say("बॉस, कुछ गड़बड़ हो गई, फिर से बोलिए।") { listen() }
        }
    }

    private suspend fun commandInner(said: String) {
        VoiceState.speaking = true
        val prefs = getSharedPreferences("myra", MODE_PRIVATE)
        val model = prefs.getString("model", "") ?: ""
        if (GeminiClient.preferred != model) GeminiClient.preferred = model
        val p0 = pending
        pending = null
        val p = if (p0 != null) p0.copy(name = if (p0.kind == "alarm") TaskRunner.timeOf(said) else said.trim())
                else TaskRunner.parseSmart(this, said)
        when {
            p == null -> {
                if (com.myra.ai.ai.GeminiTools.needsSearch(said)) speaker.sayWait("ठीक है बॉस, इंटरनेट पर खोज रही हूँ।")
                val ans = Brain.answer(this, said); VoiceState.line = ans.take(140)
                val bad = ans.startsWith("Error") || ans.startsWith("Network")
                speaker.say(if (bad) "बॉस, अभी जवाब नहीं मिल पाया। API Key या इंटरनेट देखो।" else ans) { listen() }
            }
            p.kind == "battery" -> speaker.say(BatteryMonitor.statusText(this)) { listen() }
            p.kind == "readnotifs" -> speaker.say(NotifBus.summary()) { listen() }
            p.kind == "unlock" -> speaker.say("बॉस, PIN या पैटर्न वाला फ़ोन ऐप से अनलॉक नहीं हो सकता, यह Android की सुरक्षा है। फिंगरप्रिंट या फेस अनलॉक इस्तेमाल करो।") { listen() }
            p.name == null && TaskRunner.question(p.kind) != null -> {
                pending = p
                speaker.say(TaskRunner.question(p.kind)!!) { awake = true; OverlayManager.awake(true); listen() }
            }
            else -> {
                val msg = TaskRunner.execute(this, p, TaskRunner.steps(this, p)) { scope.launch { speaker.say(it) } }   // talk AND act at the same time
                VoiceState.line = msg; speaker.say(msg) { listen() }
            }
        }
    }

    override fun onDestroy() {
        h.removeCallbacks(watchdog); VoiceState.on = false
        rec?.destroy(); mic.stop(); live?.stop(); Beep.restore(); shared = null; BatteryMonitor.stop(this); if (::speaker.isInitialized) speaker.shutdown()
        OverlayManager.hideOrb(); scope.cancel(); super.onDestroy()
    }
}
