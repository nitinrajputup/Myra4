package com.myra.ai.service

import android.app.admin.DeviceAdminReceiver

/** Lets MYRA lock the screen even when Accessibility is off (Device admin: force-lock only). */
class MyraAdminReceiver : DeviceAdminReceiver()
