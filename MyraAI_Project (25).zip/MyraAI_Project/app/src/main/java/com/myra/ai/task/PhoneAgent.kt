package com.myra.ai.task

import android.content.Context
import android.content.Intent
import com.myra.ai.ai.GeminiClient
import com.myra.ai.service.MyraAccessibilityService
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/**
 * Looks at the screen (Accessibility), asks Gemini for the NEXT move, does it, and repeats until the goal is done.
 * This is what lets MYRA go on after opening an app: search inside it, tap, type, send, scroll...
 */
object PhoneAgent {
    @Volatile var narrate: (suspend (String) -> Unit)? = null

    suspend fun run(ctx: Context, goal: String): Boolean {
        val s = MyraAccessibilityService.instance ?: return false
        val key = ctx.getSharedPreferences("myra", Context.MODE_PRIVATE).getString("gemini_key", "") ?: ""
        if (key.isBlank()) return false
        val installed = TaskRunner.apps(ctx)
        val hist = StringBuilder()
        var fails = 0; var lastSig = ""; var same = 0; var acted = 0
        for (step in 1..10) {
            delay(1000)
            val pkgNow = s.currentPkg()
            val screen = "current app: $pkgNow\n" + s.dumpScreen()
            val prompt = """You control an Android phone through accessibility. GOAL: $goal
Installed apps: ${installed.keys.joinToString(", ")}
Current screen (id: "text" kind; kind btn = tappable, edit = text field):
$screen
Steps already done:
$hist
Choose the NEXT single action. Reply ONLY with JSON:
{"a":"tap|type|enter|swipe|back|home|open|wait|done|fail","id":<number from the screen list>,"text":"<text to type>","dir":"up|down|left|right","app":"<exact installed app name, for open>","say":"<very short Hindi sentence about what you are doing NOW, like 'सर्च बॉक्स में लिख रही हूँ'; never say it is finished>","proof":"<only for done: exact text copied from the screen list>"}
Never use open for an app that is already the current app. Say "done" ONLY when the current screen list already SHOWS the goal achieved, and put in "proof" an exact piece of text copied from the screen list that proves it (a result title, 'Pause video', the sent message...). Typing the words into a search box is NOT proof. If you cannot point to real proof, do the next action instead of saying done. Use "fail" only if it is impossible. To search: tap the search field/icon, type the text, then use enter."""
            val raw = GeminiClient.generate(key, JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("responseMimeType", "application/json")), fastOnly = true)
            val j = runCatching { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) }.getOrNull() ?: return false
            val say = j.optString("say")
            if (say.isNotBlank()) narrate?.invoke(say)
            val a = j.optString("a")
            var ok = true
            when (a) {
                "done" -> {
                    val proof = j.optString("proof").trim()
                    // believe "done" only if it acted, and the proof text really is on screen (and is not just the words we typed)
                    if (acted > 0 && proof.length >= 3 && screen.contains(proof, ignoreCase = true) && !goal.contains(proof, ignoreCase = true)) return true
                    ok = false
                }
                "fail" -> return false
                "tap" -> ok = s.tapNode(j.optInt("id", -1))
                "type" -> ok = s.typeNode(j.optInt("id", -1), j.optString("text"))
                "enter" -> ok = s.enter() || s.clickText("Search")
                "swipe" -> ok = s.swipe(j.optString("dir", "up"))
                "back", "home" -> ok = s.global(a)
                "open" -> {
                    val pkg = installed[j.optString("app").lowercase()]
                    val i = pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
                    if (pkg != null && pkg == pkgNow) ok = true            // already open: do NOT open it again
                    else { ok = i != null && runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess; delay(1500) }
                }
                "wait" -> delay(1500)
                else -> ok = false
            }
            hist.append("$step. $j -> ${if (ok) "ok" else "FAILED"}\n")
            if (ok && a != "wait") acted++
            fails = if (ok) 0 else fails + 1
            val sig = a + j.optInt("id", -1) + j.optString("text") + j.optString("app")
            same = if (sig == lastSig) same + 1 else 0; lastSig = sig
            if (fails >= 3 || same >= 2) return false                    // stuck: stop instead of repeating forever
        }
        return false
    }
}
