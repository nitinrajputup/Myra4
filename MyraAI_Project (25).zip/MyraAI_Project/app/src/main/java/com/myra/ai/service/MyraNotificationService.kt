package com.myra.ai.service

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.myra.ai.data.Store
import com.myra.ai.voice.Speaker
import kotlinx.coroutines.*

/** Last notifications, so "नोटिफिकेशन पढ़ो" can read them out. */
object NotifBus {
    private val recent = ArrayDeque<String>()
    @Synchronized fun add(line: String) { recent.addLast(line); while (recent.size > 15) recent.removeFirst() }
    @Synchronized fun summary(): String =
        if (recent.isEmpty()) "बॉस, कोई नया नोटिफिकेशन नहीं है।"
        else "बॉस, ${recent.size} नोटिफिकेशन हैं। " + recent.toList().takeLast(4).joinToString(". ")
}

/** Needs Notification access (Settings). Speaks every new notification: "WhatsApp से नाबिन: कहाँ हो?" */
class MyraNotificationService : NotificationListenerService() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob() + CoroutineExceptionHandler { _, _ -> })
    private var own: Speaker? = null
    private var lastKey = ""; private var lastAt = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.isOngoing || (sbn.notification.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val ex = sbn.notification.extras
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = runCatching { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() }
            .getOrDefault(sbn.packageName)
        val key = sbn.packageName + title + text
        val now = System.currentTimeMillis()
        if (key == lastKey && now - lastAt < 10000) return
        lastKey = key; lastAt = now
        val line = "$app से $title: ${text.take(120)}".trim()
        NotifBus.add(line)
        if (Store(this).get("notif_speak") == "off") return
        val shared = WakeWordService.shared
        scope.launch {
            if (shared != null) {                                   // MYRA is running: use her voice, and keep her mic quiet meanwhile
                if (VoiceState.speaking) return@launch
                VoiceState.speaking = true
                shared.say(line) { VoiceState.speaking = false }
            } else (own ?: Speaker(this@MyraNotificationService).also { own = it }).say(line)
        }
    }

    override fun onDestroy() { own?.shutdown(); scope.cancel(); super.onDestroy() }
}
