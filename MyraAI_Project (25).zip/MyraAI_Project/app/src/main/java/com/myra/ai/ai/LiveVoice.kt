package com.myra.ai.ai

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.util.Base64
import com.myra.ai.service.VoiceState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

/**
 * Gemini Live (e.g. gemini-3.8-live): you talk, it answers in voice almost instantly.
 * With [tools] the model can call back into the phone (open apps, search, lock...) via [onTool].
 */
class LiveVoice(
    private val key: String, private val model: String, private val sys: String,
    private val scope: CoroutineScope? = null,
    private val tools: JSONArray? = null,
    private val onTool: (suspend (String, JSONObject) -> String)? = null,
    private val onTurn: (String, String) -> Unit = { _, _ -> },
    private val onEnd: (String, Boolean) -> Unit = { _, _ -> },
    private val onState: (String) -> Unit
) {
    private val client = OkHttpClient.Builder().readTimeout(0, TimeUnit.MILLISECONDS).pingInterval(20, TimeUnit.SECONDS).build()
    private val ui = Handler(Looper.getMainLooper())
    private var ws: WebSocket? = null
    private var mic: AudioRecord? = null
    private var track: AudioTrack? = null
    @Volatile private var running = false
    @Volatile private var connected = false
    @Volatile private var lastAudioAt = 0L
    private var inText = StringBuilder()
    private var outText = StringBuilder()

    private fun state(s: String) { ui.post { onState(s) } }

    fun start() {
        if (running) return
        running = true; connected = false; state("कनेक्ट हो रही है...")
        val ver = if (model.contains("thinking")) "v1alpha" else "v1beta"
        val req = Request.Builder()
            .url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.$ver.GenerativeService.BidiGenerateContent?key=${key.trim()}").build()
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                val gen = JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                    .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", "Aoede"))))
                val setup = JSONObject().put("model", "models/$model").put("generationConfig", gen)
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                if (scope != null) setup.put("inputAudioTranscription", JSONObject()).put("outputAudioTranscription", JSONObject())
                if (tools != null) setup.put("tools", tools)
                w.send(JSONObject().put("setup", setup).toString())
            }
            override fun onMessage(w: WebSocket, text: String) = onMsg(text)
            override fun onMessage(w: WebSocket, bytes: ByteString) = onMsg(bytes.utf8())
            override fun onFailure(w: WebSocket, t: Throwable, r: Response?) { fail("Error: ${t.message}") }
            override fun onClosed(w: WebSocket, code: Int, reason: String) { fail("बंद ($code) $reason") }
        })
    }

    private fun onMsg(s: String) {
        val j = runCatching { JSONObject(s) }.getOrNull() ?: return
        if (j.has("setupComplete")) { connected = true; state("🎙 बोलिए, मैं सुन रही हूँ"); startMic(); return }
        j.optJSONObject("toolCall")?.let { handleTools(it); return }
        val sc = j.optJSONObject("serverContent") ?: return
        sc.optJSONObject("inputTranscription")?.optString("text")?.let { inText.append(it) }
        sc.optJSONObject("outputTranscription")?.optString("text")?.let { outText.append(it); state(outText.toString().takeLast(120)) }
        if (sc.optBoolean("interrupted")) { track?.pause(); track?.flush(); track?.play() }
        val parts = sc.optJSONObject("modelTurn")?.optJSONArray("parts")
        if (parts != null) for (i in 0 until parts.length()) {
            val d = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
            if (d.isNotEmpty()) { val b = Base64.decode(d, Base64.DEFAULT); lastAudioAt = System.currentTimeMillis(); track?.write(b, 0, b.size) }
        }
        if (sc.optBoolean("turnComplete")) {
            val u = inText.toString().trim(); val a = outText.toString().trim()
            inText = StringBuilder(); outText = StringBuilder()
            if (u.isNotEmpty() && a.isNotEmpty()) ui.post { onTurn(u, a) }
        }
    }

    private fun handleTools(tc: JSONObject) {
        val calls = tc.optJSONArray("functionCalls") ?: return
        for (i in 0 until calls.length()) {
            val c = calls.getJSONObject(i)
            val id = c.optString("id"); val name = c.optString("name"); val args = c.optJSONObject("args") ?: JSONObject()
            val sc = scope
            if (sc == null || onTool == null) { reply(id, name, "यह टूल उपलब्ध नहीं है"); continue }
            sc.launch { reply(id, name, runCatching { onTool.invoke(name, args) }.getOrElse { "गड़बड़: ${it.message}" }) }
        }
    }

    private fun reply(id: String, name: String, result: String) {
        val fr = JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", result))
        ws?.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(fr))).toString())
    }

    @SuppressLint("MissingPermission")
    private fun startMic() {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        mic = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000, AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 6400))
        val tmin = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(tmin * 4, 48000)).setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }
        mic?.startRecording()
        Thread {
            val buf = ByteArray(3200)
            while (running) {
                val n = mic?.read(buf, 0, buf.size) ?: break
                if (n <= 0) continue
                var sum = 0.0; var k = 0
                while (k + 1 < n) { val v = (buf[k].toInt() and 0xff) or (buf[k + 1].toInt() shl 8); sum += v.toShort() * v.toShort().toDouble(); k += 2 }
                val rms = sqrt(sum / (n / 2)) / 32768.0
                VoiceState.level = VoiceState.level * 0.6f + (rms * 8).coerceIn(0.0, 1.0).toFloat() * 0.4f   // animation follows your voice
                VoiceState.speaking = System.currentTimeMillis() - lastAudioAt < 500                           // ...and hers
                ws?.send(JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
                    .put("data", Base64.encodeToString(buf, 0, n, Base64.NO_WRAP))
                    .put("mimeType", "audio/pcm;rate=16000"))).toString())
            }
        }.start()
    }

    /** The connection dropped or was refused (not stopped by us). */
    private fun fail(reason: String) {
        if (!running) return
        val was = connected
        stop()
        state("ℹ $reason")
        ui.post { onEnd(reason, was) }
    }

    fun stop() {
        if (!running) return
        running = false
        runCatching { ws?.close(1000, "bye") }; ws = null
        runCatching { mic?.stop(); mic?.release() }; mic = null
        runCatching { track?.stop(); track?.release() }; track = null
        VoiceState.speaking = false
        state("बंद")
    }
}
