package com.myra.ai.ui

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.content.Intent
import android.speech.RecognizerIntent
import com.myra.ai.voice.Speaker
import com.myra.ai.task.TaskRunner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.myra.ai.service.WakeWordService
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.myra.ai.ai.GeminiClient
import com.myra.ai.ai.Brain
import com.myra.ai.ai.GeminiTools
import com.myra.ai.data.Store
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Use in MainActivity:  setContent { MyraRoot() } */
@Composable
fun MyraRoot() = MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Bg)) { MyraContent() }

@Composable
fun MyraContent() {
    val ctx = LocalContext.current; val store = remember { Store(ctx) }
    var screen by remember { mutableStateOf("Home") }
    remember { loadTheme(store.get("theme")) }
    val (bat, chg) = rememberBattery()
    remember { GeminiClient.preferred = store.get("model") }
    // Home mic: listens, runs the task / answers, and SPEAKS (no need to open another panel)
    val speaker = remember { Speaker(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    val homeScope = rememberCoroutineScope()
    var homeStatus by remember { mutableStateOf("I am listening...") }
    var again by remember { mutableStateOf(0) }
    val speechIntent = remember {
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
    }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (t == null) homeStatus = "सुन नहीं पाई, फिर बोलो" else homeScope.launch {
            homeStatus = "सोच रही हूँ..."
            val a = converse(ctx, speaker, t)
            homeStatus = a.take(70)
            if (!a.startsWith("Error") && !a.startsWith("Network")) speaker.say(a)
            if (ConvState.pending != null) again++ else { delay(5000); homeStatus = "I am listening..." }
        }
    }
    LaunchedEffect(again) { if (again > 0) micLauncher.launch(speechIntent) }
    if (screen == "Home") AnimatedHome(battery = bat, charging = chg, status = homeStatus, onTile = { screen = it }, onMic = { micLauncher.launch(speechIntent) }) else
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            TextButton({ screen = "Home" }) { Text("← Home", color = Purple) }
            when (screen) {
                "Voice Assistant" -> VoiceAssistantScreen(store) { screen = "Settings" }
                "AI Chat" -> Ask(store, "Gemini से पूछो") { k, q -> Brain.answer(ctx, q) }
                "Web Search" -> Ask(store, "Internet पर खोजो", tasks = false) { k, q -> GeminiTools.webSearch(k, q) }
                "Live Vision" -> Vision(store)
                "Memory" -> MemoryPanel(store)
                "Automation" -> HistoryPanel(store)
                "More Tools" -> MoreTools { screen = it }
                "Themes" -> ThemePanel(store)
                "Battery" -> BatteryPanel(store)
                "Live" -> LivePanel(store)
                "Setup" -> SetupPanel(store)
                "Phone Control" -> PhoneControlPanel(store)
                "Profile" -> ProfilePanel(store)
                "Resume" -> ResumePanel(store)
                "Coding" -> CodingPanel(store)
                else -> SettingsPanel(store)   // Phone Control / More Tools -> settings & permissions
            }
        }
}

@Composable
fun Ask(store: Store, hint: String, tasks: Boolean = true, call: suspend (String, String) -> String) {
    val ctx = LocalContext.current
    val speaker = remember { Speaker(ctx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    var q by remember { mutableStateOf("") }; var a by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    fun run(text: String) = scope.launch {
        a = "सोच रही हूँ..."
        a = if (tasks) converse(ctx, speaker, text) else call(store.get("gemini_key"), text)
        store.addHistory(text)
        if (!a.startsWith("Error") && !a.startsWith("Network")) speaker.say(a)
    }
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { q = it; run(it) }
    }
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text(hint) })
    Row {
        Button({ run(q) }) { Text("भेजो") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton({
            mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"))
        }) { Text("🎤 बोलो") }
    }
    Box(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
        Text(a, color = Color.White, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
fun Vision(store: Store) {
    var q by remember { mutableStateOf("यह क्या है?") }; var a by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val appCtx = LocalContext.current
    val speaker = remember { Speaker(appCtx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bmp: Bitmap? ->
        if (bmp != null) scope.launch { a = "देख रही हूँ..."; a = GeminiTools.vision(store.get("gemini_key"), bmp, q)
            if (!a.startsWith("Error") && !a.startsWith("Network")) speaker.say(a) }
    }
    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("सवाल") })
    Button({ cam.launch(null) }) { Text("📷 फोटो लो और पूछो") }
    Box(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
        Text(a, color = Color.White, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
fun MemoryPanel(store: Store) {
    val appCtx = LocalContext.current
    val speaker = remember { Speaker(appCtx) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(store.memories()) }; var t by remember { mutableStateOf("") }
    OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth(), label = { Text("कुछ याद रखवाओ") })
    Row { Button({ if (t.isNotBlank()) { store.addMemory(t); items = store.memories(); t = ""; scope.launch { speaker.say("ठीक है बॉस, याद कर लिया।") } } }) { Text("Save") }
        Spacer(Modifier.width(8.dp)); OutlinedButton({ store.clearMemories(); items = emptyList() }) { Text("Clear") }
        Spacer(Modifier.width(8.dp))
        OutlinedButton({ scope.launch { speaker.say(if (items.isEmpty()) "अभी कुछ याद नहीं है बॉस।" else items.joinToString(". ")) } }) { Text("🔊 सुनाओ") } }
    LazyColumn { items(items) { m -> Text("• $m   ✕", color = Color.White, modifier = Modifier.clickable { store.removeMemory(m); items = store.memories() }.padding(vertical = 6.dp)) } }
}

@Composable
fun HistoryPanel(store: Store) =
    LazyColumn { items(store.history().reversed()) { Text("• $it", color = Color.White, modifier = Modifier.padding(vertical = 4.dp)) } }

@Composable
fun SettingsPanel(store: Store) {
    // scrollable: every field (ElevenLabs, OpenAI...) is reachable, with room below for the keyboard
    Column(Modifier.verticalScroll(rememberScrollState())) { SettingsBody(store); Spacer(Modifier.height(260.dp)) }
}

@Composable
fun SettingsBody(store: Store) {
    val ctx = LocalContext.current
    var refresh by remember { mutableStateOf(0) }
    if (refresh >= 0 && store.get("gemini_key").isBlank())
        Text("⚠ Gemini API Key खाली है! इसके बिना MYRA जवाब, सर्च और कंट्रोल कुछ नहीं कर पाएगी। aistudio.google.com/apikey पर मुफ़्त key बनाओ, उसे कॉपी करो, फिर नीचे का बटन दबाओ।",
            color = Color(0xFFFF6B6B), modifier = Modifier.padding(bottom = 6.dp))
    OutlinedButton({
        val clip = ctx.getSystemService(android.content.ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text?.toString()?.trim().orEmpty()
        if (clip.length > 20) { store.set("gemini_key", clip); refresh++ }
    }, Modifier.fillMaxWidth()) { Text("📋 Clipboard से Gemini Key चिपकाओ") }
    Spacer(Modifier.height(8.dp))
    var wake by remember { mutableStateOf(store.get("wake") != "off") }
    Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("Background Wake Word (Hello Myra)", color = Color.White, modifier = Modifier.weight(1f))
        Switch(wake, { on ->
            wake = on; store.set("wake", if (on) "on" else "off")
            val i = Intent(ctx, WakeWordService::class.java)
            if (on) ctx.startForegroundService(i) else ctx.stopService(i)
        })
    }
    OutlinedButton({ ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + ctx.packageName))) },
        Modifier.fillMaxWidth()) { Text("1) Overlay permission (animation + task card)") }
    OutlinedButton({ ctx.startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
        Modifier.fillMaxWidth()) { Text("2) Accessibility ON करो (Phone Control)") }
    Spacer(Modifier.height(12.dp))
    var guardOn by remember { mutableStateOf(store.get("touchguard") != "off") }
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("🛡 Touch Guard (MYRA काम करे तब मेरा टच रुके)", color = Color.White, modifier = Modifier.weight(1f))
        Switch(guardOn, { guardOn = it; store.set("touchguard", if (it) "on" else "off") })
    }
    var beepMusic by remember { mutableStateOf(store.get("beepmusic") == "on") }
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("🔇 Beep पूरी तरह रोको (वरना भी रुकती है; अड़ियल फ़ोन के लिए, media आवाज़ पल भर म्यूट होगी)", color = Color.White, modifier = Modifier.weight(1f))
        Switch(beepMusic, { beepMusic = it; store.set("beepmusic", if (it) "on" else "off") })
    }
    var notifSpeak by remember { mutableStateOf(store.get("notif_speak") != "off") }
    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("🔔 नए नोटिफिकेशन बोलकर बताओ", color = Color.White, modifier = Modifier.weight(1f))
        Switch(notifSpeak, { notifSpeak = it; store.set("notif_speak", if (it) "on" else "off") })
    }
    OutlinedButton({ ctx.startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
        Modifier.fillMaxWidth()) { Text("3) Notification access ON करो (नोटिफिकेशन बताने के लिए)") }
    var ytSkip by remember { mutableStateOf(store.get("ytskip") != "off") }
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("⏭ YouTube ads अपने आप स्किप (जहाँ Skip बटन आए)", color = Color.White, modifier = Modifier.weight(1f))
        Switch(ytSkip, { ytSkip = it; store.set("ytskip", if (it) "on" else "off") })
    }
    var liveOn by remember { mutableStateOf(store.get("live_engine") != "off") }
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("⚡ Gemini Live से बात: तुरंत जवाब, आवाज़ में (बंद = सामान्य मोड)", color = Color.White, modifier = Modifier.weight(1f))
        Switch(liveOn, { liveOn = it; store.set("live_engine", if (it) "on" else "off") })
    }
    var funMode by remember { mutableStateOf(store.get("persona") != "plain") }
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("😄 चुलबुला, दोस्त जैसा अंदाज़ (बंद = सीधा-सादा)", color = Color.White, modifier = Modifier.weight(1f))
        Switch(funMode, { funMode = it; store.set("persona", if (it) "fun" else "plain") })
    }
    var brain by remember { mutableStateOf(store.get("brain").ifBlank { "gemini" }) }
    Text("दिमाग़ (Brain): " + if (brain == "openai") "ChatGPT" else "Gemini", color = Color.White)
    Row {
        listOf("Gemini" to "gemini", "ChatGPT" to "openai").forEach { (l, id) ->
            OutlinedButton({ brain = id; store.set("brain", id) }) { Text(l) }
            Spacer(Modifier.width(6.dp))
        }
    }
    var model by remember { mutableStateOf(store.get("model")) }
    Text("Gemini Model: " + model.ifBlank { "Auto (सबसे तेज़)" }, color = Color.White)
    Row {
        listOf("Auto" to "", "3.8 Flash" to "gemini-3.8-flash", "Pro" to "gemini-3.1-pro-preview").forEach { (l, id) ->
            OutlinedButton({ model = id; store.set("model", id); GeminiClient.preferred = id }) { Text(l) }
            Spacer(Modifier.width(6.dp))
        }
    }
    F("Custom model ID (Live आदि)", model) { model = it; store.set("model", it.trim()); GeminiClient.preferred = it.trim() }
    Spacer(Modifier.height(12.dp))
    val keys = listOf("gemini_key" to "Gemini API Key", "eleven_key" to "ElevenLabs API Key", "voice_id" to "ElevenLabs Voice ID",
        "openai_key" to "OpenAI (ChatGPT) API Key", "openai_model" to "OpenAI model (खाली = gpt-5.4-mini)")
    keys.forEach { (k, label) ->
        var v by remember(refresh) { mutableStateOf(store.get(k)) }
        OutlinedTextField(v, { v = it; store.set(k, it) }, Modifier.fillMaxWidth().padding(bottom = 8.dp), label = { Text(label) }, singleLine = true)
    }
    Text("Phone Control के लिए: Settings → Accessibility → MYRA ON करो।", color = Color.White)
}
